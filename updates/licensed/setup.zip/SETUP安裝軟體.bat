@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
set "PYLIST=%TEMP%\BonusLedger_python_list_%RANDOM%.txt"
set "PYTHON_EXE="

where py >nul 2>nul
if not errorlevel 1 (
    py -0p >"%PYLIST%" 2>nul
    findstr /i "python.exe" "%PYLIST%" >nul
    if not errorlevel 1 (
        findstr /i "3." "%PYLIST%" >nul
        if not errorlevel 1 (
            py -3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
            if not errorlevel 1 goto use_py
        )
    )
)

for /f "delims=" %%P in ('where python 2^>nul') do (
    echo %%P | findstr /i "WindowsApps" >nul
    if errorlevel 1 if not defined PYTHON_EXE set "PYTHON_EXE=%%P"
)
if defined PYTHON_EXE (
    "%PYTHON_EXE%" -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
    if not errorlevel 1 goto use_python
)

where py >nul 2>nul
if not errorlevel 1 (
    echo 尚未安裝 Python 執行環境，正在安裝 Python 3.12……
    py install 3.12
    if not errorlevel 1 (
        py -3.12 -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
        if not errorlevel 1 goto use_py312
    )
)

del "%PYLIST%" >nul 2>nul
echo 找不到可用的 Python 3.10 以上版本。
echo 請在 Python Install Manager 安裝 Python 3.12 後，再重新執行本安裝檔。
pause
exit /b 1

:use_py
del "%PYLIST%" >nul 2>nul
py -3 "啟動程式.py"
if errorlevel 1 pause
exit /b %errorlevel%

:use_py312
del "%PYLIST%" >nul 2>nul
py -3.12 "啟動程式.py"
if errorlevel 1 pause
exit /b %errorlevel%

:use_python
del "%PYLIST%" >nul 2>nul
"%PYTHON_EXE%" "啟動程式.py"
if errorlevel 1 pause
exit /b %errorlevel%
