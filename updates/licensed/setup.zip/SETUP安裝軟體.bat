@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 goto use_py
where python >nul 2>nul
if not errorlevel 1 goto use_python
echo 找不到 Python。請安裝 Python 3.10 以上版本，並選取 Tcl/Tk，再重新啟動。
pause
exit /b 1

:use_py
py -3 "啟動程式.py"
if errorlevel 1 pause
exit /b %errorlevel%

:use_python
python "啟動程式.py"
if errorlevel 1 pause
exit /b %errorlevel%
