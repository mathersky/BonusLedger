"""Local, versioned bonus ledger. Money is stored as integer thousandths of a dollar."""
import contextlib
import hashlib
import json
import sqlite3
import uuid
from datetime import datetime, timezone, date
from decimal import Decimal, InvalidOperation, ROUND_DOWN, ROUND_HALF_UP
from pathlib import Path

KINDS = {'bonus1':'獎1','bonus2':'獎2','bonus3':'獎3','bonus4':'獎4',
         'year_end':'年終','performance':'考績'}
SHEETS = {'bonus1':'1','bonus2':'2','bonus3':'3','bonus4':'4','year_end':'年','performance':'考'}
VERSION = '1.8.1'
DISPLAY_KINDS = dict(zip(KINDS, ['第一次獎勵金','第二次獎勵金','第三次獎勵金','第四次獎勵金','年終','考績']))

def uid(): return uuid.uuid4().hex
def now(): return datetime.now(timezone.utc).isoformat(timespec='microseconds')
def js(value): return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',',':'))
def digest(value): return hashlib.sha256(value if isinstance(value,bytes) else js(value).encode()).hexdigest()
def milli(value):
    try: d=Decimal(str(value).strip().replace(',',''))
    except (InvalidOperation,ValueError): raise ValueError(f'金額不是有效數字：{value}')
    if not d.is_finite() or d<0 or d>Decimal('1000000000000'):
        raise ValueError('金額須為有限非負數，且不得超過一兆元。')
    if d*1000 != (d*1000).to_integral_value(): raise ValueError('金額最多保留小數三位。')
    return int(d*1000)
def money(n):
    s=f'{Decimal(n)/1000:,.3f}'
    return s.rstrip('0').rstrip('.')
def numeric(n): return float(Decimal(n)/1000)
def valid_date(text):
    try: return date.fromisoformat(text).isoformat()
    except (ValueError,TypeError): raise ValueError('日期請使用西元 YYYY-MM-DD，例如 2026-09-19。')

def validate_settings(s):
    s=dict(s); s['threshold_milli']=milli(s['threshold'])
    if s['threshold_milli']<=0: raise ValueError('所得稅門檻必須大於 0。')
    for key in ['tax_percent','nhi_percent']:
        d=Decimal(str(s[key]))
        if not d.is_finite() or not 0<=d<=100: raise ValueError('費率須介於 0% 與 100%。')
        s[key]=str(d)
    if int(s['insurance_multiple'])!=4: raise ValueError('目前核准規格使用四倍投保額。')
    if not str(s.get('organization','')).strip(): raise ValueError('請填機關名稱。')
    return s

def calculate_batch(kind, people, previous, settings, tax_policy="integer_v15"):
    """Pure calculation. Q6 deliberately returns zero when previous == threshold."""
    legacy=tax_policy=="legacy_v14"
    medical=kind.startswith('bonus'); threshold=settings['threshold_milli']
    tax_rate=Decimal(settings['tax_percent'])/100
    nhi_rate=Decimal(settings['nhi_percent'])/100
    rows=[]
    for p in people:
        gross=p['gross_milli']; taxable=p['taxable_milli']; b=p['accumulation_base_milli']
        prev=previous.get(p['employee_id'],0); acc=prev+b; q=p['insurance_milli']*4
        if acc<q: nhi=0; branch='累計未達四倍門檻'
        elif prev<q:
            nhi=int((Decimal(acc-q)/1000*nhi_rate).quantize(Decimal('1'),rounding=ROUND_HALF_UP))*1000
            branch='本次跨門檻，超額計費'
        elif prev==q: nhi=0; branch='前次累計恰等於門檻，依確認規格不扣'
        else:
            nhi=int((Decimal(b)/1000*nhi_rate).quantize(Decimal('1'),rounding=ROUND_HALF_UP))*1000
            branch='之前已超門檻，本次全額計費'
        eligible=taxable>=threshold
        tax=int((Decimal(taxable)*tax_rate).quantize(Decimal('1'),rounding=ROUND_DOWN)) if eligible else 0
        if legacy and not medical: tax=(tax//1000)*1000
        rows.append({**p,'previous_accumulated_milli':prev,'current_base_milli':b,
            'accumulated_milli':acc,'fourfold_insurance_milli':q,'threshold_milli':threshold,
            'needs_withholding':int(eligible),'calculated_tax_milli':tax,'deducted_tax_milli':tax,
            'nhi_milli':nhi,'explanation_json':js({'nhi_branch':branch,'rules':VERSION,'tax_policy':tax_policy})})
    if medical and legacy:
        roles=[r for r in rows if r['tax_difference_role']]
        if len(roles)>1: raise ValueError('每批只能有一位醫師差額扣稅人員。請調整基本資料。')
        taxes=sum(r['calculated_tax_milli'] for r in rows)
        if roles:
            role=roles[0]; others=taxes-role['calculated_tax_milli']
            role['deducted_tax_milli']=(taxes//1000-others//1000)*1000
        elif taxes % 1000:
            raise ValueError('本批所得稅有小數差額，請指定醫師差額扣稅人員並納入本批。')
    if not legacy:
        roles=[r for r in rows if r['tax_difference_role']]
        if len(roles)>1:raise ValueError('每批只能有一位醫師差額扣稅人員。')
        for r in rows:r['deducted_tax_milli']=r['calculated_tax_milli']//1000*1000
        if roles:
            doctor=roles[0]
            total=sum(r['calculated_tax_milli'] for r in rows)
            others=total-doctor['calculated_tax_milli']
            # Sum untruncated individual tax first, retain cents without rounding up,
            # then discard cents. Never subtract the sum of individually truncated tax.
            total_cents=total//10*10
            doctor['deducted_tax_milli']=(total_cents//1000-others//1000)*1000
            explanation=json.loads(doctor['explanation_json'])
            explanation.update(tax_total_two_decimals_milli=total_cents,non_doctor_raw_total_milli=others)
            doctor['explanation_json']=js(explanation)
    for r in rows:
        base=r['taxable_milli'] if legacy and kind=='performance' else r['gross_milli']
        r['net_milli']=base-r['deducted_tax_milli']-r['nhi_milli']
        if r['net_milli']<0: raise ValueError(f"{r['employee_snapshot']['name']} 的實領為負數，請檢查金額及差額扣稅人員。")
    return rows

def summary(rows):
    s={k:0 for k in ['gross','taxable','tax','deducted','nhi','net','withheld_income','exempt_income','withheld_count','exempt_count','people']}
    for r in rows:
        for dest,source in [('gross','gross_milli'),('taxable','taxable_milli'),('tax','calculated_tax_milli'),('deducted','deducted_tax_milli'),('nhi','nhi_milli'),('net','net_milli')]:s[dest]+=r[source]
        if r['gross_milli']>0 or r['taxable_milli']>0:
            cat='withheld' if r['needs_withholding'] else 'exempt'
            s[cat+'_income']+=r['taxable_milli'];s[cat+'_count']+=1;s['people']+=1
    s['tax_total_integer']=(s['tax']//1000)*1000
    return s

class Store:
    def __init__(self,path,assets):
        self.path=Path(path);self.assets=Path(assets); self.path.parent.mkdir(parents=True,exist_ok=True)
        self.db=sqlite3.connect(self.path); self.db.row_factory=sqlite3.Row
        self.db.execute('PRAGMA foreign_keys=ON'); self.db.execute('PRAGMA busy_timeout=5000')
        self.db.execute('PRAGMA journal_mode=WAL'); self.db.execute('PRAGMA synchronous=FULL')
        if not self.db.execute("SELECT 1 FROM sqlite_master WHERE name='schema_version'").fetchone():
            self.db.executescript((self.assets/'schema.sql').read_text(encoding='utf-8'))
            with self.db:
                self.db.execute('INSERT INTO cycles(id,label,status,opened_at) VALUES(?,?,?,?)',(uid(),'首次計算期間','open',now()))
                seed=json.loads((self.assets/'seed.json').read_text(encoding='utf-8'))
                self.db.execute('INSERT INTO settings_versions VALUES(?,?,?,?,?)',(uid(),1,js(validate_settings(seed['settings'])),'範本與使用者核准規格',now()))
                for i,e in enumerate(seed['employees'],1):self._save_employee({**e,'id':uid(),'employee_code':f'E{i:03d}'},initial=True)
        if self.db.execute('SELECT MAX(version) FROM schema_version').fetchone()[0]!=1:raise ValueError('此資料庫版本不相容。')
        self.ensure_editor_storage()
        self.upgrade_tax_policy()
        self.upgrade_performance_policy()
    def upgrade_tax_policy(self):
        cy=self.cycle()
        if not cy:return
        published=self.one("SELECT r.* FROM calculation_runs r JOIN cycle_publications p ON p.run_id=r.id WHERE p.cycle_id=?",(cy["id"],))
        if not published or published["engine_version"] not in {"1.0.0","1.1.0","1.2.0","1.3.0","1.4.0"}:return
        backup=self.path.parent/"backups"/("扣稅規則升級前_1.5.0_"+datetime.now().strftime("%Y%m%d_%H%M%S_%f")+".sqlite")
        self.backup(backup)
        with self.db:
            self._touch(cy["id"]);run=self._recalculate(cy["id"])
            self.audit("tax_policy_upgrade","cycle",cy["id"],{"run_id":published["id"],"engine_version":published["engine_version"]},{"run_id":run,"engine_version":VERSION,"backup":str(backup)},"使用者確認整數扣稅與實領同步更新；保留原計算代次及封存期間")
    def upgrade_performance_policy(self):
        cy=self.cycle()
        if not cy:return
        published=self.one("SELECT r.* FROM calculation_runs r JOIN cycle_publications p ON p.run_id=r.id WHERE p.cycle_id=?",(cy['id'],))
        if not published or published['engine_version'] not in {'1.5.0','1.5.1'}:return
        if not any(b['state']=='active' and b['bonus_kind']=='performance' for b in self.history()):return
        backup=self.path.parent/'backups'/('考績規則修正前_1.6.0_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.sqlite')
        self.backup(backup)
        with self.db:
            self._touch(cy['id']);run=self._recalculate(cy['id'])
            self.audit('performance_policy_upgrade','cycle',cy['id'],{'run_id':published['id']},{'run_id':run,'backup':str(backup)},'考績實領改以未扣稅金額減稅及健保；保留原始輸入與舊結果，封存期不變')
    def ensure_editor_storage(self):
        with self.db:self.db.execute("CREATE TABLE IF NOT EXISTS editor_sessions (cycle_id TEXT NOT NULL, kind TEXT NOT NULL, payload_json TEXT NOT NULL, updated_at TEXT NOT NULL, PRIMARY KEY(cycle_id,kind))")
    def save_editor(self,kind,state):
        with self.db:self.db.execute('INSERT OR REPLACE INTO editor_sessions VALUES(?,?,?,?)',(self.cycle()['id'],kind,js(state),now()))
    def load_editor(self,kind):
        r=self.one('SELECT payload_json FROM editor_sessions WHERE cycle_id=? AND kind=?',(self.cycle()['id'],kind))
        return json.loads(r['payload_json']) if r else None
    def clear_editor(self,kind):
        with self.db:self.db.execute('DELETE FROM editor_sessions WHERE cycle_id=? AND kind=?',(self.cycle()['id'],kind))
    def reorder_batches(self,ordered_ids):
        with self.db:
            self.db.execute('BEGIN IMMEDIATE')
            cy=self.cycle();before=self.history();active=[b for b in before if b['state']=='active']
            if len(ordered_ids)!=len(set(ordered_ids)) or set(ordered_ids)!={b['id'] for b in active}:raise ValueError('順序必須包含本期每個有效批次且不可重複。')
            slots=sorted(b['sequence'] for b in active)
            offset=max([b['sequence'] for b in before]+[0])+1
            for i,bid in enumerate(ordered_ids):self.db.execute('UPDATE batches SET sequence=? WHERE id=?',(offset+i,bid))
            for seq,bid in zip(slots,ordered_ids):self.db.execute('UPDATE batches SET sequence=? WHERE id=?',(seq,bid))
            self._touch();self._recalculate(cy['id'])
            self.audit('reorder','cycle',cy['id'],[b['id'] for b in active],ordered_ids,'使用者調整累計計算順序')
    def close(self): self.db.close()
    def all(self,sql,args=()):return [dict(r) for r in self.db.execute(sql,args)]
    def one(self,sql,args=()):
        r=self.db.execute(sql,args).fetchone();return dict(r) if r else None
    def cycle(self):return self.one("SELECT * FROM cycles WHERE status='open'")
    def cycles(self):return self.all('SELECT * FROM cycles ORDER BY opened_at DESC')
    def settings_record(self):return self.one('SELECT * FROM settings_versions ORDER BY version DESC LIMIT 1')
    def settings(self):return json.loads(self.settings_record()['settings_json'])
    def audit(self,action,entity,ident,before,after,reason):
        self.db.execute('INSERT INTO audit_events(happened_at,action,entity_type,entity_id,before_json,after_json,reason) VALUES(?,?,?,?,?,?,?)',(now(),action,entity,ident,js(before) if before is not None else None,js(after) if after is not None else None,reason))
    def save_settings(self,s):
        s=validate_settings(s)
        with self.db:
            old=self.settings_record();self.db.execute('INSERT INTO settings_versions VALUES(?,?,?,?,?)',(uid(),old['version']+1,js(s),'使用者在基本設定修改',now()))
            self.audit('settings','settings',str(old['version']+1),json.loads(old['settings_json']),s,'僅供新批次使用')
            self._touch()
    def rename_cycle(self,label):
        if not str(label).strip():raise ValueError('計算期間名稱不可空白。')
        with self.db:
            cy=self.cycle();self.db.execute('UPDATE cycles SET label=? WHERE id=?',(label.strip(),cy['id']))
            self.audit('rename_cycle','cycle',cy['id'],{'label':cy['label']},{'label':label.strip()},'使用者修改期間名稱');self._touch()
    def employees(self):return self.all('SELECT * FROM employees ORDER BY employee_code')
    def _save_employee(self,e,initial=False):
        e=dict(e); old=self.one('SELECT * FROM employees WHERE id=?',(e.get('id',''),))
        e.setdefault('id',uid());e.setdefault('employee_code','E'+uid()[:8].upper())
        if not str(e.get('name','')).strip():raise ValueError('姓名不可空白。')
        for key in ['national_id','bank_account','insurance_unit']:e[key]=str(e.get(key,'') or '').strip()
        if e.get('national_id') and (len(e['national_id'])!=10):raise ValueError('身分證號請輸入 10 碼，或留空待補。')
        for key in ['employed_on','left_on']:
            e[key]=valid_date(e[key]) if e.get(key) else None
        e['updated_at']=now();e['created_at']=old['created_at'] if old else now()
        cols=['id','employee_code','name','title','employment_type','active','employed_on','left_on','national_id','bank_account','insurance_unit','default_insurance_milli','payout_enabled','nhi_export_enabled','tax_difference_role','created_at','updated_at']
        if old:self.db.execute('UPDATE employees SET '+','.join(c+'=?' for c in cols[1:])+' WHERE id=?',tuple(e[c] for c in cols[1:])+(e['id'],))
        else:self.db.execute('INSERT INTO employees('+','.join(cols)+') VALUES('+','.join('?' for _ in cols)+')',tuple(e[c] for c in cols))
        if not initial:self.audit('employee_update' if old else 'employee_create','employee',e['id'],old,e,'使用者維護')
        return e['id']
    def save_employee(self,e):
        with self.db:r=self._save_employee(e);self._touch()
        return r
    def remove_employee(self,ident):
        with self.db:
            old=self.one('SELECT * FROM employees WHERE id=?',(ident,))
            if self.one('SELECT employee_id FROM batch_people WHERE employee_id=? LIMIT 1',(ident,)):
                self.db.execute('UPDATE employees SET active=0,left_on=?,updated_at=? WHERE id=?',(date.today().isoformat(),now(),ident));action='employee_deactivate'
            else:self.db.execute('DELETE FROM employees WHERE id=?',(ident,));action='employee_delete'
            self.audit(action,'employee',ident,old,None,'使用者刪除／離職');self._touch()
    def _touch(self,cycle=None):self.db.execute('UPDATE cycles SET data_version=data_version+1 WHERE id=?',(cycle or self.cycle()['id'],))
    def latest_insurance(self,employee_id):
        r=self.one("SELECT p.insurance_milli FROM batch_people p JOIN batches b ON b.id=p.batch_id AND b.current_revision=p.revision JOIN cycles c ON c.id=b.cycle_id WHERE b.state='active' AND p.employee_id=? ORDER BY c.opened_at DESC,b.sequence DESC LIMIT 1",(employee_id,))
        return r['insurance_milli'] if r else self.one('SELECT default_insurance_milli FROM employees WHERE id=?',(employee_id,))['default_insurance_milli']
    def history(self,cycle=None):return self.all('SELECT b.*,r.paid_on,r.earned_period,r.created_at AS revised_at,r.metadata_json FROM batches b JOIN batch_revisions r ON b.id=r.batch_id AND b.current_revision=r.revision WHERE b.cycle_id=? ORDER BY b.sequence',(cycle or self.cycle()['id'],))
    def batch_payload(self,batch_id,revision=None):
        b=self.one('SELECT * FROM batches WHERE id=?',(batch_id,));rev=revision or b['current_revision']
        r=self.one('SELECT * FROM batch_revisions WHERE batch_id=? AND revision=?',(batch_id,rev))
        p=self.all('SELECT * FROM batch_people WHERE batch_id=? AND revision=? ORDER BY display_order',(batch_id,rev))
        for x in p:x['employee_snapshot']=json.loads(x['employee_snapshot_json']);x['source_row_ids']=json.loads(x['source_row_ids_json'])
        return {**b,**r,'kind':b['bonus_kind'],'people':p,'regions':json.loads(r['source_regions_json']),'metadata':json.loads(r['metadata_json']),
            'raw_rows':self.all('SELECT * FROM source_rows WHERE batch_id=? AND revision=?',(batch_id,rev)),
            'settings':json.loads(self.one('SELECT settings_json FROM settings_versions WHERE id=?',(r['settings_version_id'],))['settings_json'])}
    def validate_payload(self,p):
        if p['kind'] not in KINDS:raise ValueError('資料種類不正確。')
        p['paid_on']=valid_date(p['paid_on']);p['credited_on']=valid_date(p.get('credited_on') or p['paid_on'])
        if not p.get('earned_period','').strip():raise ValueError('請輸入獎金所屬期間。')
        seen=set()
        for i,x in enumerate(p['people']):
            if x['employee_id'] in seen:raise ValueError('同批員工重複，請先合併月份金額。')
            seen.add(x['employee_id'])
            for key in ['gross_milli','taxable_milli','insurance_milli']:
                if not isinstance(x[key],int) or x[key]<0:raise ValueError('金額資料格式有誤。')
            if 'supervisor_milli' in x:
                allowance=x['supervisor_milli'] if not p['kind'].startswith('bonus') else 0
                if not isinstance(allowance,int) or allowance<0 or allowance>x['gross_milli']:raise ValueError('主管加給不可為負值或超過未扣稅金額。')
                x['taxable_milli']=x['gross_milli']-allowance
            e=x['employee_snapshot'];required=(p['kind'].startswith('bonus') and '醫師' in e.get('title','')) or (p['kind']=='year_end' and e['employment_type']=='contract')
            if required and x.get('amount_entered') is False:raise ValueError(e['name']+' 請填寫未扣稅金額。')
            if x['taxable_milli']>x['gross_milli']:raise ValueError('報稅金額不可高於應發金額。')
            if p['kind'].startswith('bonus') and x['taxable_milli']!=x['gross_milli']:raise ValueError('醫療獎金的應發與報稅金額須相同。')
            x['accumulation_base_milli']=x['taxable_milli'];x['net_base_mode']='gross'
            x['display_order']=i
        if not seen or not sum(x['gross_milli'] for x in p['people']):raise ValueError('沒有正額獎金可匯入。')
        return p
    def preview(self,p,replace_id=None):
        p=self.validate_payload(json.loads(js(p)));cy=self.cycle();replace=None
        if replace_id:
            replace=self.one('SELECT * FROM batches WHERE id=?',(replace_id,))
            if not replace or replace['cycle_id']!=cy['id'] or replace['state']!='active' or replace['bonus_kind']!=p['kind']:raise ValueError('只能取代本期同種類的有效批次。')
        elif self.one("SELECT id FROM batches WHERE cycle_id=? AND bonus_kind=? AND state='active'",(cy['id'],p['kind'])):
            raise ValueError('同種類已匯入。請從匯入紀錄選擇「取代／修改」。')
        seq=replace['sequence'] if replace else cy['next_sequence'];previous={};all_rows=[]
        timeline=[]
        for b in self.history():
            if b['state']=='active' and b['id']!=replace_id:timeline.append((b['sequence'],b['id'],self.batch_payload(b['id'])))
        timeline.append((seq,'preview',p));current=[]
        for order,bid,payload in sorted(timeline,key=lambda x:x[0]):
            rows=calculate_batch(payload['kind'],payload['people'],previous,payload['settings'])
            for r in rows:previous[r['employee_id']]=r['accumulated_milli']
            if bid=='preview':current=rows
            all_rows.append({'batch_id':bid,'sequence':order,'kind':payload['kind'],'summary':summary(rows)})
        return {'payload':p,'rows':current,'summary':summary(current),'affected':all_rows,'cycle_version':cy['data_version']}
    def save_draft(self,p,replace_id=None):
        preview=self.preview(p,replace_id);p=preview['payload'];ident=uid();key=uid()
        with self.db:self.db.execute('INSERT INTO import_drafts VALUES(?,?,?,?,?,?,?,?,?,?,?)',(ident,self.cycle()['id'],p['kind'],p.get('source_file_id'),preview['cycle_version'],js({'payload':p,'replace_id':replace_id}),js(preview['summary']),'ready',key,now(),now()))
        return ident,preview
    def store_file(self,path):
        data=Path(path).read_bytes();sha=digest(data);r=self.one('SELECT id FROM source_files WHERE sha256=?',(sha,))
        if r:return r['id']
        ident=uid()
        with self.db:self.db.execute('INSERT INTO source_files VALUES(?,?,?,?,?,?,?)',(ident,sha,Path(path).name,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',data,len(data),now()))
        return ident
    def _insert_revision(self,bid,rev,p,reason):
        fingerprint=digest({'kind':p['kind'],'amounts':sorted((x['employee_id'],x['gross_milli'],x['taxable_milli']) for x in p['people'])})
        self.db.execute('INSERT INTO batch_revisions VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(bid,rev,p.get('source_file_id'),p['settings_version_id'],p['paid_on'],p.get('credited_on'),p['earned_period'],fingerprint,js(p.get('regions',[])),js(p.get('metadata',{})),reason,now()))
        source_links={}
        for x in p.get('raw_rows',[]):
            rowid=uid()
            self.db.execute('INSERT INTO source_rows VALUES(?,?,?,?,?,?,?,?,?,?)',(rowid,bid,rev,x.get('source_sheet',''),x.get('source_location',''),x.get('region_key',''),x.get('raw_payload_json',js(x)),x.get('employee_id'),x.get('disposition','included'),x.get('decision_reason','來源匯入')))
            if x.get('employee_id') and x.get('disposition','included')=='included':source_links.setdefault(x['employee_id'],[]).append(rowid)
        for i,x in enumerate(p['people']):
            self.db.execute('INSERT INTO batch_people VALUES('+','.join('?' for _ in range(17))+')',(bid,rev,x['employee_id'],i,js(x['employee_snapshot']),js(source_links.get(x['employee_id'],[])),x['gross_milli'],x['taxable_milli'],x['accumulation_base_milli'],x['net_base_mode'],x['insurance_milli'],x.get('insurance_change_reason',''),x.get('input_method','manual'),x.get('input_explanation',''),x['payout_enabled'],x['nhi_export_enabled'],x['tax_difference_role']))
        return fingerprint
    def commit_draft(self,ident,reason='正式匯入'):
        with self.db:
            self.db.execute('BEGIN IMMEDIATE')
            d=self.one('SELECT * FROM import_drafts WHERE id=?',(ident,))
            if not d:raise ValueError('預覽已不存在，請重新預覽。')
            if d['state']=='committed':
                return self.one('SELECT id FROM batches WHERE confirmation_key=?',(d['confirmation_key'],))['id'] if self.one('SELECT id FROM batches WHERE confirmation_key=?',(d['confirmation_key'],)) else json.loads(d['draft_payload_json'])['replace_id']
            cy=self.cycle()
            if cy['id']!=d['cycle_id'] or cy['data_version']!=d['cycle_data_version']:raise ValueError('資料在預覽後已變更，請重新預覽再確認。')
            wrapper=json.loads(d['draft_payload_json']);p=wrapper['payload'];bid=wrapper['replace_id']
            self.preview(p,bid)
            before=self.batch_payload(bid) if bid else None
            if bid:
                rev=before['current_revision']+1
                self.db.execute('DELETE FROM active_import_keys WHERE batch_id=?',(bid,))
                self.db.execute('UPDATE batches SET current_revision=? WHERE id=?',(rev,bid))
            else:
                bid=uid();rev=1
                self.db.execute('INSERT INTO batches VALUES(?,?,?,?,?,?,?,?,?)',(bid,cy['id'],cy['next_sequence'],p['kind'],'active',d['confirmation_key'],1,now(),None))
                self.db.execute('UPDATE cycles SET next_sequence=next_sequence+1 WHERE id=?',(cy['id'],))
            fp=self._insert_revision(bid,rev,p,reason)
            self.db.execute('INSERT INTO active_import_keys VALUES(?,?,?,?)',(cy['id'],p['kind'],fp,bid))
            self.db.execute("UPDATE import_drafts SET state='committed',updated_at=? WHERE id=?",(now(),ident))
            self._touch();self._recalculate(cy['id'])
            self.audit('replace' if before else 'import','batch',bid,{'revision':before['current_revision']} if before else None,{'revision':rev},reason)
        return bid
    def _recalculate(self,cycle):
        rows=[];prev={};inputs=[];cy=self.one('SELECT * FROM cycles WHERE id=?',(cycle,));run=uid()
        for b in self.history(cycle):
            if b['state']!='active':continue
            p=self.batch_payload(b['id']);inputs.append((b['id'],b['current_revision'],p['settings_version_id']))
            current=calculate_batch(p['kind'],p['people'],prev,p['settings'])
            for x in current:prev[x['employee_id']]=x['accumulated_milli'];rows.append((b,x))
        self.db.execute('INSERT INTO calculation_runs VALUES(?,?,?,?,?,?,?,?,?)',(run,cycle,cy['data_version'],VERSION,digest(inputs),'building',now(),None,'{}'))
        cols=['previous_accumulated_milli','current_base_milli','accumulated_milli','fourfold_insurance_milli','threshold_milli','needs_withholding','calculated_tax_milli','deducted_tax_milli','nhi_milli','net_milli','explanation_json']
        for b,x in rows:self.db.execute('INSERT INTO results VALUES('+','.join('?' for _ in range(16))+')',(run,cycle,b['id'],b['current_revision'],x['employee_id'])+tuple(x[c] for c in cols))
        self.db.execute("UPDATE calculation_runs SET state='complete',completed_at=?,validation_json=? WHERE id=?",(now(),js({'rows':len(rows)}),run))
        self.db.execute('INSERT INTO cycle_publications VALUES(?,?,?) ON CONFLICT(cycle_id) DO UPDATE SET run_id=excluded.run_id,published_at=excluded.published_at',(cycle,run,now()))
        return run
    def results(self,bid=None,cycle=None):
        cycle=cycle or self.cycle()['id'];args=[cycle];extra=''
        if bid:extra=' AND r.batch_id=?';args.append(bid)
        rows=self.all('SELECT p.*,r.*,b.sequence,b.bonus_kind FROM results r JOIN cycle_publications c ON c.run_id=r.run_id JOIN batch_people p ON p.batch_id=r.batch_id AND p.revision=r.revision AND p.employee_id=r.employee_id JOIN batches b ON b.id=r.batch_id WHERE c.cycle_id=?'+extra+' ORDER BY b.sequence,p.display_order',args)
        for x in rows:x['employee_snapshot']=json.loads(x['employee_snapshot_json'])
        return rows
    def delete_batch(self,bid,reason):
        if not reason.strip():raise ValueError('請填刪除原因。')
        with self.db:
            b=self.one('SELECT * FROM batches WHERE id=?',(bid,))
            if not b or b['cycle_id']!=self.cycle()['id'] or b['state']!='active':raise ValueError('只能刪除本期有效批次。')
            self.db.execute("UPDATE batches SET state='deleted',deleted_at=? WHERE id=?",(now(),bid));self.db.execute('DELETE FROM active_import_keys WHERE batch_id=?',(bid,))
            self._touch();self._recalculate(b['cycle_id']);self.audit('delete','batch',bid,b,None,reason)
    def restore_batch(self,bid):
        with self.db:
            b=self.one('SELECT * FROM batches WHERE id=?',(bid,))
            if not b or b['cycle_id']!=self.cycle()['id'] or b['state']!='deleted':raise ValueError('只能復原本期已刪除批次。')
            if self.one("SELECT id FROM batches WHERE cycle_id=? AND bonus_kind=? AND state='active'",(b['cycle_id'],b['bonus_kind'])):raise ValueError('同種類已有有效批次，無法直接復原。')
            p=self.batch_payload(bid);self.db.execute("UPDATE batches SET state='active',deleted_at=NULL WHERE id=?",(bid,))
            self.db.execute('INSERT INTO active_import_keys VALUES(?,?,?,?)',(b['cycle_id'],b['bonus_kind'],p['normalized_source_sha256'],bid));self._touch();self._recalculate(b['cycle_id']);self.audit('restore','batch',bid,None,{'state':'active'},'使用者復原刪除')
    def backup(self,path):
        target=Path(path)
        if target.resolve()==self.path.resolve():raise ValueError('備份不可覆蓋正在使用的資料庫。')
        target.parent.mkdir(parents=True,exist_ok=True)
        with contextlib.closing(sqlite3.connect(target)) as dest:self.db.backup(dest)
        return target
    @staticmethod
    def inspect_backup(path):
        with contextlib.closing(sqlite3.connect(Path(path).resolve().as_uri()+'?mode=ro',uri=True)) as db:
            if db.execute('PRAGMA integrity_check').fetchone()[0]!='ok' or db.execute('PRAGMA foreign_key_check').fetchall():raise ValueError('備份資料庫完整性檢查失敗。')
            if db.execute('SELECT MAX(version) FROM schema_version').fetchone()[0]!=1:raise ValueError('備份版本不相容。')
            for sha,data in db.execute('SELECT sha256,bytes FROM source_files'):
                if digest(data)!=sha:raise ValueError('備份內原始檔案校驗失敗。')
            return {'cycles':db.execute('SELECT count(*) FROM cycles').fetchone()[0],'batches':db.execute('SELECT count(*) FROM batches').fetchone()[0]}
    def restore_backup(self,path,safety_path):
        self.inspect_backup(path);self.backup(safety_path)
        with contextlib.closing(sqlite3.connect(Path(path).resolve().as_uri()+'?mode=ro',uri=True)) as source:source.backup(self.db)
        self.db.execute('PRAGMA foreign_keys=ON');self.ensure_editor_storage()
        with self.db:self.audit('database_restore','database','local',None,{'source':Path(path).name},'使用者確認還原')
        self.upgrade_tax_policy()
        self.upgrade_performance_policy()
    def close_cycle(self,label,backup_path):
        if not label.strip():raise ValueError('新計算期間名稱不可空白。')
        self.backup(backup_path)
        with self.db:
            cy=self.cycle();self.db.execute("UPDATE cycles SET status='archived',closed_at=? WHERE id=?",(now(),cy['id']))
            ident=uid();self.db.execute('INSERT INTO cycles(id,label,status,opened_at) VALUES(?,?,?,?)',(ident,label,'open',now()));self.audit('close_cycle','cycle',cy['id'],cy,{'new_cycle':ident},'使用者結清並開啟新期')
