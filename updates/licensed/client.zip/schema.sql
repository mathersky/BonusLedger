-- 設計稿；僅建立結構，不含真實員工、來源資料或正式批次。
-- 金額以 1/1000 元整數保存；規則與業務計算由應用層驗證。
PRAGMA foreign_keys = ON;
BEGIN;

CREATE TABLE schema_version (
    version INTEGER PRIMARY KEY,
    applied_at TEXT NOT NULL
);

CREATE TABLE cycles (
    id TEXT PRIMARY KEY,
    label TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('open','archived')),
    next_sequence INTEGER NOT NULL DEFAULT 1 CHECK (next_sequence > 0),
    data_version INTEGER NOT NULL DEFAULT 0,
    opened_at TEXT NOT NULL,
    closed_at TEXT,
    CHECK ((status = 'open' AND closed_at IS NULL) OR
           (status = 'archived' AND closed_at IS NOT NULL))
);
CREATE UNIQUE INDEX one_open_cycle ON cycles(status) WHERE status = 'open';

CREATE TABLE employees (
    id TEXT PRIMARY KEY,
    employee_code TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    title TEXT NOT NULL DEFAULT '',
    employment_type TEXT NOT NULL CHECK (employment_type IN ('civil','contract','other')),
    active INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
    employed_on TEXT,
    left_on TEXT,
    national_id TEXT,
    bank_account TEXT,
    insurance_unit TEXT,
    default_insurance_milli INTEGER NOT NULL CHECK (default_insurance_milli >= 0),
    payout_enabled INTEGER NOT NULL DEFAULT 1 CHECK (payout_enabled IN (0,1)),
    nhi_export_enabled INTEGER NOT NULL DEFAULT 1 CHECK (nhi_export_enabled IN (0,1)),
    tax_difference_role INTEGER NOT NULL DEFAULT 0 CHECK (tax_difference_role IN (0,1)),
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE UNIQUE INDEX employee_identity_unique ON employees(national_id)
    WHERE national_id IS NOT NULL AND national_id <> '';

CREATE TABLE settings_versions (
    id TEXT PRIMARY KEY,
    version INTEGER NOT NULL UNIQUE,
    settings_json TEXT NOT NULL,
    decision_source TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE source_files (
    id TEXT PRIMARY KEY,
    sha256 TEXT NOT NULL UNIQUE CHECK (length(sha256) = 64),
    original_name TEXT NOT NULL,
    media_type TEXT NOT NULL,
    bytes BLOB NOT NULL,
    byte_length INTEGER NOT NULL CHECK (byte_length >= 0),
    created_at TEXT NOT NULL,
    CHECK (length(bytes) = byte_length)
);

CREATE TABLE import_drafts (
    id TEXT PRIMARY KEY,
    cycle_id TEXT NOT NULL REFERENCES cycles(id),
    bonus_kind TEXT NOT NULL CHECK (bonus_kind IN ('bonus1','bonus2','bonus3','bonus4','year_end','performance')),
    source_file_id TEXT REFERENCES source_files(id),
    cycle_data_version INTEGER NOT NULL,
    draft_payload_json TEXT NOT NULL,
    validation_json TEXT NOT NULL,
    state TEXT NOT NULL CHECK (state IN ('editing','ready','committed','cancelled')),
    confirmation_key TEXT NOT NULL UNIQUE,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE batches (
    id TEXT PRIMARY KEY,
    cycle_id TEXT NOT NULL REFERENCES cycles(id),
    sequence INTEGER NOT NULL CHECK (sequence > 0),
    bonus_kind TEXT NOT NULL CHECK (bonus_kind IN ('bonus1','bonus2','bonus3','bonus4','year_end','performance')),
    state TEXT NOT NULL CHECK (state IN ('active','deleted')),
    confirmation_key TEXT NOT NULL UNIQUE,
    current_revision INTEGER NOT NULL CHECK (current_revision > 0),
    created_at TEXT NOT NULL,
    deleted_at TEXT,
    UNIQUE (cycle_id, sequence),
    UNIQUE (id, cycle_id),
    FOREIGN KEY (id, current_revision) REFERENCES batch_revisions(batch_id, revision)
        DEFERRABLE INITIALLY DEFERRED,
    CHECK ((state = 'active' AND deleted_at IS NULL) OR
           (state = 'deleted' AND deleted_at IS NOT NULL))
);
-- 一期一種類一個有效正規批次；取代建立修訂，不重複新增獎金。
CREATE UNIQUE INDEX one_active_kind ON batches(cycle_id, bonus_kind) WHERE state = 'active';

CREATE TABLE batch_revisions (
    batch_id TEXT NOT NULL REFERENCES batches(id),
    revision INTEGER NOT NULL CHECK (revision > 0),
    source_file_id TEXT REFERENCES source_files(id),
    settings_version_id TEXT NOT NULL REFERENCES settings_versions(id),
    paid_on TEXT NOT NULL,
    credited_on TEXT,
    earned_period TEXT NOT NULL,
    normalized_source_sha256 TEXT NOT NULL CHECK (length(normalized_source_sha256) = 64),
    source_regions_json TEXT NOT NULL,
    metadata_json TEXT NOT NULL,
    correction_reason TEXT NOT NULL,
    created_at TEXT NOT NULL,
    PRIMARY KEY (batch_id, revision)
);

CREATE TABLE source_rows (
    id TEXT PRIMARY KEY,
    batch_id TEXT NOT NULL,
    revision INTEGER NOT NULL,
    source_sheet TEXT NOT NULL,
    source_location TEXT NOT NULL,
    region_key TEXT NOT NULL,
    raw_payload_json TEXT NOT NULL,
    employee_id TEXT REFERENCES employees(id),
    disposition TEXT NOT NULL CHECK (disposition IN ('included','historical','header','total','empty','excluded')),
    decision_reason TEXT NOT NULL,
    FOREIGN KEY (batch_id, revision) REFERENCES batch_revisions(batch_id, revision)
);

CREATE TABLE batch_people (
    batch_id TEXT NOT NULL,
    revision INTEGER NOT NULL,
    employee_id TEXT NOT NULL REFERENCES employees(id),
    display_order INTEGER NOT NULL,
    employee_snapshot_json TEXT NOT NULL,
    source_row_ids_json TEXT NOT NULL,
    gross_milli INTEGER NOT NULL CHECK (gross_milli >= 0),
    taxable_milli INTEGER NOT NULL CHECK (taxable_milli >= 0),
    accumulation_base_milli INTEGER NOT NULL CHECK (accumulation_base_milli >= 0),
    net_base_mode TEXT NOT NULL CHECK (net_base_mode IN ('gross','taxable')),
    insurance_milli INTEGER NOT NULL CHECK (insurance_milli >= 0),
    insurance_change_reason TEXT NOT NULL DEFAULT '',
    input_method TEXT NOT NULL CHECK (input_method IN ('file','manual','mixed')),
    input_explanation TEXT NOT NULL,
    payout_enabled INTEGER NOT NULL CHECK (payout_enabled IN (0,1)),
    nhi_export_enabled INTEGER NOT NULL CHECK (nhi_export_enabled IN (0,1)),
    tax_difference_role INTEGER NOT NULL CHECK (tax_difference_role IN (0,1)),
    PRIMARY KEY (batch_id, revision, employee_id),
    FOREIGN KEY (batch_id, revision) REFERENCES batch_revisions(batch_id, revision)
);

CREATE TABLE calculation_runs (
    id TEXT PRIMARY KEY,
    cycle_id TEXT NOT NULL REFERENCES cycles(id),
    cycle_data_version INTEGER NOT NULL,
    engine_version TEXT NOT NULL,
    input_sha256 TEXT NOT NULL CHECK (length(input_sha256) = 64),
    state TEXT NOT NULL CHECK (state IN ('building','complete','failed')),
    started_at TEXT NOT NULL,
    completed_at TEXT,
    validation_json TEXT NOT NULL,
    UNIQUE (id, cycle_id)
);

CREATE TABLE results (
    run_id TEXT NOT NULL,
    cycle_id TEXT NOT NULL,
    batch_id TEXT NOT NULL,
    revision INTEGER NOT NULL,
    employee_id TEXT NOT NULL,
    previous_accumulated_milli INTEGER NOT NULL CHECK (previous_accumulated_milli >= 0),
    current_base_milli INTEGER NOT NULL CHECK (current_base_milli >= 0),
    accumulated_milli INTEGER NOT NULL CHECK (accumulated_milli >= 0),
    fourfold_insurance_milli INTEGER NOT NULL CHECK (fourfold_insurance_milli >= 0),
    threshold_milli INTEGER NOT NULL CHECK (threshold_milli >= 0),
    needs_withholding INTEGER NOT NULL CHECK (needs_withholding IN (0,1)),
    calculated_tax_milli INTEGER NOT NULL CHECK (calculated_tax_milli >= 0),
    deducted_tax_milli INTEGER NOT NULL CHECK (deducted_tax_milli >= 0),
    nhi_milli INTEGER NOT NULL CHECK (nhi_milli >= 0 AND nhi_milli % 1000 = 0),
    net_milli INTEGER NOT NULL,
    explanation_json TEXT NOT NULL,
    PRIMARY KEY (run_id, batch_id, employee_id),
    FOREIGN KEY (run_id, cycle_id) REFERENCES calculation_runs(id, cycle_id),
    FOREIGN KEY (batch_id, cycle_id) REFERENCES batches(id, cycle_id),
    FOREIGN KEY (batch_id, revision, employee_id)
        REFERENCES batch_people(batch_id, revision, employee_id),
    CHECK (accumulated_milli = previous_accumulated_milli + current_base_milli)
);

CREATE TABLE cycle_publications (
    cycle_id TEXT PRIMARY KEY REFERENCES cycles(id),
    run_id TEXT NOT NULL,
    published_at TEXT NOT NULL,
    FOREIGN KEY (run_id, cycle_id) REFERENCES calculation_runs(id, cycle_id)
);
CREATE TRIGGER publish_completed_results_insert
BEFORE INSERT ON cycle_publications
WHEN (SELECT state FROM calculation_runs WHERE id = NEW.run_id) <> 'complete'
BEGIN
    SELECT RAISE(ABORT, 'Cannot publish incomplete calculation results');
END;
CREATE TRIGGER publish_completed_results_update
BEFORE UPDATE ON cycle_publications
WHEN (SELECT state FROM calculation_runs WHERE id = NEW.run_id) <> 'complete'
BEGIN
    SELECT RAISE(ABORT, 'Cannot publish incomplete calculation results');
END;

CREATE TABLE active_import_keys (
    cycle_id TEXT NOT NULL,
    bonus_kind TEXT NOT NULL,
    normalized_source_sha256 TEXT NOT NULL CHECK (length(normalized_source_sha256) = 64),
    batch_id TEXT NOT NULL UNIQUE,
    PRIMARY KEY (cycle_id, bonus_kind, normalized_source_sha256),
    FOREIGN KEY (batch_id, cycle_id) REFERENCES batches(id, cycle_id)
);

CREATE TABLE audit_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    happened_at TEXT NOT NULL,
    action TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    before_json TEXT,
    after_json TEXT,
    reason TEXT NOT NULL
);

CREATE TABLE export_jobs (
    id TEXT PRIMARY KEY,
    run_id TEXT NOT NULL REFERENCES calculation_runs(id),
    scope_json TEXT NOT NULL,
    template_sha256 TEXT NOT NULL CHECK (length(template_sha256) = 64),
    file_name TEXT NOT NULL,
    output_sha256 TEXT NOT NULL CHECK (length(output_sha256) = 64),
    created_at TEXT NOT NULL
);

CREATE INDEX source_rows_revision ON source_rows(batch_id, revision);
CREATE INDEX results_employee ON results(run_id, employee_id);
CREATE INDEX history_by_cycle ON batches(cycle_id, sequence);
CREATE INDEX audit_entity ON audit_events(entity_type, entity_id, id);

INSERT INTO schema_version VALUES (1, strftime('%Y-%m-%dT%H:%M:%fZ','now'));
COMMIT;
