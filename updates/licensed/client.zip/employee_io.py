"""Round-trip employee master data with a validated, atomic import preview."""
import csv
import io
import re
import unicodedata
from itertools import islice
from decimal import Decimal, InvalidOperation
from datetime import date, datetime
from pathlib import Path
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
from core import digest, milli, money, uid, valid_date

FIELDS = [
    ('員工代碼','employee_code'),('姓名','name'),('職稱','title'),
    ('身分','employment_type'),('在職／啟用','active'),
    ('預設投保額','default_insurance_milli'),('收款帳號','bank_account'),
    ('身分證字號','national_id'),('投保單位代號','insurance_unit'),
    ('到職日期','employed_on'),('退休(離職)日期','left_on'),
    ('列入農會撥款','payout_enabled'),('列入健保申報','nhi_export_enabled'),
    ('醫師差額扣稅人員','tax_difference_role')]
HEADERS = [h for h,k in FIELDS]
FLAGS = {'active','payout_enabled','nhi_export_enabled','tax_difference_role'}
TYPES = {'公職':'civil','勞工':'contract','約聘':'contract','其他':'other',
         'civil':'civil','contract':'contract','other':'other'}
IDENTIFIERS = {'employee_code','bank_account','national_id','insurance_unit'}

def normalize(value):
    return unicodedata.normalize('NFKC',str('' if value is None else value)).replace('\ufeff','').replace('\u200b','').strip()

def header_key(value):
    return re.sub(r'[\s／/()（）_－-]+','',normalize(value)).lower()

ALIASES = {
    '員工代碼':['員工編號','員工編碼','代碼','人員編號','工號','employee_code','employee id'],
    '姓名':['員工姓名','名字','name'], '職稱':['職務','職位','title'],
    '身分':['身份','員工身分','員工身份','身分類別','身份別','employment_type'],
    '在職／啟用':['在職','啟用','在職狀態','是否在職','active'],
    '預設投保額':['投保額','投保金額','投保薪資','月投保金額','預設投保金額'],
    '收款帳號':['匯款帳號','銀行帳號','農會帳號','帳號','bank_account'],
    '身分證字號':['身份證字號','身分證號','身份證號','身分證','national_id'],
    '投保單位代號':['投保單位','健保單位代號','insurance_unit'],
    '到職日期':['到職日','入職日期','到任日期','employed_on'],
    '退休(離職)日期':['退休日期','離職日期','離職日','退職日期','left_on'],
    '列入農會撥款':['農會撥款','是否撥款','列入撥款','payout_enabled'],
    '列入健保申報':['健保申報','是否申報健保','nhi_export_enabled'],
    '醫師差額扣稅人員':['醫師差額扣稅','差額扣稅人員','tax_difference_role']}
HEADER_MAP={header_key(alias):h for h in HEADERS for alias in [h]+ALIASES[h]}

def date_text(value):
    text=normalize(value)
    if not text:return None
    text=re.sub(r'^(民國|西元)','',text)
    text=re.sub(r'[年/.]','-',text).replace('月','-').replace('日','')
    if re.fullmatch(r'\d{7,8}',text):text=f'{text[:-4]}-{text[-4:-2]}-{text[-2:]}'
    match=re.fullmatch(r'(\d{2,4})-(\d{1,2})-(\d{1,2})(?:[ T]00:00:00)?',text)
    if not match:raise ValueError('日期請用西元或民國年/月/日，例如2026/9/23或115/9/23。')
    y,m,d=map(int,match.groups())
    if y<1911 and len(match[1])<=3:y+=1911
    return valid_date(f'{y:04d}-{m:02d}-{d:02d}')

def identifier_text(value,field,warnings,rowno):
    text=normalize(value)
    if not text:return ''
    if isinstance(value,bool):raise ValueError('代碼／帳號不能是布林值。')
    if isinstance(value,(int,float)):
        number=Decimal(str(value))
        if not number.is_finite() or number<0 or number!=number.to_integral_value():raise ValueError('代碼／帳號須為非負整數或文字。')
        text=format(number,'f').split('.')[0]
        if len(text)>15:raise ValueError('Excel數字代碼／帳號超過15位可能已失真，請改用原始文字資料。')
        warnings.append(f'第{rowno}列 {field}：數字已轉文字「{text}」，請核對是否缺少開頭的0。')
    elif re.fullmatch(r"'?\d+\.0+",text):
        text=text.lstrip("'").split('.')[0]
    elif text.startswith("'") and re.fullmatch(r'[A-Za-z0-9]+',text[1:]):text=text[1:]
    elif re.fullmatch(r'\d+(?:\.\d+)?[eE][+]?[0-9]+',text):
        number=Decimal(text)
        if number.adjusted()>40 or number!=number.to_integral_value():raise ValueError('代碼科學記號不正確。')
        text=format(number,'f');warnings.append(f'第{rowno}列 {field}：科學記號轉為「{text}」，請核對原始位數。')
    if field in {'收款帳號','投保單位代號'} and re.fullmatch(r'\d+(?:[ -]+\d+)+',text):text=re.sub(r'[ -]+','',text)
    if field=='身分證字號':text=re.sub(r'\s+','',text).upper()
    return text


def display_employee(e):
    values=[]
    for h,k in FIELDS:
        v=e.get(k)
        if k in FLAGS:v='V' if v else ''
        elif k=='employment_type':v={'civil':'公職','contract':'勞工','other':'其他'}[v]
        elif k=='default_insurance_milli':v=money(v).replace(',','')
        values.append('' if v is None else str(v))
    return values

def export_employees(store,path):
    path=Path(path)
    rows=[display_employee(e) for e in store.employees()]
    if path.suffix.lower()=='.csv':
        with path.open('w',encoding='utf-8-sig',newline='') as f:
            writer=csv.writer(f);writer.writerow(HEADERS)
            # Prevent spreadsheet formula execution while allowing our CSV round-trip.
            writer.writerows([["'"+v if v.startswith(('=', '+', '-', '@', "'", '\t', '\r', '\n')) else v for v in row] for row in rows])
    elif path.suffix.lower()=='.xlsx':
        wb=openpyxl.Workbook();ws=wb.active;ws.title='員工資料'
        ws.append(HEADERS)
        for row in rows:ws.append(row)
        for row in ws:
            for c in row:
                c.data_type='s';c.number_format='@'
                c.font=Font(name='Microsoft JhengHei',size=11)
                c.alignment=Alignment(vertical='center')
        for c in ws[1]:
            c.font=Font(name='Microsoft JhengHei',size=11,bold=True,color='FFFFFF')
            c.fill=PatternFill('solid',fgColor='174B66')
        for i,(h,k) in enumerate(FIELDS,1):
            ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width=24 if k in IDENTIFIERS else 20
        ws.freeze_panes='C2';ws.auto_filter.ref=ws.dimensions;ws.row_dimensions[1].height=30
        help_sheet=wb.create_sheet('填寫說明')
        for line in [
            '請保留員工資料工作表與全部表頭；每列一位員工。',
            '新增：員工代碼留空自動編號，或填入未使用的代碼；更新：保留現有員工代碼。',
            '身分可填公職、勞工、約聘等；V、勾號、是或1表示勾選，空白或0表示未勾選。',
            '預設投保額填非負金額，最多三位小數；日期可填西元或民國年/月/日。',
            '更新會使用該列全部欄位，空白可清除原欄位；未列入的員工不會刪除。',
            '帳號可為文字或數字；Excel補零格式會保留，普通數字會提示核對開頭的0。',
            '姓名不可空白；身分證字號可留空待補，填寫時須10碼且不可重複。',
            '新增人員後重新開啟匯入作業；已保存批次與草稿保留原有人員快照。',
            '建議使用xlsx；CSV請以文字方式匯入Excel，避免Excel自動改變帳號。']:
            help_sheet.append([line])
        help_sheet.column_dimensions['A'].width=115
        wb.save(path);wb.close()
    else:raise ValueError('請使用 .xlsx 或 .csv 格式。')
    return len(rows)

def read_rows(path):
    path=Path(path)
    if path.stat().st_size>50*1024*1024:raise ValueError('檔案不可超過50MB。')
    if path.suffix.lower()=='.csv':
        data=path.read_bytes()
        try:text=data.decode('utf-16') if data.startswith((b'\xff\xfe',b'\xfe\xff')) else data.decode('utf-8-sig')
        except UnicodeDecodeError:
            try:text=data.decode('cp950')
            except UnicodeDecodeError:raise ValueError('CSV請存成UTF-8或繁體中文Big5編碼。')
        # Title rows can have a different field count, which confuses Sniffer.
        scores={sep:max([sum(header_key(v) in HEADER_MAP for v in row) for row in islice(csv.reader(io.StringIO(text),delimiter=sep),20)]+[0]) for sep in [',',';','\t']}
        if max(scores.values())>=3:delimiter=max(scores,key=scores.get)
        else:
            try:delimiter=csv.Sniffer().sniff(text[:8192],delimiters=',;\t').delimiter
            except csv.Error:delimiter=','
        rows=list(csv.reader(io.StringIO(text),delimiter=delimiter))
        rows=[[v[1:] if len(v)>1 and v[0]=="'" and v[1] in "=+-@'\t\r\n" else v for v in row] for row in rows]
    elif path.suffix.lower()=='.xlsx':
        wb=openpyxl.load_workbook(path,read_only=True,data_only=False)
        try:
            ws=wb['員工資料'] if '員工資料' in wb.sheetnames else wb.worksheets[0]
            if ws.max_row and ws.max_row>10001:raise ValueError('單次最多匯入10000位員工，請移除多餘空白列。')
            rows=[]
            for row in ws:
                if any(c.data_type=='f' for c in row):raise ValueError('員工資料不可含公式，請貼上為值後匯入。')
                values=[]
                for c in row:
                    v=c.value
                    if isinstance(v,(int,float)) and not isinstance(v,bool) and v>=0 and float(v).is_integer() and re.fullmatch(r'0{2,15}',c.number_format):
                        v=str(int(v)).zfill(len(c.number_format))
                    values.append(v)
                rows.append(values)
        finally:wb.close()
    else:raise ValueError('僅支援.xlsx與.csv；舊版.xls請先另存成.xlsx。')
    if not rows:raise ValueError('檔案沒有資料。')
    if len(rows)>10001:raise ValueError('單次最多匯入10000位員工。')
    return rows

def preview_employees(store,path):
    rows=read_rows(path);header_index=0
    for i,row in enumerate(rows[:20]):
        mapped=[HEADER_MAP.get(header_key(v),normalize(v)) for v in row]
        if '姓名' in mapped and '員工代碼' in mapped:header_index=i;break
    headers=[HEADER_MAP.get(header_key(v),normalize(v)) for v in rows[header_index]]
    missing=[h for h in HEADERS if h not in headers]
    if missing:raise ValueError('缺少欄位：'+ '、'.join(missing)+'。請先匯出員工資料作為範本。')
    if any(headers.count(h)!=1 for h in HEADERS):raise ValueError('表頭不可重複。')
    existing=store.employees();by_code={e['employee_code']:e for e in existing}
    reserved=set(by_code);seen=set();people=[];errors=[];warnings=[]
    known_names={e['name'].strip() for e in existing};next_code=1
    # Reserve supplied codes before generating numbers for blank codes.
    ci=headers.index('員工代碼')
    reserved.update(identifier_text(row[ci],'員工代碼',[],i) for i,row in enumerate(rows[header_index+1:],header_index+2) if len(row)>ci and row[ci] is not None)
    for rowno,row in enumerate(rows[header_index+1:],header_index+2):
        if not any(v is not None and str(v).strip() for v in row):continue
        try:
            e={}
            for h,k in FIELDS:
                idx=headers.index(h);v=row[idx] if idx<len(row) else None
                if k in IDENTIFIERS:v=identifier_text(v,h,warnings,rowno)
                if isinstance(v,(date,datetime)):v=v.strftime('%Y-%m-%d')
                text=normalize(v) if k not in {'name','title'} else ('' if v is None else str(v).strip())
                if k in FLAGS:
                    if text.upper() in {'V','✓','✔','☑','√','1','1.0','TRUE','YES','Y','是','在職','啟用','有','已勾選','勾選','X'}:v=1
                    elif text.upper() in {'','0','0.0','FALSE','NO','N','否','離職','停用','無','未勾選','□','☐','退休'}:v=0
                    else:raise ValueError(h+'無法辨識，請填V或留空。')
                    if text.upper()=='X':warnings.append(f'第{rowno}列 {h}：X按已勾選解讀，請確認。')
                elif k=='default_insurance_milli':
                    text=re.sub(r'^(NT\$|NTD|TWD|新台幣|新臺幣|\$)','',text,flags=re.I).removesuffix('元')
                    v=milli(re.sub(r'[\s,]','',text) or '0')
                elif k=='employment_type':
                    text={'公務人員':'公職','公務員':'公職','約聘人員':'勞工','約僱人員':'勞工','約僱':'勞工','勞工人員':'勞工'}.get(text,text.lower())
                    if text not in TYPES:raise ValueError('身分請填公職、勞工或其他。')
                    v=TYPES[text]
                elif k in {'employed_on','left_on'}:v=date_text(text)
                else:v=text
                e[k]=v
            if not e['name']:raise ValueError('姓名不可空白。')
            if e['national_id'] and len(e['national_id'])!=10:raise ValueError('身分證字號須10碼，或留空待補。')
            if e['employed_on'] and e['left_on'] and e['left_on']<e['employed_on']:raise ValueError('退休(離職)日期不可早於到職日期。')
            code=e['employee_code']
            if not code:
                if e['name'] in known_names:raise ValueError('已有同名員工，更新請填原員工代碼；確為不同人請指定新的員工代碼。')
                while f'E{next_code:03d}' in reserved:next_code+=1
                code=e['employee_code']=f'E{next_code:03d}';reserved.add(code)
            if code in seen:raise ValueError('檔案中員工代碼重複：'+code)
            seen.add(code);old=by_code.get(code)
            e['id']=old['id'] if old else uid()
            people.append({'row':rowno,'action':'更新' if old else '新增','employee':e});known_names.add(e['name'])
        except ValueError as exc:errors.append(f'第{rowno}列：{exc}')
    identities={e['national_id']:e['employee_code'] for e in existing if e.get('national_id')}
    # Require a code for existing identities; never merge people by name.
    for item in people:
        e=item['employee'];nid=e['national_id'];code=e['employee_code']
        if nid and nid in identities and identities[nid]!=code:
            errors.append(f"第{item['row']}列：身分證字號已由員工代碼{identities[nid]}使用；更新請保留原員工代碼。")
        elif nid:identities[nid]=code
    final={e['employee_code']:e for e in existing}
    final.update({x['employee']['employee_code']:x['employee'] for x in people})
    if sum(e['active'] and e['tax_difference_role'] for e in final.values())>1:
        errors.append('在職醫師差額扣稅人員最多一位，請先取消其他人員的勾選。')
    if errors:raise ValueError('\n'.join(errors[:30])+ ('\n其餘錯誤請修正後再檢查。' if len(errors)>30 else ''))
    if not people:raise ValueError('沒有可匯入的員工。')
    return {'people':people,'baseline':digest(existing),'filename':Path(path).name,'sha256':digest(Path(path).read_bytes()),'warnings':warnings}

def commit_employees(store,preview):
    if digest(store.employees())!=preview['baseline']:raise ValueError('員工資料已變動，請重新匯入並預覽。')
    backup=store.path.parent/'backups'/('員工批次匯入前_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.sqlite')
    store.backup(backup)
    with store.db:
        store.db.execute('BEGIN IMMEDIATE')
        if digest(store.employees())!=preview['baseline']:raise ValueError('員工資料已變動，請重新預覽。')
        for item in preview['people']:store._save_employee(item['employee'])
        store._touch()
        store.audit('employees_import','employees','bulk',None,{'file':preview['filename'],'sha256':preview['sha256'],'count':len(preview['people']),'normalization_warnings':preview.get('warnings',[]),'backup':str(backup)},'使用者確認批次匯入；已保存批次快照不變')
    return backup
