# Python 版維護說明

此發行包以 Python 原始碼執行，不使用 PyInstaller 或 EXE。

- 建議環境：Windows 64 位元、Python 3.12（含 tkinter）。
- 相依套件：`requirements.txt`（目前為 `openpyxl==3.1.5`）。
- 一般使用者雙擊 `SETUP安裝軟體.bat`。啟動程式會在 `%LOCALAPPDATA%\BonusLedger\python_env_1_7_1` 建立專用環境，檢查 `requirements.txt` 中的每一項套件與版本，缺少或不符時使用 pip 安裝。
- 手動開發可建立虛擬環境、安裝 `requirements.txt`，再執行 `python app.py`。
- 測試資料請將 `BONUS_LEDGER_DATA` 指向獨立目錄，不要連到正式 `%LOCALAPPDATA%\BonusLedger`。
- 資源必須與 `app.py` 同層：`schema.sql`、`seed.json`、`template.xlsx`、`references`。
- 資料庫 `schema_version=1`。更改資料結構時必須增加遷移程序，不可直接覆蓋使用者資料庫。

金額採千分之一元整數及 Decimal 計算。首次建立資料庫會匯入 `seed.json` 的初始員工與預設設定；既有資料庫不會重新載入名冊。
