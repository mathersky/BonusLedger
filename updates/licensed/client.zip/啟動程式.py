"""Windows launcher: build a per-user environment and install missing packages."""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path
from update_service import ensure_startup_assets


ROOT = Path(__file__).resolve().parent
LOCAL = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
ENV = LOCAL / "BonusLedger" / "python_env_1_7_1"
REQUIREMENTS = ROOT / "requirements.txt"
SETUP_LOG = ENV.parent / "setup_error.log"

CHECK_REQUIREMENTS = """
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
import re, sys
for raw in Path(sys.argv[1]).read_text(encoding='utf-8').splitlines():
    line = raw.partition('#')[0].strip()
    if not line:
        continue
    match = re.fullmatch(r'([A-Za-z0-9_.-]+)==([A-Za-z0-9_.+-]+)', line)
    if not match:
        raise SystemExit(2)
    try:
        actual = version(match.group(1))
    except PackageNotFoundError:
        raise SystemExit(1)
    if actual != match.group(2):
        raise SystemExit(1)
"""


def report(message: str) -> None:
    try:
        import tkinter as tk
        from tkinter import messagebox

        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("獎勵金計算系統", message)
        root.destroy()
    except Exception:
        print(message, file=sys.stderr)


def interpreter() -> str:
    if os.name != "nt":
        raise RuntimeError("此版本供 Windows 使用。")
    if sys.version_info < (3, 10):
        raise RuntimeError(
            "需要 Python 3.10 以上（建議 Python 3.12，並包含 Tcl/Tk）。\n"
            "請安裝 Python 後重新點選「SETUP安裝軟體.bat」。"
        )
    try:
        import tkinter  # noqa: F401
    except Exception as exc:
        raise RuntimeError(
            "目前的 Python 未包含 Tkinter 圖形介面元件。\n"
            "請重新安裝 Windows 版 Python，並保留 Tcl/Tk 選項。"
        ) from exc
    return sys.executable


def requirements_ok(python: Path) -> bool:
    result = subprocess.run(
        [str(python), "-c", CHECK_REQUIREMENTS, str(REQUIREMENTS)],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    if result.returncode == 2:
        raise RuntimeError("requirements.txt 格式錯誤；請保留套件名稱==版本的格式。")
    return result.returncode == 0


def locked_setup() -> Path:
    """Serialize first-run setup and repair an incomplete virtual environment."""
    ENV.parent.mkdir(parents=True, exist_ok=True)
    lock_path = ENV.parent / "python_setup.lock"
    with lock_path.open("a+b") as lock:
        if lock_path.stat().st_size == 0:
            lock.write(b"0")
            lock.flush()
        lock.seek(0)
        import msvcrt
        msvcrt.locking(lock.fileno(), msvcrt.LK_LOCK, 1)
        try:
            python = ENV / "Scripts" / "python.exe"
            pythonw = ENV / "Scripts" / "pythonw.exe"
            if not python.exists():
                subprocess.run([interpreter(), "-m", "venv", str(ENV)], check=True)
            try:
                if not requirements_ok(python):
                    result = subprocess.run(
                        [str(python), "-m", "pip", "install", "--disable-pip-version-check", "-r", str(REQUIREMENTS)],
                        capture_output=True,
                        text=True,
                        encoding="utf-8",
                        errors="replace",
                    )
                    if result.returncode:
                        detail = (result.stderr or result.stdout or "pip 未提供錯誤內容").strip()
                        SETUP_LOG.write_text(detail + "\n", encoding="utf-8")
                        raise RuntimeError(
                            "自動安裝缺少的 Python 套件失敗。請確認網路連線後重新啟動。\n"
                            f"詳細錯誤：{SETUP_LOG}\n\n{detail[-1400:]}"
                        )
                if not requirements_ok(python):
                    raise RuntimeError("套件安裝後仍未通過版本檢查；請重新啟動，或查看 setup_error.log。")
            except OSError:
                shutil.rmtree(ENV, ignore_errors=True)
                subprocess.run([interpreter(), "-m", "venv", str(ENV)], check=True)
                python = ENV / "Scripts" / "python.exe"
                result = subprocess.run(
                    [str(python), "-m", "pip", "install", "--disable-pip-version-check", "-r", str(REQUIREMENTS)],
                    capture_output=True,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                )
                if result.returncode:
                    detail = (result.stderr or result.stdout or "pip 未提供錯誤內容").strip()
                    SETUP_LOG.write_text(detail + "\n", encoding="utf-8")
                    raise RuntimeError(f"Python 環境修復失敗，請查看：{SETUP_LOG}\n\n{detail[-1400:]}")
            if not pythonw.exists():
                raise RuntimeError("Python 圖形啟動程式 pythonw.exe 不存在，請修復 Python 安裝後再試。")
            return pythonw
        finally:
            lock.seek(0)
            msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)


def main() -> int:
    try:
        interpreter()
        pythonw = locked_setup()
        ensure_startup_assets(ROOT)
        subprocess.Popen([str(pythonw), str(ROOT / "app.py")], cwd=ROOT)
        return 0
    except subprocess.CalledProcessError as exc:
        report(f"Python 環境建立失敗（錯誤代碼 {exc.returncode}）。請修復 Python 後重新啟動。")
        return exc.returncode or 1
    except Exception as exc:
        report(str(exc))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
