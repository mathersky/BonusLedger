"""Wait for the client to exit, replace only application files, then restart it."""
from __future__ import annotations

import ctypes
import os
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path
from tkinter import Tk, messagebox

ALLOWED = {
    "app.py", "core.py", "employee_io.py", "excel_io.py", "update_service.py", "update_runner.py", "license_guard.py", "LICENSE",
    "schema.sql", "seed.json", "template.xlsx", "requirements.txt", "啟動程式.py",
    "SETUP安裝軟體.bat", "啟動獎勵金系統.bat", "BonusLedger.ico", "README_Python版.md", "操作說明_獎勵金計算系統.md", "BUILD.md",
}
REQUIRED = {"app.py", "core.py", "employee_io.py", "excel_io.py", "update_service.py", "update_runner.py"}


def wait_for_process(pid: int) -> None:
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.OpenProcess.argtypes = [ctypes.c_uint32, ctypes.c_int, ctypes.c_uint32]
    kernel.OpenProcess.restype = ctypes.c_void_p
    kernel.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
    kernel.WaitForSingleObject.restype = ctypes.c_uint32
    kernel.CloseHandle.argtypes = [ctypes.c_void_p]
    kernel.CloseHandle.restype = ctypes.c_int
    handle = kernel.OpenProcess(0x00100000, False, pid)  # SYNCHRONIZE
    if not handle:
        return
    try:
        result = kernel.WaitForSingleObject(handle, 30000)
        if result != 0:
            raise RuntimeError("程式尚未關閉，更新已取消。")
    finally:
        kernel.CloseHandle(handle)


def install(archive_path: Path, app_dir: Path) -> None:
    update_root = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local")) / "BonusLedger" / "updates"
    update_root.mkdir(parents=True, exist_ok=True)
    stage = Path(tempfile.mkdtemp(prefix="stage_", dir=update_root))
    backup = update_root / ("backup_" + str(time.time_ns()))
    backup.mkdir()
    staged_names = set()
    try:
        with zipfile.ZipFile(archive_path) as z:
            total = 0
            for item in z.infolist():
                if item.is_dir():
                    continue
                path = Path(item.filename)
                if path.is_absolute() or ".." in path.parts or len(path.parts) != 1 or path.name not in ALLOWED:
                    raise RuntimeError("更新包含有不允許的檔案路徑，已停止更新。")
                total += item.file_size
                if total > 250 * 1024 * 1024:
                    raise RuntimeError("更新包解壓縮後過大，已停止更新。")
                destination = stage / path.name
                destination.write_bytes(z.read(item))
                staged_names.add(path.name)
        if not REQUIRED.issubset(staged_names):
            raise RuntimeError("更新包缺少必要程式檔，已停止更新。")
        python = Path(sys.executable).with_name("python.exe")
        if not python.exists():
            python = Path(sys.executable)
        check = subprocess.run([str(python), "-m", "py_compile", *[str(stage / n) for n in REQUIRED]], capture_output=True)
        if check.returncode:
            raise RuntimeError("更新程式檔語法檢查失敗，原版本保持不變。")
        installed = []
        try:
            for name in sorted(staged_names):
                destination = app_dir / name
                if destination.exists():
                    shutil.copy2(destination, backup / name)
                temporary = destination.with_name(destination.name + ".update.tmp")
                shutil.copy2(stage / name, temporary)
                os.replace(temporary, destination)
                installed.append(name)
        except Exception:
            for name in reversed(installed):
                old = backup / name
                destination = app_dir / name
                if old.exists():
                    os.replace(old, destination)
                elif destination.exists():
                    destination.unlink()
            raise
    finally:
        shutil.rmtree(stage, ignore_errors=True)


def notify(title: str, message: str) -> None:
    root = Tk()
    root.withdraw()
    messagebox.showinfo(title, message)
    root.destroy()


def main() -> int:
    if len(sys.argv) != 4:
        return 2
    archive_path, app_dir, parent_pid = Path(sys.argv[1]), Path(sys.argv[2]), int(sys.argv[3])
    try:
        wait_for_process(parent_pid)
        install(archive_path, app_dir)
        subprocess.Popen([sys.executable, str(app_dir / "app.py")], cwd=app_dir)
        return 0
    except Exception as exc:
        notify("更新未完成", f"原程式資料保留。請重新開啟程式後手動檢查更新。\n\n{exc}")
        try:
            subprocess.Popen([sys.executable, str(app_dir / "app.py")], cwd=app_dir)
        except Exception:
            pass
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
