"""Workbook import adapters and value-only template export for the desktop application."""
from copy import copy
from decimal import Decimal, ROUND_HALF_UP
from io import BytesIO
from pathlib import Path
import json
import re
import zipfile
from functools import lru_cache
from xml.etree import ElementTree as ET
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.cell.cell import MergedCell
from core import KINDS,SHEETS,milli,numeric,js,digest,uid,now,summary

MAX_FILE=50*1024*1024
def text(v):return '' if v is None else str(v).strip()
def id_text(v):return str(int(v)) if isinstance(v,(int,float)) else text(v)

class Source:
    def __init__(self,path):
        self.path=Path(path)
        if self.path.suffix.lower()!='.xlsx':raise ValueError('請選擇 .xlsx 檔案；舊版 .xls 請先另存為 .xlsx。')
        if self.path.stat().st_size>MAX_FILE:raise ValueError('檔案超過 50 MB，請只提供本次來源資料。')
        with zipfile.ZipFile(self.path) as z:
            if sum(x.file_size for x in z.infolist())>250*1024*1024:raise ValueError('Excel 解壓縮內容過大。')
        self.values=openpyxl.load_workbook(path,data_only=True)
        self.formulas=openpyxl.load_workbook(path,data_only=False)
    def value(self,sheet,row,col):
        c=self.values[sheet].cell(row,col);f=self.formulas[sheet].cell(row,col)
        if f.data_type=='f' and c.value is None:raise ValueError(f'{sheet}!{c.coordinate} 公式缺少計算值，請在 Excel 計算並存檔。')
        if c.data_type=='e':raise ValueError(f'{sheet}!{c.coordinate} 為錯誤值 {c.value}。')
        return c.value
    def amount(self,sheet,row,col):
        v=self.value(sheet,row,col)
        if v is None or v=='':return 0
        return milli(v)
    def parse(self,kind,sheet=None):
        sheet=sheet or KINDS[kind]
        if sheet not in self.values.sheetnames:raise ValueError('找不到所選工作表。')
        s=self.values[sheet]; records=[];regions=[];raw=[]
        # Flat input format, explicit headers rather than guessing an amount column.
        flat=None
        for row in s.iter_rows(max_row=min(s.max_row,30),max_col=min(s.max_column,50)):
            h={text(c.value):c.column for c in row if c.value is not None}
            if '應發金額' in h and '未扣稅金額' not in h:h['未扣稅金額']=h['應發金額']
            if '姓名' in h and '未扣稅金額' in h:flat=(row[0].row,h);break
        if flat:
            hr,h=flat
            for r in range(hr+1,min(s.max_row,10000)+1):
                name=text(self.value(sheet,r,h['姓名']))
                if not name or name in ('合計','總計'):continue
                gross=self.amount(sheet,r,h['未扣稅金額']);allowance=self.amount(sheet,r,h['主管加給']) if '主管加給' in h and not kind.startswith('bonus') else 0
                if allowance>gross:raise ValueError(f'{sheet} 第 {r} 列主管加給不可超過未扣稅金額。')
                tax=gross-allowance
                rec={'name':name,'code':text(self.value(sheet,r,h['員工代碼'])) if '員工代碼' in h else '',
                     'gross_milli':gross,'taxable_milli':tax,'region':'current','source_sheet':sheet,'source_location':str(r),
                     'components':[gross,0,0,0,0,0]}
                records.append(rec);raw.append(self.raw_record(sheet,r,1,min(s.max_column,50),'current'))
            regions=[{'key':'current','label':'本次已核定明細','amount_milli':sum(x['gross_milli'] for x in records),'status':'included'}]
        elif kind.startswith('bonus'):
            blocks=[('current1',2,5,3,False),('current2',9,12,4,False),('current3',16,19,5,False),
                    ('previous1',23,26,0,True),('previous2',30,33,1,True),('previous3',37,40,2,True)]
            found=0
            for key,nc,ac,component,old in blocks:
                headers=[r for r in range(1,min(s.max_row,100)+1) if text(s.cell(r,nc).value)=='姓名' and text(s.cell(r,ac).value) in ('合計','應發金額','未扣稅金額','金額')]
                if len(headers)>1:raise ValueError(f'{sheet} 的姓名欄出現多個表頭，請整理為一區一個表頭。')
                if not headers:continue
                found+=1;start=headers[0]+1;total=0
                for r in range(start,min(s.max_row,10000)+1):
                    name=text(self.value(sheet,r,nc));title=text(s.cell(r,nc-1).value)
                    if name in ('合計','總計') or title in ('合計','總計'):break
                    if not name:continue
                    val=self.amount(sheet,r,ac);total+=val;comps=[0]*6;comps[component]=val
                    records.append({'name':name,'code':'','gross_milli':val,'taxable_milli':val,'region':key,
                                    'source_sheet':sheet,'source_location':f'{openpyxl.utils.get_column_letter(ac)}{r}','components':comps})
                    raw.append(self.raw_record(sheet,r,nc-1,ac+1,key))
                label=f'{"前期" if old else "本次"}區 {openpyxl.utils.get_column_letter(nc-1)}:{openpyxl.utils.get_column_letter(ac+1)}'
                regions.append({'key':key,'label':label,'amount_milli':total,'status':'included'})
            if not found:raise ValueError('找不到姓名／合計欄。請使用原來源表，或「姓名、應發金額、報稅金額」簡式表頭。')
        else:
            if text(s['B3'].value)!='姓名' or text(s['D4'].value)!='薪餉' or text(s['E4'].value)!='專業加級':
                raise ValueError('年終／考績來源缺少 B3 姓名、D4 薪餉、E4 專業加級；請使用原格式或簡式表。')
            for r in range(5,min(s.max_row,10000)+1):
                name=text(self.value(sheet,r,2));title=text(s.cell(r,1).value)
                if name in ('合計','總計') or title in ('合計','總計'):break
                if not name:continue
                if any(x in name for x in ('人事','會計','機關','出納')):continue
                gross=self.amount(sheet,r,9)
                salary=self.amount(sheet,r,4);professional=self.amount(sheet,r,5)
                months=Decimal(str(self.value(sheet,r,8) or 0))
                if not months.is_finite() or months<0:raise ValueError(f'{sheet}!H{r} 月數不正確。')
                allowance=int((Decimal(self.amount(sheet,r,6))/1000*months).quantize(Decimal('1'),rounding=ROUND_HALF_UP))*1000
                taxable=gross-allowance
                if taxable<0:raise ValueError(f'{sheet}!F{r} 主管加給超過未扣稅金額。')
                records.append({'name':name,'code':'','gross_milli':gross,'taxable_milli':taxable,'region':'current','source_sheet':sheet,'source_location':f'I{r}/N{r}','components':[0]*6})
                raw.append(self.raw_record(sheet,r,1,14,'current'))
            regions=[{'key':'current','label':'年終／考績清冊','amount_milli':sum(x['gross_milli'] for x in records),'status':'included'}]
        if not records:raise ValueError('所選工作表沒有可辨識的員工明細。')
        return {'records':records,'regions':regions,'raw_rows':raw,'sheet':sheet}
    def raw_record(self,sheet,row,start,end,key):
        return {'source_sheet':sheet,'source_location':f'{openpyxl.utils.get_column_letter(start)}{row}:{openpyxl.utils.get_column_letter(end)}{row}',
                'region_key':key,'raw_payload_json':js({'values':[self.values[sheet].cell(row,c).value for c in range(start,end+1)],
                'formulas':[self.formulas[sheet].cell(row,c).value if self.formulas[sheet].cell(row,c).data_type=='f' else None for c in range(start,end+1)]}),
                'disposition':'included','decision_reason':'辨識原始明細'}

def match_record(rec,employees):
    if rec.get('employee_id'):return rec['employee_id']
    hits=[e for e in employees if (e['employee_code']==rec['code'] if rec.get('code') else e['name'].strip()==rec['name'].strip())]
    return hits[0]['id'] if len(hits)==1 else None

def aggregate(parsed,employees):
    states={r['key']:r['status'] for r in parsed['regions']};by={};unmatched=[]
    for rec in parsed['records']:
        if states[rec['region']] in ('historical','pending'):continue
        eid=match_record(rec,employees)
        if not eid:unmatched.append(rec);continue
        x=by.setdefault(eid,{'gross_milli':0,'taxable_milli':0,'components':[0]*6,'locations':[]})
        x['gross_milli']+=rec['gross_milli'];x['taxable_milli']+=rec['taxable_milli']
        x['components']=[a+b for a,b in zip(x['components'],rec['components'])];x['locations'].append(rec['source_sheet']+'!'+rec['source_location'])
    return by,unmatched

def clone_style(source,target):
    target._style=copy(source._style);target.alignment=copy(source.alignment);target.protection=copy(source.protection)
    target.number_format=source.number_format

def setv(ws,r,c,v):
    cell=ws.cell(r,c)
    if isinstance(cell,MergedCell):return
    cell.value=v
    # Untrusted strings are text, never executable Excel formulas.
    if isinstance(v,str):cell.data_type='s'

def setmoney(ws,r,c,value,widen=True):
    setv(ws,r,c,numeric(value));cell=ws.cell(r,c)
    cell.number_format='#,##0' if value%1000==0 else '#,##0.000'
    if widen:
        label=f'{numeric(value):,.0f}' if value%1000==0 else f'{numeric(value):,.3f}'
        col=openpyxl.utils.get_column_letter(c);ws.column_dimensions[col].width=max(ws.column_dimensions[col].width or 10,len(label)*1.15+1)

def clear_data(ws,start=3,end=None):
    for row in ws.iter_rows(min_row=start,max_row=end or ws.max_row):
        for c in row:
            if not isinstance(c,MergedCell):c.value=None;c.comment=None;c.hyperlink=None

def template_rows(ws,start,old_count,new_count,style_row=None):
    delta=new_count-old_count;old_end=start+old_count
    merges=[str(x) for x in ws.merged_cells.ranges]
    dims={r:copy(v) for r,v in ws.row_dimensions.items()}
    style=[copy(ws.cell(style_row or start,c)._style) for c in range(1,ws.max_column+1)]
    for m in merges:ws.unmerge_cells(m)
    if delta>0:ws.insert_rows(old_end,delta)
    elif delta<0:ws.delete_rows(start+new_count,-delta)
    for r,d in dims.items():
        if r>=old_end:ws.row_dimensions[r+delta]=copy(d)
    for m in merges:
        rng=openpyxl.worksheet.cell_range.CellRange(m)
        if rng.min_row>=old_end:rng.shift(row_shift=delta)
        elif rng.min_row>=start+new_count and rng.min_row<old_end:continue
        ws.merge_cells(str(rng))
    for r in range(start,start+new_count):
        for c,sty in enumerate(style,1):
            if not isinstance(ws.cell(r,c),MergedCell):ws.cell(r,c)._style=copy(sty)
        ws.row_dimensions[r].height=dims.get(style_row or start,ws.row_dimensions[start]).height or 24

def stamp_row(ws,row,groups,last_column):
    """One tall signing row, with a blank spacer above and ample room below labels."""
    for merged in list(ws.merged_cells.ranges):
        if merged.min_row<=row<=merged.max_row:ws.unmerge_cells(str(merged))
    for col in range(1,last_column+1):
        c=ws.cell(row,col);c.value=None;c.border=Border();c.fill=PatternFill();c.number_format='General'
    ws.row_dimensions[row-1].height=16
    # Width-fit printing reduces the visual height; 110pt leaves about 2cm on A4.
    ws.row_dimensions[row].height=110
    for start,end,label in groups:
        if end>start:ws.merge_cells(start_row=row,start_column=start,end_row=row,end_column=end)
        cell=ws.cell(row,start);cell.value=label;cell.font=Font(name='標楷體',size=12,bold=True,color='000000')
        cell.alignment=Alignment(horizontal='right' if label=='已列入所得' else 'left',vertical='top',wrap_text=False)

def main_sheet(ws,kind,rows,p):
    medical=kind.startswith('bonus');n=len(rows);template_rows(ws,3,18,n,4);clear_data(ws,3)
    s=p['settings'];meta=p['metadata'];ws['A2']='職稱';ws['B2']='姓名'
    if medical:
        ws['C1']=p['earned_period']+' 獎金';ws['D1']=None;ws.merge_cells('C1:G1');ws['H1']=meta.get('title') or s['organization'];ws.merge_cells('H1:N1');ws['O1']=KINDS[kind]
        for c,label in enumerate(meta.get('component_labels',['前期一','前期二','前期三','本期一','本期二','本期三']),3):ws.cell(2,c,label)
    else:
        title_style=copy(ws['F1']._style);ws['F1']=None;ws['G1']=None
        ws.merge_cells('A1:K1');ws['A1']=(meta.get('title') or s['organization'])+' '+p['earned_period']+' '+KINDS[kind];ws['A1']._style=title_style
    ws.row_dimensions[1].height=36
    for cell in ws[1]:
        if not isinstance(cell,MergedCell):cell.alignment=Alignment(horizontal='center',vertical='center',wrap_text=True)
    # Unmerge old doctor amount if the first row is not the nominated doctor.
    if medical and 'C3:H3' in [str(x) for x in ws.merged_cells.ranges]:ws.unmerge_cells('C3:H3')
    for i,x in enumerate(rows,3):
        e=x['employee_snapshot'];setv(ws,i,1,e['title']);setv(ws,i,2,e['name'])
        if medical:
            comp=meta.get('components',{}).get(x['employee_id']) or [x['gross_milli'],0,0,0,0,0]
            if sum(comp)!=x['gross_milli']:comp=[x['gross_milli'],0,0,0,0,0]
            for c,a in enumerate(comp,3):
                if a:setmoney(ws,i,c,a)
                else:setv(ws,i,c,None)
            if x['tax_difference_role']:
                for c in range(3,9):setv(ws,i,c,None)
                ws.merge_cells(start_row=i,start_column=3,end_row=i,end_column=8);setmoney(ws,i,3,x['gross_milli'],False);ws.cell(i,3).alignment=Alignment(horizontal='center',vertical='center')
            vals=[x['gross_milli'],x['nhi_milli'],x['deducted_tax_milli'],x['net_milli'],x['accumulated_milli'],x['fourfold_insurance_milli'],x['insurance_milli']]
            for c,a in enumerate(vals,9):setmoney(ws,i,c,a)
        else:
            vals=[x['gross_milli'],x['taxable_milli'],x['taxable_milli'],x['nhi_milli'],x['deducted_tax_milli'],x['net_milli'],x['accumulated_milli'],x['fourfold_insurance_milli'],x['insurance_milli']]
            for c,a in enumerate(vals,3):setmoney(ws,i,c,a)
    end=3+n;sm=summary(rows)
    if medical:
        others=[x for x in rows if not x['tax_difference_role']];setv(ws,end,1,f'不含醫師{len(others)}人');setv(ws,end,2,'合計')
        setv(ws,end+1,1,f'含醫師{n}人');setv(ws,end+1,2,'合計')
        for r,rr in [(end,others),(end+1,rows)]:
            for c,key in [(9,'gross_milli'),(10,'nhi_milli'),(12,'net_milli'),(13,'accumulated_milli'),(14,'fourfold_insurance_milli'),(15,'insurance_milli')]:setmoney(ws,r,c,sum(x[key] for x in rr))
            setmoney(ws,r,11,sum(x['deducted_tax_milli'] for x in rr))
        for c in range(3,9):
            total=0
            for x in others:
                comp=meta.get('components',{}).get(x['employee_id']) or [x['gross_milli'],0,0,0,0,0]
                if sum(comp)!=x['gross_milli']:comp=[x['gross_milli'],0,0,0,0,0]
                total+=comp[c-3]
            if total:setmoney(ws,end,c,total)
        r=end+4
        for c,label in {3:'醫師',4:'獎勵金期間',5:'入賬日期',6:'獎勵金',7:'二代健保',8:'預扣所得稅',9:'實領',10:'內部往來統籌金'}.items():setv(ws,r,c,label)
        doctor=next((x for x in rows if x['tax_difference_role']),None)
        if doctor:
            for c,val in {3:doctor['employee_snapshot']['name'],4:p['earned_period'],5:p['paid_on'],6:numeric(doctor['gross_milli']),7:numeric(doctor['nhi_milli']),8:numeric(doctor['deducted_tax_milli']),9:numeric(doctor['net_milli'])}.items():setv(ws,r+1,c,val)
        fund_font=copy(ws.cell(r+1,13).font)
        ws.merge_cells(start_row=r,start_column=10,end_row=r,end_column=12)
        ws.merge_cells(start_row=r+1,start_column=10,end_row=r+1,end_column=12)
        setmoney(ws,r+1,10,meta.get('fund_milli',0),False);ws.cell(r+1,10).font=fund_font
        bold=copy(ws.cell(r,10).font);bold.bold=True;ws.cell(r,10).font=bold
        # Remove the former blank J cells by moving the fund block one column left.
        for rr in [r,r+1]:
            ws.cell(rr,13).value=None;ws.cell(rr,13).border=Border()
            for cc in range(3,13):
                cell=ws.cell(rr,cc);old=cell.border
                cell.border=Border(left=Side(style='medium',color='000000') if cc==3 else copy(old.left),right=Side(style='medium',color='000000') if cc==12 else copy(old.right),top=Side(style='medium',color='000000') if rr==r else copy(old.top),bottom=Side(style='medium',color='000000') if rr==r+1 else copy(old.bottom))
        ws.row_dimensions[r].height=max(ws.row_dimensions[r].height or 20,32);ws.row_dimensions[r+1].height=40
        for rr in [r,r+1]:
            for cell in ws[rr]:
                if not isinstance(cell,MergedCell):cell.alignment=Alignment(horizontal='center',vertical='center',wrap_text=True)
        print_end=r+3;last_col='O'
    else:
        setv(ws,end,1,f'{n}人');setv(ws,end,2,'合計')
        for c in range(3,12):setmoney(ws,end,c,sum(int(Decimal(str(ws.cell(r,c).value or 0))*1000) for r in range(3,end)))
        print_end=end+3;last_col='K'
    tax_col,nhi_col=(11,10) if medical else (7,6)
    for rr in range(2,end+(2 if medical else 1)):
        target=ws.cell(rr,tax_col);source=ws.cell(rr,nhi_col)
        target.font=copy(source.font);target.alignment=copy(source.alignment);target.fill=copy(source.fill);target.border=copy(source.border)
    groups=[(1,3,'出納:'),(4,6,'約僱人員:'),(7,9,'會計:'),(10,12,'主任:'),(13,15,'已列入所得')] if medical else [(1,2,'出納:'),(3,4,'約僱人員:'),(5,6,'會計:'),(7,9,'主任:'),(10,11,'已列入所得')]
    stamp_row(ws,print_end,groups,15 if medical else 11)
    ws.print_area=f'A1:{last_col}{print_end}';ws.print_title_rows='1:2';ws.sheet_properties.pageSetUpPr.fitToPage=True
    ws.page_setup.fitToWidth=1;ws.page_setup.fitToHeight=0;ws.freeze_panes='C3'
    if medical:
        # Collapse only dynamically located blank spacer rows, never employee rows.
        ws.row_dimensions[end+2].hidden=True
        ws.row_dimensions[end+3].height=6
        ws.row_dimensions[r].height=26
        ws.row_dimensions[r+1].height=36
        ws.row_dimensions[r+2].hidden=True
        ws.page_setup.orientation='landscape';ws.page_setup.paperSize=ws.PAPERSIZE_A4
        ws.page_setup.fitToWidth=1;ws.page_setup.fitToHeight=1;ws.page_setup.scale=None
        ws.sheet_properties.pageSetUpPr.autoPageBreaks=False
        ws.row_breaks.brk=[];ws.col_breaks.brk=[]
        ws.page_margins.left=0.25;ws.page_margins.right=0.25
        ws.page_margins.top=0.3;ws.page_margins.bottom=0.3
        ws.print_options.horizontalCentered=True


def bank_sheet(ws,rows,p):
    rows=[x for x in rows if x['payout_enabled'] and (x['gross_milli'] or x['taxable_milli'])]
    original=16 if ws.title=='3農' else 19
    template_rows(ws,4,original,max(1,len(rows)),5);clear_data(ws,4)
    meta=p['metadata'];ws['A1']=meta.get('title') or p['settings']['organization']+' 撥款明細'
    ws['A2']='入賬日期 '+(p.get('credited_on') or p['paid_on']);ws['C2']=p['earned_period'];ws['D2']='農會撥款支票號碼 '+meta.get('check_number','')
    ws.row_dimensions[2].height=40
    for c in ws[2]:
        if not isinstance(c,MergedCell):c.alignment=Alignment(horizontal='center',vertical='center',wrap_text=True)
    for r,x in enumerate(rows,4):
        e=x['employee_snapshot'];setv(ws,r,1,e.get('bank_account',''));ws.cell(r,1).number_format='@';setv(ws,r,2,e['name']);setmoney(ws,r,3,x['net_milli']);setv(ws,r,4,{'bonus1':'第一次醫療獎勵金','bonus2':'第二次醫療獎勵金','bonus3':'第三次醫療獎勵金','bonus4':'第四次醫療獎勵金'}.get(p['kind'],meta.get('remark') or KINDS[p['kind']]))
    for rr in range(4,4+len(rows)):ws.cell(rr,4).alignment=Alignment(horizontal='center',vertical='center',wrap_text=True)
    end=4+max(1,len(rows));setv(ws,end,2,'合計');setmoney(ws,end,3,sum(x['net_milli'] for x in rows))
    longest=max([len(str(x['employee_snapshot'].get('bank_account',''))) for x in rows]+[0])
    ws.column_dimensions['A'].width=max(ws.column_dimensions['A'].width or 0,32,longest*1.3+4)
    for rr in range(4,end):ws.cell(rr,1).alignment=Alignment(horizontal='center',vertical='center',wrap_text=False)
    stamp_row(ws,end+3,[(1,1,'出納:'),(2,3,'會計:'),(4,4,'機關長官:')],4)
    ws.print_area=f'A1:D{end+3}';ws.print_title_rows='1:3';ws.page_setup.fitToWidth=1;ws.page_setup.fitToHeight=0

def nhi_sheet(ws,rows,p):
    clear_data(ws,2);date=p['paid_on'];y,m,d=map(int,date.split('-'));roc=(y-1911)*10000+m*100+d
    rows=[x for x in rows if x['nhi_export_enabled'] and x['taxable_milli']>0]
    for r,x in enumerate(rows,2):
        for c in range(1,20):clone_style(ws.cell(2,c),ws.cell(r,c))
        e=x['employee_snapshot'];values={1:e.get('insurance_unit',''),2:p['settings'].get('tax_id',''),3:e.get('national_id',''),4:e['name'],5:roc,6:'逾當月投保金額四倍部分之獎金',7:numeric(x['taxable_milli']),8:numeric(x['insurance_milli']),12:0,13:0,16:0}
        for c,val in values.items():setv(ws,r,c,val)
        for c in [1,2,3]:ws.cell(r,c).number_format='@'
    ws.print_area=f'A1:S{max(2,len(rows)+1)}';ws.freeze_panes='E2'

def flat_table(wb,name,headers,data):
    ws=wb.create_sheet(name);ws.append(headers)
    for row in data:ws.append(row)
    for row in ws:
        for c in row:
            if isinstance(c.value,str):c.data_type='s'
            elif isinstance(c.value,(int,float)):
                c.number_format='#,##0' if c.value==int(c.value) else '#,##0.000'
            c.font=Font(name='Microsoft JhengHei',size=11);c.alignment=Alignment(vertical='center',wrap_text=True)
    for c in ws[1]:c.fill=PatternFill('solid',fgColor='174B66');c.font=Font(name='Microsoft JhengHei',size=11,color='FFFFFF',bold=True)
    for c in range(1,len(headers)+1):ws.column_dimensions[openpyxl.utils.get_column_letter(c)].width=20
    ws.row_dimensions[1].height=32;ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
    ws.sheet_properties.pageSetUpPr.fitToPage=True;ws.page_setup.orientation='landscape';ws.page_setup.paperSize=9;ws.page_setup.fitToWidth=1;ws.page_setup.fitToHeight=0
    return ws

def copy_source_values(wb,name,original):
    """Copy source values/formatting across workbooks without cross-workbook style IDs."""
    ws=wb.create_sheet(name)
    for row in original:
        for c in row:
            if isinstance(c,MergedCell):continue
            dest=ws.cell(c.row,c.column)
            if c.has_style:
                dest.font=copy(c.font);dest.fill=copy(c.fill);dest.border=copy(c.border);dest.alignment=copy(c.alignment);dest.number_format=c.number_format;dest.protection=copy(c.protection)
            if c.value is not None:setv(ws,c.row,c.column,c.value)
    for key,dim in original.column_dimensions.items():ws.column_dimensions[key]=copy(dim)
    for key,dim in original.row_dimensions.items():ws.row_dimensions[key]=copy(dim)
    for m in original.merged_cells.ranges:ws.merge_cells(str(m))
    ws.page_setup=copy(original.page_setup);ws.page_margins=copy(original.page_margins);ws.print_options=copy(original.print_options)
    ws.freeze_panes=original.freeze_panes
    return ws

@lru_cache(maxsize=2)
def compact_template(path,mtime,size):
    """Discard only distant, empty styled cells; retain content and merge bounds.

    Cache immutable ZIP bytes, never a mutable Workbook shared across exports.
    """
    target=BytesIO();ns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
    with zipfile.ZipFile(path) as src, zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as dst:
        for info in src.infolist():
            data=src.read(info.filename)
            if re.fullmatch(r'xl/worksheets/sheet\d+\.xml',info.filename):
                root=ET.fromstring(data);sheet=root.find('s:sheetData',ns)
                cells=list(sheet.iter('{'+ns['s']+'}c'))
                meaningful=[c for c in cells if len(c)]
                bounds=[openpyxl.utils.cell.coordinate_to_tuple(c.attrib['r']) for c in meaningful]
                for m in root.findall('s:mergeCells/s:mergeCell',ns):
                    a,b,c,d=openpyxl.utils.range_boundaries(m.attrib['ref']);bounds.append((d,c))
                last_row=max([40]+[r for r,c in bounds]);last_col=max([19]+[c for r,c in bounds])
                for row in list(sheet):
                    for cell in list(row):
                        rr,cc=openpyxl.utils.cell.coordinate_to_tuple(cell.attrib['r'])
                        if rr>last_row or cc>last_col:row.remove(cell)
                    if not len(row) and int(row.attrib['r'])>last_row:sheet.remove(row)
                dimension=root.find('s:dimension',ns)
                if dimension is not None:dimension.set('ref',f'A1:{openpyxl.utils.get_column_letter(last_col)}{last_row}')
                data=ET.tostring(root,encoding='utf-8')
            dst.writestr(info,data)
    return target.getvalue()

def export_workbook(store,path,cycle=None,batch_id=None):
    cycle=cycle or store.cycle()['id'];history=[b for b in store.history(cycle) if b['state']=='active' and (not batch_id or b['id']==batch_id)]
    if not history:raise ValueError('沒有可匯出的有效批次。')
    by={b['id']:[] for b in history}
    for row in store.results(cycle=cycle):
        batch_rows=by.get(row['batch_id'])
        if batch_rows is not None:batch_rows.append(row)
    for b in history:
        for x in by[b['id']]:
            e=x['employee_snapshot']
            if x['gross_milli']>0 and x['payout_enabled'] and not e.get('bank_account'):raise ValueError(e['name']+' 的當批收款帳號空白。請先修正批次，或取消列入撥款。')
            if x['taxable_milli']>0 and x['nhi_export_enabled'] and (not e.get('national_id') or not e.get('insurance_unit')):raise ValueError(e['name']+' 的當批身分證號／投保單位未填，請修正批次。')
    template=store.assets/'template.xlsx';stat=template.stat()
    wb=openpyxl.load_workbook(BytesIO(compact_template(str(template),stat.st_mtime_ns,stat.st_size)));keep=[];payloads={}
    for b in history:
        p=store.batch_payload(b['id']);payloads[b['id']]=p;name=SHEETS[b['bonus_kind']]
        rows=sorted(by[b['id']],key=lambda x:(not x['tax_difference_role'],x['display_order']))
        main_sheet(wb[name],b['bonus_kind'],rows,p);bank_sheet(wb[name+'農'],rows,p);nhi_sheet(wb[name+'健'],rows,p)
        keep += [name,name+'農',name+'健']
    if not batch_id:
        keep.insert(0,'全獎金');ws=wb['全獎金'];ws.delete_cols(7,1);clear_data(ws,1)
        for m in list(ws.merged_cells.ranges):ws.unmerge_cells(str(m))
        headers=['職稱','姓名','第一次醫療獎勵金','第二次醫療獎勵金','第三次醫療獎勵金','第四次醫療獎勵金','年終報稅金額','考績報稅金額','獎金累計','四倍投保金額','全年概算健保','最後批次投保金額']
        for c,h in enumerate(headers,1):
            if c==13:clone_style(ws.cell(3,11),ws.cell(3,c))
            setv(ws,3,c,h);ws.cell(3,c).alignment=Alignment(horizontal='center',vertical='center',wrap_text=True)
        ws.row_dimensions[3].height=42;ws.column_dimensions['M'].width=19
        people={}
        for b in history:
            for x in by[b['id']]:
                e=people.setdefault(x['employee_id'],{'last':x,'amounts':{},'nhi':0});e['last']=x;e['amounts'][b['bonus_kind']]=x['taxable_milli'];e['nhi']+=x['nhi_milli']
        for r,(_,e) in enumerate(people.items(),4):
            x=e['last'];snap=x['employee_snapshot'];total=sum(e['amounts'].values());q=x['insurance_milli']*4
            settings=payloads[x['batch_id']]['settings'];estimate=int((Decimal(max(0,total-q))/1000*Decimal(settings['nhi_percent'])/100).quantize(Decimal('1'),rounding=ROUND_HALF_UP))*1000
            vals=[snap['title'],snap['name']]+[numeric(e['amounts'].get(k,0)) for k in KINDS]+[numeric(total),numeric(q),numeric(estimate),numeric(x['insurance_milli'])]
            for c,val in enumerate(vals,1):
                if r>4:clone_style(ws.cell(4,c),ws.cell(r,c))
                if c==13:clone_style(ws.cell(r,11),ws.cell(r,c))
                setv(ws,r,c,val)
                if c>=3:setmoney(ws,r,c,int(Decimal(str(val))*1000))
        end=4+len(people);setv(ws,end,2,'合計')
        for c in range(3,10):setmoney(ws,end,c,sum(int(Decimal(str(ws.cell(r,c).value or 0))*1000) for r in range(4,end)))
        if ws.max_column>12:ws.delete_cols(13,ws.max_column-12)
        # Remove the trailing blank template rows (original row 23 for 18 people),
        # then the first two blank rows; never delete an employee when headcount grows.
        if ws.max_row>end:ws.delete_rows(end+1,ws.max_row-end)
        heights={r:ws.row_dimensions[r].height for r in range(3,end+1)}
        ws.delete_rows(1,2)
        for r,h in heights.items():ws.row_dimensions[r-2].height=h
        ws.print_area=f'A1:L{end-2}';ws.freeze_panes='C2';ws.print_title_rows='1:1'
    for name in list(wb.sheetnames):
        if name not in keep:del wb[name]
    if not batch_id:
        source_cache={}
        for b in history:
            p=payloads[b['id']];source_name=KINDS[b['bonus_kind']]
            raw=p.get('raw_rows',[]);sheet_name=raw[0]['source_sheet'] if raw else None
            if p.get('source_file_id') and sheet_name:
                source_id=p['source_file_id']
                if source_id not in source_cache:
                    source=store.one('SELECT bytes FROM source_files WHERE id=?',(source_id,))
                    source_cache[source_id]=openpyxl.load_workbook(BytesIO(source['bytes']),data_only=True)
                original=source_cache[source_id]
                if sheet_name not in original.sheetnames:raise ValueError('來源工作表不存在，不能產生完整年度來源資料。')
                copy_source_values(wb,source_name,original[sheet_name])
            else:
                flat_table(wb,source_name,['員工代碼','姓名','未扣稅金額','主管加給','報稅金額','當批投保額'],[[x['employee_snapshot']['employee_code'],x['employee_snapshot']['name'],numeric(x['gross_milli']),numeric(x['gross_milli']-x['taxable_milli']),numeric(x['taxable_milli']),numeric(x['insurance_milli'])] for x in by[b['id']]])
    # Output includes traceability/statistics; never embeds reference-page login material.
    stats=[];logs=[]
    for b in history:
        p=payloads[b['id']];s=summary(by[b['id']])
        stats.append([b['sequence'],KINDS[b['bonus_kind']],p['paid_on'],s['withheld_count'],numeric(s['withheld_income']),s['exempt_count'],numeric(s['exempt_income']),numeric(s['tax_total_integer']),numeric(s['deducted']),numeric(s['nhi']),numeric(s['net'])])
        logs.append([b['sequence'],KINDS[b['bonus_kind']],b['created_at'],b['current_revision'],p['paid_on'],p['earned_period']])
    flat_table(wb,'扣繳統計',['順序','種類','入賬日期','需預扣人次','需預扣所得','免預扣人次','免預扣所得','稅額合計截位','實際扣款合計','二代健保','實領合計'],stats)
    flat_table(wb,'匯入紀錄',['順序','種類','匯入時間 UTC','修訂','入賬日期','所屬期間'],logs)
    if not batch_id:
        flat_table(wb,'本次核定輸入',['順序','種類','員工代碼','姓名','未扣稅金額','報稅金額','投保金額','輸入方式'],[[b['sequence'],KINDS[b['bonus_kind']],x['employee_snapshot']['employee_code'],x['employee_snapshot']['name'],numeric(x['gross_milli']),numeric(x['taxable_milli']),numeric(x['insurance_milli']),x['input_method']] for b in history for x in by[b['id']]])
    # Every result is a value, no stale formulas, comments or external links.
    for ws in wb:
        for row in ws:
            for c in row:
                if not isinstance(c,MergedCell):
                    if c.data_type=='f':raise ValueError('匯出仍有未替換公式：'+ws.title+'!'+c.coordinate)
                    c.comment=None;c.hyperlink=None
    wb._external_links=[]
    dest=Path(path);tmp=dest.with_name(dest.stem+'.writing.xlsx');wb.save(tmp);tmp.replace(dest)
    run=store.one('SELECT run_id FROM cycle_publications WHERE cycle_id=?',(cycle,))['run_id']
    with store.db:store.db.execute('INSERT INTO export_jobs VALUES(?,?,?,?,?,?,?)',(uid(),run,js({'cycle':cycle,'batch':batch_id}),digest((store.assets/'template.xlsx').read_bytes()),dest.name,digest(dest.read_bytes()),now()))
    return dest
