"""Signed GitHub Release update checks and downloads for the client."""
from __future__ import annotations

import base64
import calendar
import ctypes
import hashlib
import os
import json
import re
import urllib.error
import urllib.request
import zipfile
import tkinter as tk
import subprocess
from datetime import datetime, timedelta, timezone
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from core import VERSION

REPOSITORY = "mathersky/BonusLedger"
MANIFEST_URL = f"https://raw.githubusercontent.com/{REPOSITORY}/main/updates/licensed/manifest.json"
ASSET_URL = f"https://raw.githubusercontent.com/{REPOSITORY}/main/updates/licensed/client.zip"
PUBLIC_KEY_B64 = "VpO7NxjD0M/VMoW++0NJdrqnTMG0mv58MPQtWHeWzyg="
MAX_MANIFEST_BYTES = 64 * 1024
MAX_PACKAGE_BYTES = 100 * 1024 * 1024
PRODUCT = "BonusLedger"
TRIAL_MONTHS = 3
ENTROPY = b"BonusLedger-License-v1"


class UpdateError(RuntimeError):
    pass


def _request(url: str, limit: int) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "BonusLedger-Updater/1", "Accept": "application/octet-stream"})
    try:
        with urllib.request.urlopen(req, timeout=12) as response:
            data = response.read(limit + 1)
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        raise UpdateError(f"連線更新伺服器失敗：{exc}") from exc
    if len(data) > limit:
        raise UpdateError("更新檔大小超過安全限制。")
    return data


def _version_tuple(value: str) -> tuple[int, ...]:
    if not re.fullmatch(r"\d+(?:\.\d+){1,3}", value):
        raise UpdateError("更新資訊中的版本格式不正確。")
    return tuple(int(x) for x in value.split("."))


def _canonical(payload: dict) -> bytes:
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def check_latest() -> dict | None:
    if PUBLIC_KEY_B64.startswith("__"):
        raise UpdateError("此客戶端尚未設定更新驗證金鑰，請使用主控端發布的安裝包。")
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

        envelope = json.loads(_request(MANIFEST_URL, MAX_MANIFEST_BYTES).decode("utf-8"))
        payload = envelope["payload"]
        signature = base64.b64decode(envelope["signature"], validate=True)
        key = Ed25519PublicKey.from_public_bytes(base64.b64decode(PUBLIC_KEY_B64, validate=True))
        key.verify(signature, _canonical(payload))
    except UpdateError:
        raise
    except Exception as exc:
        raise UpdateError("更新資訊簽章驗證失敗，已停止更新。") from exc
    version = str(payload.get("version", ""))
    if _version_tuple(version) <= _version_tuple(VERSION):
        return None
    if payload.get("asset") != "client.zip" or not re.fullmatch(r"[0-9a-f]{64}", str(payload.get("sha256", ""))):
        raise UpdateError("更新資訊不完整，已停止更新。")
    return payload


def download_package(payload: dict, destination: str | Path) -> Path:
    data = _request(ASSET_URL, MAX_PACKAGE_BYTES)
    if hashlib.sha256(data).hexdigest() != payload["sha256"]:
        raise UpdateError("更新檔 SHA-256 驗證失敗，已停止更新。")
    try:
        import io

        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            if archive.testzip() is not None:
                raise UpdateError("更新 ZIP 檔損毀，已停止更新。")
            for item in archive.infolist():
                path = Path(item.filename)
                if path.is_absolute() or ".." in path.parts or item.file_size > MAX_PACKAGE_BYTES:
                    raise UpdateError("更新 ZIP 含有不安全的檔案路徑。")
    except zipfile.BadZipFile as exc:
        raise UpdateError("更新檔不是有效的 ZIP。") from exc
    target = Path(destination)
    target.parent.mkdir(parents=True, exist_ok=True)
    temp = target.with_suffix(target.suffix + ".part")
    temp.write_bytes(data)
    temp.replace(target)
    return target


# Machine-bound trial and license management. The release publisher injects the
# same Ed25519 public key used to verify signed updates.
class LicenseError(RuntimeError):
    pass


class DATA_BLOB(ctypes.Structure):
    _fields_ = [("cbData", ctypes.c_uint32), ("pbData", ctypes.POINTER(ctypes.c_ubyte))]


def _blob(raw: bytes):
    buf = ctypes.create_string_buffer(raw)
    return DATA_BLOB(len(raw), ctypes.cast(buf, ctypes.POINTER(ctypes.c_ubyte))), buf


def _protect(raw: bytes, decrypt: bool = False) -> bytes:
    if os.name != "nt":
        raise LicenseError("授權功能需在 Windows 執行。")
    crypt = ctypes.WinDLL("crypt32", use_last_error=True)
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    blob_ptr = ctypes.POINTER(DATA_BLOB)
    crypt.CryptProtectData.argtypes = [blob_ptr, ctypes.c_wchar_p, blob_ptr, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint32, blob_ptr]
    crypt.CryptProtectData.restype = ctypes.c_int
    crypt.CryptUnprotectData.argtypes = [blob_ptr, ctypes.POINTER(ctypes.c_wchar_p), blob_ptr, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint32, blob_ptr]
    crypt.CryptUnprotectData.restype = ctypes.c_int
    kernel.LocalFree.argtypes = [ctypes.c_void_p]
    kernel.LocalFree.restype = ctypes.c_void_p
    source, source_buf = _blob(raw)
    entropy, entropy_buf = _blob(ENTROPY)
    output = DATA_BLOB()
    flags = 0x1  # CRYPTPROTECT_UI_FORBIDDEN
    if decrypt:
        ok = crypt.CryptUnprotectData(ctypes.byref(source), None, ctypes.byref(entropy), None, None, flags, ctypes.byref(output))
    else:
        ok = crypt.CryptProtectData(ctypes.byref(source), None, ctypes.byref(entropy), None, None, flags, ctypes.byref(output))
    if not ok:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        return ctypes.string_at(output.pbData, output.cbData)
    finally:
        kernel.LocalFree(output.pbData)


def machine_code() -> str:
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography") as key:
            machine_guid = winreg.QueryValueEx(key, "MachineGuid")[0]
    except Exception as exc:
        raise LicenseError("無法讀取此電腦代碼。請確認 Windows 系統正常。") from exc
    return hashlib.sha256((PRODUCT + "|" + str(machine_guid)).encode("utf-8")).hexdigest()[:24].upper()


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def _parse(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def add_months(value: datetime, count: int) -> datetime:
    month = value.month - 1 + count
    year = value.year + month // 12
    month = month % 12 + 1
    day = min(value.day, calendar.monthrange(year, month)[1])
    return value.replace(year=year, month=month, day=day)


def _state_path(data_dir: str | Path) -> Path:
    return Path(data_dir) / "license_state.dat"


def _save(path: Path, state: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_bytes(_protect(json.dumps(state, ensure_ascii=False, separators=(",", ":")).encode("utf-8")))
    os.replace(temp, path)


def _load(path: Path) -> dict | None:
    if not path.exists():
        return None
    try:
        return json.loads(_protect(path.read_bytes(), decrypt=True).decode("utf-8"))
    except Exception as exc:
        raise LicenseError("授權狀態檔無法讀取。請匯入有效授權檔，或聯絡授權管理者。") from exc


def _verify_license(envelope: dict) -> dict:
    if PUBLIC_KEY_B64.startswith("__"):
        raise LicenseError("此版本尚未設定授權驗證金鑰，請重新取得主控端發布的安裝包。")
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
        payload = envelope["payload"]
        signature = base64.b64decode(envelope["signature"], validate=True)
        key = Ed25519PublicKey.from_public_bytes(base64.b64decode(PUBLIC_KEY_B64, validate=True))
        key.verify(signature, _canonical(payload))
    except Exception as exc:
        raise LicenseError("授權檔簽章無效或已損毀。") from exc
    if payload.get("product") != PRODUCT:
        raise LicenseError("授權檔不適用於本軟體。")
    if payload.get("machine_code") != machine_code():
        raise LicenseError("授權檔綁定其他電腦，無法在此使用。")
    if not payload.get("issued_at"):
        raise LicenseError("授權檔缺少簽發時間。")
    try:
        issued = _parse(payload["issued_at"])
        expiry = _parse(payload["expires_at"]) if payload.get("expires_at") else None
    except Exception as exc:
        raise LicenseError("授權檔日期格式錯誤。") from exc
    if issued > _now() + timedelta(days=1):
        raise LicenseError("此授權檔的簽發時間晚於目前時間。")
    if expiry and _now() >= expiry:
        raise LicenseError("此授權已到期，請匯入新的授權檔。")
    return payload


def _status(state: dict | None, now: datetime | None = None) -> tuple[bool, str, datetime | None]:
    now = now or _now()
    if state and state.get("license"):
        try:
            payload = _verify_license(state["license"])
            expiry = _parse(payload["expires_at"]) if payload.get("expires_at") else None
            label = "永久授權" if expiry is None else f"正式授權至 {expiry.astimezone().date().isoformat()}"
            return True, label, expiry
        except LicenseError as exc:
            return False, str(exc), None
    if not state or not state.get("trial_started_at"):
        return False, "試用狀態尚未建立", None
    try:
        started = _parse(state["trial_started_at"])
    except Exception:
        return False, "試用狀態無效，請匯入授權檔", None
    expiry = add_months(started, TRIAL_MONTHS)
    last_seen = state.get("last_seen_at")
    if last_seen:
        try:
            if now < _parse(last_seen) - timedelta(hours=12):
                return False, "系統時間異常，請校正時間或匯入授權檔", expiry
        except Exception:
            return False, "試用狀態無效，請匯入授權檔", expiry
    if now >= expiry:
        return False, f"試用已於 {expiry.astimezone().date().isoformat()} 到期", expiry
    return True, f"免費試用至 {expiry.astimezone().date().isoformat()}", expiry


def current_status_text(data_dir: str | Path) -> str:
    try:
        ok, label, _ = _status(_load(_state_path(data_dir)))
        return label if ok else label
    except LicenseError as exc:
        return str(exc)


def ensure_license(data_dir: str | Path) -> bool:
    path = _state_path(data_dir)
    try:
        state = _load(path)
    except LicenseError:
        state = None
        # A damaged state file does not silently restart the free trial.
    if state is None and not path.exists():
        now = _now()
        state = {"machine_code": machine_code(), "trial_started_at": _iso(now), "last_seen_at": _iso(now)}
        _save(path, state)
    if state and state.get("machine_code") not in (None, machine_code()):
        state = None
    if state:
        now = _now()
        active, _, _ = _status(state, now)
        if active:
            state["last_seen_at"] = _iso(max(now, _parse(state.get("last_seen_at", _iso(now)))))
            _save(path, state)
            return True
    root = tk.Tk()
    root.withdraw()
    try:
        messagebox.showwarning("需要授權", "免費試用已結束或授權狀態需要修復。請匯入有效授權檔。", parent=root)
        return open_license_dialog(root, data_dir, required=True)
    finally:
        root.destroy()


def open_license_dialog(parent, data_dir: str | Path, required: bool = False) -> bool:
    path = _state_path(data_dir)
    try:
        state = _load(path)
    except LicenseError:
        state = None
    if state is None and not path.exists():
        now = _now()
        state = {"machine_code": machine_code(), "trial_started_at": _iso(now), "last_seen_at": _iso(now)}
        _save(path, state)
    ok, label, _ = _status(state)
    result = {"ok": ok}
    win = tk.Toplevel(parent)
    win.title("BonusLedger｜授權")
    win.geometry("540x260")
    win.resizable(False, False)
    frame = ttk.Frame(win, padding=18)
    frame.pack(fill="both", expand=True)
    ttk.Label(frame, text="BonusLedger 授權", font=("Microsoft JhengHei", 16, "bold")).pack(anchor="w")
    status = tk.StringVar(value=label)
    ttk.Label(frame, textvariable=status, foreground="#31566b").pack(anchor="w", pady=(10, 12))
    code = machine_code()
    ttk.Label(frame, text="本機代碼（提供給授權管理者）").pack(anchor="w")
    row = ttk.Frame(frame); row.pack(fill="x", pady=(3, 12))
    code_var = tk.StringVar(value=code)
    ttk.Entry(row, textvariable=code_var, state="readonly", font=("Consolas", 12)).pack(side="left", fill="x", expand=True)
    def copy_code():
        win.clipboard_clear(); win.clipboard_append(code); status.set("本機代碼已複製")
    ttk.Button(row, text="複製", command=copy_code).pack(side="left", padx=(8, 0))
    def import_license():
        filename = filedialog.askopenfilename(parent=win, title="選取 BonusLedger 授權檔", filetypes=[("BonusLedger 授權檔", "*.lic"), ("所有檔案", "*.*")])
        if not filename: return
        try:
            envelope = json.loads(Path(filename).read_text(encoding="utf-8"))
            payload = _verify_license(envelope)
            state_now = state or {"machine_code": code, "trial_started_at": _iso(_now())}
            state_now["machine_code"] = code
            state_now["license"] = envelope
            state_now["last_seen_at"] = _iso(_now())
            _save(path, state_now)
            result["ok"] = True
            status.set("授權完成：" + ("永久授權" if not payload.get("expires_at") else "正式授權至 " + _parse(payload["expires_at"]).astimezone().date().isoformat()))
            messagebox.showinfo("授權完成", "授權已綁定此電腦。", parent=win)
            win.destroy()
        except Exception as exc:
            messagebox.showerror("匯入失敗", str(exc), parent=win)
    buttons = ttk.Frame(frame); buttons.pack(fill="x", side="bottom")
    ttk.Button(buttons, text="匯入授權檔", command=import_license).pack(side="left")
    if not required:
        ttk.Button(buttons, text="關閉", command=win.destroy).pack(side="right")
    win.transient(parent)
    win.grab_set()
    win.wait_window()
    return bool(result["ok"])

APP_ICON_B64 = "AAABAAUAEBAAAAAAIAACAwAAVgAAABgYAAAAACAAdgUAAFgDAAAgIAAAAAAgAFIIAADOCAAAMDAAAAAAIABeDgAAIBEAAEBAAAAAACAAiBUAAH4fAACJUE5HDQoaCgAAAA1JSERSAAAAEAAAABAIBgAAAB/z/2EAAALJSURBVHicTZNLiB1VEIa/qj7dfR/JPAJJ8DFh0BmjEnwbHwSUbJQIBsSNLrMOmpWjC/ci6kI32QkqQhBXESJKxBAyiEEYTMA4EAkjEaPM5DG37+3bt0+Vi+5RCw5ncc7/81NfldDWXS+9dsjFn0qSREIQwQAMzDBr7noS3S162kmXV788fgoQAWT/0bffWr92a2k4KKeq2hmNK9wdNwOLeDTUjW6WIO6ouPe2dd5d++aTN2XvK68/VxbVybqOdTmZhNmZnj66MG8qgBnujuIMihHnf76so9EIoiVpnjK7e+ZQqCs7UBRVmrinNxjw/GMLfHjksP5y5Q/yNMXdGZQVTz+0yEefnY5LH5wIO6Z6MdZRx0X5THA3VRUXc8dMVZSV1TU5eW6FfjcnD4GZ7X3uu/t2ds/2xc0ABBDcNYCBu7i7K1BWEw4+ci8P3zOHiuCqTG/vIyFQjMZN1/5XodEbYobhZEnCxfUNflvfoNfLWcgTbq5fZW7PPCGRxsAddwdAt1C5RXBv03lz2k8hUTRklJOUOKzR9s3MUDNrcVkrbCxAGsruJCGj3PyLB3b9yeP3TzEYRYStBK3YY8TNW52gAoojoYNOrnvx0/vxjtEpjh7u+4PzKWUZCQrh3/gxQtJEG1UTBuMKDwnl5t9M3Vz25Uu/y8cXMs06m/byE1Px/K9DVawxIDYTB46kCfvmbvOd09vIs8AOhfTGBv3Vi/7k3NAX7+z71z8M1S02/TF391i7mXl3aPx4esWPXRtajAbuRE0oihH7dwV5dt9O+/7CWD//bsP7ee6TiVnodrKzQ0WqcZ1kKvHqlety/NKZ/2i7AcIJSckDMh5H6+WadIMSOulZERH2HHz1neLWcKmuI6qKqmwBaVB6QypGQzFEhd50/721M1+8IVvgF1888sJ4UB5wcW2F7Uq3a91OjjiWdTrnLn/76VfuyD/TvpWSuTYYUgAAAABJRU5ErkJggolQTkcNChoKAAAADUlIRFIAAAAYAAAAGAgGAAAA4Hc9+AAABT1JREFUeJxllUuMHFcVhr9z61Z1T3dP99gTTx4OHieEYDA2CSLERlYcCYQEOFlF3rGKFIVNBAGJ5WRAQqyIkBASEWZFYAFKEAgWZAFCgmA7L5NYlvMisfCMPY/M9PtRdc9hUdU9PUMtuur2vfc/r//8RwBYWnIsL6uZyYNP/+B41k9vM1Xh/56w55VBVmyJWuLita9/rHxpeXlZx5gy/lg888RJFydLw8HwpCFlEQTGNgxMwQzMMDPQfG2qmCmomXOuW6mW/1XdV1v+969+cp6lJScADz39/fvV7NzKtfVPhkzTbqff2AHPDZjmwGKKaW7QVHGAhYBqsXaOWqOyvv9A48yl3/z0gpxeWvI3rjZfHI3CwyEdpYbEg0FWzfHF8otWeJ+DjD2PgN5gIHEkEjtnGgKmGsD5fQv1v3z+C4uP+P6NcLTT7J7qdga1yEeIiwjlEaVqxPPfeTzce3ABNSWPyMB24kqzwJX3V+ypHz0ffdRsu8gJmESaZdZvd0+890HnmB/p6A7VUI0iZ845RExSnyE+4sjifr9yY52VjW1iH2FT4KM049g9BznzpRP257+/kf38d391840aWVAQJGShmg4HB72IK66ZAGamuZcGg2HGSxeu8NZ715kpx0WNjXISMximlJOYw4uHcGhe9N2PAPipOhYpsKltePT0cU597uP4KAJAVfnsPYeo1esMu10il+JkD6OnQvWE8R9jltjUOePo4p2ENCOY4UXoqxIMmtsdTAOlajm/O+3k1MtPDE44rpNdJ8LfPrhGs9dnYbbK5mjIkWqFso0IZlQrDaBepNT2kKDAyL81bx4z0J1DAqyPBmykQ4ZOWQ8jSolQ84Gqz4hkfNCQCbjtSRHZBNhEEdsplgFHGnO0kyH1KKFciQghomsVghkVHCCkaV4bJ0WXF0YC4MI4R4UU2JR1EeGNzQ1e29xgNe3zensLcSlV2pSthY886EjmG0gUxXT6AScw3Ss+DyDPvajkhorMqRkPHFig3R9SSxLmGyWwmA4Ol5SJP7poN69cDN89ObCv3X1Yv/frprt4tUUlzh2NCAVNc7HCJOezFRx1Ivzz5irN/oAjt87zTrvNo7fOU3WBsHnBBtdeyhi1otc2nJxfK9ljD83TbMa8vdKnnngIkP8W4oXu5rCacfr2O+gMRlQSz51JFaeBgaUk/eu62eq6qxu4F9+J2eik8o1TUfrlz5T8m+92iGZzVS/6oBAxEUR1QjtT5Y//+ZCtXp9jt9/ClU6Ps3NGqXkVF1p2vS3u2VdK3D0npMFIVYidgoZJIfyk89RACm0XkNjTqNf41uGHyaeKMRE8voL+9/fR0dZa9uR92+JJSWZmdWFf5H78akuSkhCCAgFvmsp4aEjRY7LeY9gb8uwv/pA1KjOWhYCIYIDDcOJotVpy3/5S9NiDhzIjsNWL5dvnVv3lD/tWr5XE1IwMvIujVedcF9WGFZIifSVtDfjhz17wk5pMS6nlTRWXEo7fVXWNWc/l97usbac0ZmcIabBkRnpJ7Fe9/+KnL8/c2H550Bl81bKQiXMRzuHKM9xSqTKFusNvMwxDQ+DNayNCNqCcOObqM2SpBhHny7OV85/41MIlATh69psPNNe2/9Te6hywkMFeddxlYLckjBtLVVFVRBy1+frm/MG5R9767S9fngz9Y2efPNHZ7jzTa/dOhDRUEYTpwbw3RYUhGw8Jw6LI9Wbq1Qu1/bVnLr9w7h+ToT82cnppyTff3bo/TdPbnJkQFYBhdyxh7yoDETEfyU2/z15/9bnn0jHm/wBwRS/XpOzk7gAAAABJRU5ErkJggolQTkcNChoKAAAADUlIRFIAAAAgAAAAIAgGAAAAc3p69AAACBlJREFUeJyNl2uMXVUVx39rn8e95947nelMOy32iZZSKxQKKAGRmEoklqgg1ghFDXwRYwwhAflgDBoSvhG/GCMkJiQKqKWmECJiUMQIUVBBgkRaBVuEtkPLtDP3dR57LT+ccx9TKnEl556z99l3//97vY8wEgFsMLjk5jtnXZzUoQckY8sG4x7/ryxm7f5LP7xn7nRYsmRi165g+/KzP5tl2TVZL9/i1TcFZLTMhr9i1bMpqJWzZtVtMFbMsECkG9WjV8M4eOTlB36zD17JBphSXmJsuXpm07YN9/Q6/ev7vTxSNQI3wB4QAMywIVh52dgzqtVYy3cVOeccSSvuT61Y/lDeOf7N/Y89dAxMQjMQ2VT75K5Lv5VnxcVv/fvI3MRkw7K0SE7Ot5c753BOcCIjJVQnHAFrCWRWnUnxHtR7xFXTPmfxWL+ep8WNM2tm2Lp1182v/J08FBE758u37Tx44K0bfZ6nhSc2ywOvFoo458TR6WX086LSw9jJdXTSUhOVOVRpJDFxGGDeV0Z2BDHaW+jIQhTsnj7/fY8jsieEO51Z+3PH505OFXmBCwLECSIOVzfaRYedl51XfPjsM3272xc3dB8bu5f+oGaEImTes/fXzwWHDr8dJHGEH5AwXBA67S704tZU7/Ps2vWL8PxvZDPtw9lWU7UoChQRhzgIVLRZ0FnocdXlZ4VfufKKADzgTnFmThlngHLDzouzT9x0t3T6mXMilWOCiKDek3bTLRduWDMbJt41FkwbGGKYCCIYqHkEEBN6aU574bg8+MQfUTXcuE9WsIFzpHnBtrPWsn3zes5aNxNu2XiG/8ML+91EK8HruB8bpr7pM22FLgyNd4lVoQWGEYUBaZrz6O9fxBeKuJFDikDhlcJ7Fjo9bvjUJVx63iayzGO+APTd2w/0FQQWnopbRqeBlAMRwXtlciLh1t1XIAJSqV4E8sKzanqSbZvWY6qoGp1OSlKvV1Ey8JnTSzhCLgHNrASwAZuRtJIagRv5gABejVoY0u328WolwVNdY/yApyWgAw6VTm0pbTUjjCMu2LyR0DnGqRngVcnyAuccw/wwhloGyyBzLiUTji+TasUgnyzJ097zr6PHCUQIncNXO4VSGkSkJNpK6jTiqPqfVYBLCY2PRyYY2GsQ30PGRugc82nK7c8+S6aem7adw59OHOWdNOeWTR9gQ/E2PTVC9QTheqw2O9rnNPmCMVLhiFTJVk4hICLkqkzXE+69YgeBCFHg2LFmDQZE4hBW0qxOGwYBph6IxnBsjIeNzAKE/cHkoJKNF5pKnAi5L3j+zcOAsG5ZixN5Rq7KxmaDumalG6myrDVJI0kwUwQjdIYDdFz1Y4/h0E2GJtARkcoEgQidomDP669RqLL7Q1v488ljnMhyvrpsI9M2T18NoSCijoUrCKKAzDu6C54g8kQBo4I1xiCsD81jZehXHHAjE2SqTCUJP7nySggc/X7Kp9dsBCecSFN6sgoHeBNqQYrM/Y7Fxf/IXV9wwXPnbeT+pxZ57XCbZs2hakuCrPKBQTUrJ8VGmRAgckK73+eup5/Fm7Jjw3oOdE7SLgp2rl7NSn+SVKFeC0jnntTsxBu5z3O5bFXMuStrbF63PP7Og7D/0AJJ7PDjGhge2bSq5WMdTSVlenDMLmuiZqyYaHDCFTSKgulWwlSRU7gQDj9hnfk38iCfj9qdnrv/HyFH24E9fSSxe3bPylV3L456iHEnNLXKBFWKGYsCAG9GM4655dxthM5xMk05f2KaQOB4ljMfz5BwEuse95p1goPHeq5dxHzvLwmfeX9Per7uLzozsK1r4/CVQ13qkRtqOKRfgWnpdiKUL8fyQOQc870uN/3yV+SqfOmcD/L8iTnmc+Nra5ez5vBvySKHK7zVJA2+/UyTC1Yp6yYURDBTojC0mRYUhUcih1ZFKoT+sK3CZBirw/pN2WAkYcStF25HRFg70WLz9BS5wrokotbYideU7OCjIq6uhe87NUevKAtZpkI/9+7NYymRA1U9vRMuyVhm4AQLhCSpUa9PcvnmGlRRvbQarEVV6Gevh3qknd7xUZVlbjHYsU5Y1mz6Gy5r6uMvdKNXD7aZXJaQF9X+KYRaFAI68oFBEUg9Otcm0oy/vvDPYm3c9AudnriyZRlmNpEqasTxzrEam+uNaOdFrSJL08KJEcaJPLO/iG7/0QHqsWBV0wpg3ktoFndFXA8zGxYOExCHf7tLw+fcd9++8Ps/2BuMAy/JalUhUzWmWjW59mOz8Ue2TGAIz706x8+eOor3Sr3RQFURMwLnumK+I3Cn23LNkR/PHTp6vfqi7Akr65dtgeKqhDSSIYux53Iiz3IWF/tjhUeZaMUEYVzZ3lTEudkzVz98oNn/ooPvapxEe5NmPfV5IWLl5wxViy0mGDLotkeXDTrw8p1XwSsEYcTMzATT0y2mlzeZnp7ABSW4gPq8kGRZkseN+l727PEOM3npxaOPTc5OPpBMNCTPcmeqipliqlWfVV6DcUlSMVUzVRuuNTVVLQqv3pt6NS18uQY1LdLc1VsNmVo189P28/v3YSZh1T9lxcrr7phZM+vC6J3ruovdmhb+vVq5JWo/Xd0fdkVW+ocLHBMrJrOp1dM/z3r5bQcPPt1HRoat3GtrvHXXx6/1aXp1v9c/27w1wNzS3vAUWjqaU1vSe5cbGyaBdGtJbX+tFj/y8r4nH4aD/QHm+M7jn+ey/aavn+HCJFHv/1eL+d6SljfXCKyYX+z/bc+9hxn16EOs/wLCPxbhnAsPiAAAAABJRU5ErkJggolQTkcNChoKAAAADUlIRFIAAAAwAAAAMAgGAAAAVwL5hwAADiVJREFUeJzNmnmsXNV9xz+/c++d/c1b/N4ztsEG29hgBS9sBkwFgYbQRiRKoieF0PaPKP2naRNVlWiKFMBVlKhR1LRRqlRVKlpViZTQIlWhgAKEJi2LXYixTbD9wGYx3t++zHKX8+sf986dO8t7tP9UPdLM3Dl3zjnf728/5w70bzIxMeGscO//vD3yyCMGkH73ejsfecSwf78FYOu9Y1fffM2uykB5i3G9UVHrAmD6zGRXWt523W9/t92DbPxd1IRWo+nFmflTb790+DAXD1xIwBnY3zGok0AK/rrha373nvsrlfI9zXrz6nqtuSZoNssKJjtEBFSzEyho97WCBUVBbbtfNRmrySSa9CkiYr2cVyuUi9PFcuHt5YXacyf+5bkfweRUh4A7CCQ3Lrv9gR2X79z8YLPevHXq3MwGv+GXNfmZIJkRrYsMA20B7QYGqp3fSb4rCraXhKoiqnjFXG10/ei5Yrl44NShN789f+SZQ0xMODz+eNRGkYCv7J7YceWuzX85Nz23d25qaSiXd7AKxhhcR1Qlq7CEjGZIJNfaUksKmhRYSkwzxDr6tIOsWitREDE0PnJxbOP4aydfe/Oh+cNPvd4yJwEkVtuN1Tsf/Mx3t+y4Ys0Hp84PF0qF4MiBEzu3Xbdpcuri/Mg7J85e7bpGNRV9lkwngR7zyALKSL/d14cAbZKCWr8ZmuG1Q1OjG8aePfTsf/4RZw7OIII7MTFhRCTafv8ff25hbmnvL//tv6qu50YIpl5rlt596+wmvxkUjJF4rkQLRjLukJU40gUWUOkwD7TNWRCsVWwUpZrt9C1FFePlHTt7YXa0OFC69dp9NzxwTOS7ExMTjgBUd9wzsu3OvX9/+sTp3240w5yIARFc12AtiBGMY+JFE9ANP1Cr2mlFXZJLbXwl6aKEQSSOI1SKBWxku4h2aspaVdc14cYdm5+d/OXrX1h+5+cXXIDLdu7YXV+qXxP4YS6XcyxIS9LieqKKAVGxxQArihH4m698vrlpfMw2gkCMSQJMR7Md1tXP2Y0IC7Wm/uCfX3BeOHgkXykVsVa7J0qbCOo3Aq+2uLRt/c6rbnjrHZ5yAUrl4vbFucXRVIhCbC8iqIqgSlTy0XyEWgFH2LdzfWHzFZcRNZuxnfZklL55p+O2EQOO0c/cvaf5yS99p/mzlw7lq5USUaQ9v034C0Bjsb5m6LKRbcBTBsDxnNHQDwqSSD1hm8FgwWhsy4kFLNWa+Et1rAXH8zCu2/VyVnm5GAyLyw1mZhYFGoUvf/5jkVqrqitrIMYl+E2/YDBjAC6AGIz2z6/ETmRjW+6YCLx8jmdeOsIrb5win3P5kLXTcX4QsfXycT571/WxeMKIaqUgOUew1vJh2lOrRow6KYEPbWmiaUUTQRXEdXnspy/y+NMvUxwoEdkV64lUrUaEesNn17aN3Pcbu3CMJJHIolEUr9Nrjyu21Qn0c8AEjRghavp8/6u/w8NfvA9ZZVEBIlWCMEQQImsZGxog77n4QZjGDM3G1/81AUsmnseTSXecTzUQfzOOcPDYSU5fnCHnuj1mBrHNNv2A3Vs3snfndiI/wBghCCP8IOoirl2f/b/2J9Dz6z4Slc5PtcqG0RFyrofrmL7rCBBGEYOVErXlOmEUIUmyiqNcn+X7LK0rWEOGQKYcaAFMElWamLqAqbVs37SOj2y+fOWVk/4wivCDEGPMCmG3BaF3rdVaTMC2xmZLAuLM8SETNIOQIAxppQ8jsc+3mslUTq7TDnSqYLPi71loNX9o97vZvpSEpCpIPvpPJiKEfoiNLCJCpEo9CCm6bgq6HoWEKoiYtM+qUsy5DJW8ri2Ntt+1+yKjGW3vjxICNnn1aqBdt2QTYmIYxnBkeprJ2VlcMQzkcuxeO8bBqXOx7avluuFRRvFp+g2MxCW4WovjVlDWoIS9wpWVNNNrXp1OrLR2RHR6V5d9J+oXx+GJUyf58Ym3KLgOV1UH2T90C3976k08MSwGAQ/tvIFNzhyNxSnEceOZbAhcBgOjPeC1D8hOA1jJibtq9g4S2kVAwBEh8n2+vu829t92Kwq4Rig4Dk+M/lZqiXnjABsYH7PZ4SiCtXFE6hRUN+rVvbA3jCYqTEmsEhVEIAoi1MYVqm+VubBOyXFTWItRnRDBiEn1aFUpeg4DRa930qwJpdabLcE7iaZRqLP2joG3XaqPWgGMYXJujnfn5nGMoex5XD08xK9nL4JChLJ1YIgqPkHotx1ZLZgykEMT3xPiiCVoJ+iuy3S3ZzME2scbGbCZnUpPFEp8wDgu/3j8OD86foKi67J5sMrX79jHN4+/jieGhSDg4d038VFnlunFSzjGJd4gBhhdBwNDicAcAiss13zcfBHPhTDskv4KZpCaUOskoCc1Sr++xAeCgD+/7Rb+bO9NCOAZQzWf4yd3fDxdrup5OHoZY2u2Z4ejYrDq4noG0Rojxbq5fsc63psKuTTXYLjixjklG2c1axVdBNqnBCCioJKAp5dAyk1xLVRx4pxgLTMLNUpue9r5Zp0IkwSFGL21SjHvMGRP0DjzH0wtnGVMo9zTXx2WM4s5fnwAvvev74GNyLkm3qVlTCi+tl0EWjdTG8zEnT4EWj7w/tISZxYWcYxQdFw2DFQ4ObcAxGa2vlSmREgYhclmXTGOh3vheabff95aZ8R3vLy11sFGhk3lhvnmJ/zcx6671nzuL47TaAa4jrQtpKslTtxKYhlz6ToZ6EZvVTGuy/ePHuWHx09QcF22DA7yjTv38bU3DuIZw4If8Oiem7nLmWVq8RKuccB4DDsXWHjvF5FUNjd08YPc8ty7hbyJyLuG5dx48KnH6vqJj9R47CtX86n9RxiseJkA1OkPvXkgu3FpRaNuM8r4wEN7b+IP9+wCiXPAeKnEP9x+dzrlWKGIYYw1Q1eBeLjRFAuvP6lSvrJRv3SsFDYXpVLI8fQ7eZ455fInN57zTs4N8fTRRf3Tj87LvTev5ZlXzjI4kG/vlTNQMtVVhgTae92niSpV12NTqcyVxTKjXp6lWoMxk2Pc5Fnr5GnWfWYbwmKYZ8GWCOcnsVaCsDHvSbAguVyBsqe8et7hJ8dzzDTzVN2A8vDlAVEYfHpvmSiMSMvKlTSgZGws6wT9IhNtHzi/VOPi8jJGhLzjsKZY4IOlpXSJkXwBL5rHhg3ELeDPv4eaopXGJW/W9/iDp4r8/s4mo0VLJa8YUSIEwroTMRBsGccr5B2iKGrLuzsPtOu4Nol2KdGHQMYH/vrIYX6YyQPfuHMfXzt6kJwYFgKfR/bs5c5zTzB98U3c/CAysgY1HoZI5pvCy2dc7rgioOhCpLHM4prPogqOSa6tdGLqjEK2HZ5aJXQGraIdFUt8piPYMOTLe3Zx//ZtiAgl12VjdYC/unFfPKsqV5SraGWCwU3LRJLHmX8Fam+IkxuIhEVjTLyH8CNohBCq0AgsTYrWldCcm3Vo1HwKQyVsgiUrzv5OnK2bk8zccukOLUQRV1arbB8eTgE3o4jdI6PpAD+KiHLryQ0YAmuIdBk5c8Az5csbA7lz3vZhn3WVuIy4Zo0yWgjYtsZjUyVQjOP97LCPRkFc2SeWIhmL6NxSpibTKe2UmBFIzmAdJz47bUQRURQmZhefVjQ1SqcUI7iEqEJeYM5dT2ntdWb53FFv/aZdtScnjhWNrQvAxzcuky+U7A/u39IYcS55r50blcefe41KJU9k6buxSk2os5RIVJBGU0Gn62jOaZWTNAP8RtOo75t4o5IVBEJnKCYliBQ5ze1y+eiS59TPwej2euDXRW0onuOpcfM64s3mZnS9+8XvvEW91qBcrSTb1IyZa4aAjbCS3M1mO0neRQTqIfbUNEpEZCM++4X9xnMdVav9D4TSQqzTGo2Beq3JuhGXh39vk3frVt8bKDmRwbNWrWmEgfPcyWEe/LtjvPXOJarVMjZb1sSCtUqsZhcgCsNpL+/V1WoZB0VVOjMx4DhgQSLAwvnpBbf/OaZ2XmlnHxrvHc5cavLJhy6yd+c6bthedYYrrjOzZHn1xCIHj57HFUu1WiISt11HoahVvHyuEUV2OiXQWKxPFivFaUFH+x2htPQhxkHFICj5XF+5t8FqV19XUCiUKtgw5MCvL/Hyr8635eQJ1XIejINNisT0SU28WZDSQHGmsbA0mRI4d3zy9a23XD/pFbyrwmaYEyOdALK7yc5j6y6wGZvvONWTdjBA4kNuVXByDA7lEGxaj1klNpn0FLBtOjZS8fJeWKxW3p588fCvAMzExISzNPmLqdpi7ZnRDeNnojBEUJsd2BFi03yRefWKvOte57Bss1aJrBCpIVIHq8kzbe0EL4INg1DWXDF+trHceLZ++qWzrUdM8UO+oZ1Du+6763szZy7cM3N+dtTLuZYVj9xXPFbr7Olj/z3XmX1u+vuuTwHrNwMzOD48s/bK9T8//OSLX2Lp8CVEcAEVedTA0dn3Dq371uYbdwyrcuPshZkxx3UwRto4pHWG0L+4026QqwHP+IX2AR0HG8ValSAIzeDakal1m9cfev/wiW+xfOQi8qgBbFuUybPiwWvv3XPVjdsfrC8s33zp/Qvr/IZfRFq2/z9sPSR6nXg14K1oA4qbzzVGN649XxkcePX0kWPfnjn27wd6H3R3kYDN49d8+u4HiuXSb9YWa1vrS8sjfsMvqbXO6k9P+vhBd38LYEK0e9enqogxkZf36sWB8kxpsHSyvtR4YfKnz/8TvH8uC76XQMyi/YeKkVs2bN137Z5KdWALhlEw3ir/6li9df/Zo7tp9p4JI2una7NLJ08efPMQs6+e7sH2IU2Sv7j8v2ir/d3mvwFQECXazfsFXgAAAABJRU5ErkJggolQTkcNChoKAAAADUlIRFIAAABAAAAAQAgGAAAAqmlx3gAAFU9JREFUeJzFW3mQHUd5/33dM2/esW/f21taXZZkI0uW5EM+sLG9+MaEM3gdwCTllJOCkKIMhKOSSmpxOfkjqcQJoSoQQlWAcBSI4JTLiXGMb0vY2JJlS0iybGklebW72vt4+66Z7i9/zPFm5s3blQipdO3b6enp7unv9539zQxwTmVIYGDIIDq33v+fhQjAwIABDIlz6r/i9aEhwgMPaO/cwKb39Rf6u3oyGZn7X600UpzIIX7NiXVrnBju0QHq1Wp5YfTsFM6+dAaADQAYGhJ44AEGwK3u3BqAwUGJ3bsVAODi39q+YeumW7v6ClusrNUDUB5gE8wJ4wUA3dwcLhz8izaBvaE63NjoET8HoLUGETGBbGYs1crVyZnxqTdPv37iSYw+92oTLbGSDIA/oHNg7caB7Z/su2DVZQQuzk0tdJfmljrtWj2nlDYBJoAYACXOFCc0fM7RI3NSO3t/3BjL0bo/WgjhpNLWUq6Yn+no7ZgShPmxk2cOnnpq/zdRO3iiFQjNy/Y65i4bvO0dV1/06Wx7tmP0+NiG+emF9QwSJAhE5Ooa/GPSdA3COUL4SiCECWwAwS0A8MexZveoNIiY853tI2u3rh+uLFTmj710+FuVNx5/JAmEKABeh8J1n/jItqsu+lS1Ws+fOnr6CkCYUoBBxAwQUZhsWt6SxKQgmdNJhDba/Dk4gXgwh+dkAjMzSCtNrLVat3XDgbaO9rnDLxz43uLB//p2HISGpRwaEti9W+Uu/8gtF+684DOzU/O9xw+eugYgk4ihQaQ0C2afXHJNLoXrsZ8Pjl8HEGDXdAzzI6ktDnas3auwSxMJQSwNKU7+6uSumdGJvkuuv+wTmS23vR+7dysMDsr4SGJmUO/Vfbs+fOu3P/T7t58ZPnq6x7RSKteWrr/87KEtIyfG19/1B3c8fvTA8Nq9Tx64XogQgU0L8ktM7EPSEJGE5VQhbAuCevNYbponuJ+u1xyxYduGV1MZ68yB/3j+fsy9POxxQrur9sRiwwf/6Csbtqy9aeLtiY2GabBmFlJItbiwVKiWa7ne/q7RSrmWnZ1a7CER4lbAzBgISbofiLN/nmD0mmyB365XUINk0AjQju3Q1nft2DN5cnTv8M+++2XPRWpyA4YHdGrLB7Zcceeuvx07MXbZ7FRprZANERWCIISAUgwSBClFSPS9IzOU1u55ovtqPraWAg+gGBBSEISQUEo1jWmeKwIma8WUa8+e3bBj0/59j77w5/bp5/cDg9IYGIB49lno/i1r3gPmzsXZ0hrLEjpgZ0N/yUwJBgjuP98DAgwNQwpuz+VUlPbATTVAiRDVWnQ5xmECML9QEvOLi6LQlvFmbULbYxoAdq+RyxuSkrg0V+pzak7H2q0b7xg+/fz+wUHAeOaZryiiB4xiX3Hb3OR8D7tkMdjzcYzA5TF7/p4BNh3otAMSwFKtjis2redHhj5bqzsKIskcxAsjQVqW7zy9UNHf+vdnxTd3P5a1TJPC44moIQXJiDAAmhmf7i2u6toCIPOTn+yuGETEWH1rv5WxeqfHpovkU5s0B1xAWGiorO0ZfwKDkUoJ0dnGubqtm23Bb6AwGF3tWTz05Xtq6/o6l7780LfbCm056HND0OWjEFiaXejoWdvTjf7r1vPo3jcMAGjf2N0rhMjVq/VcMwCxqgZYqgb3vMvMQN1WqNtuGKtbcuP8iyA3+KqxgqyPW5+75xb148eeq7/2xnAql81AN90qUbRICMCu2VkA2WJfd9/cKFwAsrlUFmBTO9qI0x9hpq+vLYhzwWOkTANW2gK0jk1wnoUZEALVSg2O0pCC4GgNmGxeeclm+6XXj6baspnzmlI5jqFZm+lsJge426nwHVcI61yj1UrXmBmGYWByroSHfvBTzC4sQUq5jG62LkQEx1Ho62rH5z9+O9pzadcLedcNARdgeIYzad3JNobQmCYOQAJR8amXkQClGdlsGnueO4C//+YjQFvGW+SvWYiAWh3v3nUx7rxuBxZKZY8gAmsNhOOCZeKw5UoLAMLKHZ6csRziUgiUy1XcctVWPPQX92J6vgTjPCQgbDcIgONorO4p4Nrtm1Cu1CCEgFaNvQxzGNwV7tHicjIATURTaAJuORkRoJRGPmvhcx+7DVrzyikXfywAMo1Q9OgPZFSWqtDMyVNxEjPOXeWaAWBuGK6WcydLgNYMK2Xi2Ntj+LfH98CUshEILVOICNWajTvfuRPX79yCSq0OETKeUiZlt34zXiYAoIVZgxf5ef9XJkQphe5CG266fKvXuPJaiQiOUti4ugcAw5DiPGMJjianmu7XegFGuFM8jG1IglcPuJ9ciABHaxTbcrjj6h3nxSMCUHcUbKXOnfhlbQuv3AU+AH6yMdCnWIRD5B5iW9qkQnBBqFeqK64/XoSXR4jPfu6ycP6GsMkGsB/w++Gzz3mKbWyWEW1BgGmu6GHPqTDD3WUu2ylhPU2M4sRqY5Xxe8SID/YBwa4ueS1EBNvRmFhaira7F/39eeQCtUCTGTClQCGXEO0l05O8sJAHi0tTPBJEVAX8kdTYqoJda9FCApgBKQgpEoHrIiIo1nAchZSUgb8nEJTWqLIGkWhyaQxGUuK96YbhxYQ4z01S0HxqNF3kxk64gUNIGpZRM80MSwocm5vDn+3ZC4AgiTBfq+GjW7bgxgvW4C8P7kdGGiACluw67tq4BXd0ZDE5eQxSGjHOagjOArhoGeK9hS+LFEekoAUAflxN3tzsWuOAeI965pYguHsXgVLdxmsTU5DkAjBbreK6VasxV+vGkdkZ5E0TBMJ8vYbxvjKcnEClPA9ppKJmmzWkpXHu251mKVjJLjZLQGDkKAZCbOKEIgWhbNu4tLcbB3/vHjghfU8bEgTC47e939vDu5qfEgIKQO/m7ub4igGQCJ00E8s+92PraxZ/TgxiEyJBRMTeBQHwU0zn5AaVm9MLP02tOzoIK0SIyrrWiMR5MeNGvFyCJWE9LQhvmtwrHgBOs9gENsCLASh0s2VUwPUCCjPzDS9ARKg5CrZWyBpGyLQSasqBzYAQsiFpXtHsSs7arnxL+hPrTW1hgPy60wDACfeLEN/w+exLwHJK5UmiAuNQaR621pBEsLXCxZ2dWJVrx77pqSBn6DBjS6ED60yJamU+Ia3OEIaflF1BmUPErWz9Gz7fiPYJqG1kVsm3sJ4LZP8OzYvSmpE1Tbw4No4P/vRhQEo3Z1iu4L6rr8Q9l27FvXueRIdlAQBmahV88dJrcP/qdpwd2Q8jZUWNoFaQVh6p9dcF2Sb/JwRgSIIUgHbCkhMzhCEpSLLfoVDYMxJhnQ8TH94XtCjCM4Lbu7vwgw+8D47WEESoKYXLenqwtr0NX3/ngJfjA2ytsaOjG7ZloLhmF0hQbIUMIa1AMhgSDAHAQqkCdmbKmE/lkc2YkIKgFEe5nwCCC2wcAEQ7uMEwI5z7X8n4AZ74M6PdsvCx7Zc05iQCHAe21vjw5osaIBJBKwe2ZhTSGxDbjrk5WNawHYYghsmLgJoCZt6Q996Usvqy1+PAcBXPHxjHwkINHfkUHJW01kadYgw0In0CFfeDIR+9MBArxAFEqNRtnJqaRfylAUFoyuASuU8z4x7Qn88wU1jTVgFPv4LymZdRXZyEYzvi4owldt2cgUp34vDcLvzN7nHsfnIYHXnT1WLtERUsO3nRiRLgc549LxBIgx8ItShuyMBISYmcaUbiAEMIMDM0I+A0wQXMCYtqkAhy++adN1E5/BhmzhzjVGFjzSxudQyScBg87dRJnT1rXChOWD/+0g76xo5L8Zl/PIB8zozQ1AgYW7rBUIdA9wOK4D+CaiRFkv2yZkbaMPDa5BT+8OdPQhJBeJHgfdu34z0XXYA/feVFtJkGCIQFu4Z737Edd3XlMD5+JBQJMhgC3e1A5cR/YmZyyilsvq1sL4yYlcnDGVWvSAJYpDK6vefC2oGxzsrDX92b/ezd78TffWo77v/aAXQVM2ikD5PcYAQAJ9QpSnxY/DmM5jJFEiEj3chPEiErDRhEYM2wSMAkNxRKQYAYsDXDYeG6WgY0E3KWRmVkD6Ynp5zOTTeW508+k3MqcxLSgiEIjgbVluZlu34x+90XOvCv+3owa7+M737+XXj0pX48/cooCvm0axOaCOfA90e3w9yCeN8O+DBwsgwIIlRsB9u6OvHCR++GYh3YAd9A/uTm9wS7QV/368zo3djTmJ8kUjPP4MyZw1y84Oby3Mnn21StJJRsg0EKSzbwxz/PYqYq8MP3l5E1GEZawUy36/rIIfHFwZ145uW33dR5mPgwCEYMAH8r1OgYI548/U/MwjYKAagphflqLdpO5BnBiKKDiCCBIMXNELBEDZXRlyEzq22nPGWoyrQwrRwK0gGDML5EODJtYK4GTJThSoRdR6b7klq5ftK4cl3F3L65E78ankUum/YMbwwETzRCcYB29Z3RCDp8aQj70mVUwB+rlEZ5qRaESgJAVSnUlULOMENGkFBVDuoQENICoOGwgR5jBunFcZhta+3q3IhlGibGFoHHTli4do1Cb1bDkoyMQTDIM6pE0LVZQ2R6bVPPmjs3F/HqkbNoy6ZD6w67dIQAiDX6LiPYCYbZu8yTIcBVg7Jy8LPxETiavUDIwdWrVmFTVwFPnHkb0ouFbaVwZW8/LhIVlCb2QwgDSgFtWcai0hDSZLu+JIopwqOHTDz4VAYf2l7DgzdUoQHPo/hrk+B6SQizoKEWsaqzzeOybjJv7qmMAeCz0O8cet5O4ShwGeI1MzKGgV+MjuFTjz8BCAlBBF0p476rrsI9Oy/Gl17ZGwmFv3D5DfhMahiz+76OVKYIu1qC2HgVyEi7zpxEsCSZYZjCJTxRCckLALy0nC/VjYwWAi8DhFUgDkI4B4DwiwfLuwApCEu2jSv6evHcx38HthcK20pjc7GAznQaD998ZwCq0hoX5AtQtAo9717vqQ9giCqc4R/DtqvCSBcUarP+K1lBRC7J/cFrN6Ags12Ori1Jmcni5FjJC4gaa2aOx5qx5wIRQxHOAfh38SZpoNkMgh8I3bBmTaOR3Jy/ozWu6emL9K8rBQcWrJ7tQcxRK8/BKqzD0ttHU1bPthqNv2U6LOBUCBXHjSjna4TZmutj6lrAWXJQdQCqTZiz1iXYd+Q40mkjZHR9u9MyDkDIDcaJ9zcp5xAEeCAs1OuRNuHlGUu2HWknL9Jkuxzcqm4DRnEnzDP7DWanqgtb67f2H01NXtOFgXUOOtOM+3fVULIJ/Xngvetmgfdur9++doby7WnjR6/aOHV6Bh2dba4HoNAmKcTnEACIXvA7eyrQlAtXISX0xjEzlFJQLZ7stMrsxyElAgyDcHZ+FVatvxYTh5/M5TfdUtp5seRLVx22ag5QtSU+fWkdBI2FusD1l++s3p7rshfODLdNWQP46+88ByttQDMFCZ2GJ2M05wO87bAf6QXrT1ABCAIv2cB8DVRMuxcMASNlcibf7WTgoIWJOueSh4aUFpUXB7D5SiFHDj7ThuKOsrH6tjovnTVTtQVZZkBaBdXe3mcvLEyJxckX86u2DWDwwV/hrVPTKBay0OF1REBolMSkKAeRH8fACD3gGF0Az5fBEpCOjROVY/y5oX+qa9UqP71cAJHQxApTU/PUX6zQFwZvkEX7WG52elix0WXD6rQlGOSURX1yf7a3Iy+nCzfht79yEI8+8xaKhQwUC5CQ/mSx+xB7TsAFYKlcrhDBEVLYTt0xiULxPzdkPQCD3Ml5oQ6tHRhaYWKyJP7h0I+iH1Ek0swtTjnaRl6lauPhJ3tw/+9egfdemZOr0ovSZPe5Yx15jFbX4Pt7y/jq95/GyPgciu1pKE0gKRtxS0j8SZJNRE61VCoHAFRGxia12rlkWWbZrtlZ7823Rq458AC+MwIgBJBKgbQEWMO0GJ35fGKc0Jr3zSIZbmNmECuMTJVx/189jQf7Crh4UzfW9OTAIJyZmMHR4YOYnlyAlTVRyGfgMIGk6a4varqYNZOVtSogKs9NTE8AXuaa5187Y5dvmsh1tM0tzpa6SUjvGWlYdEJgeF6CCGAhAXYT2yoEVsObtCC8CZl4R3cuhkAm345sm8JStY49+98GezlAIQXSloFiRxaaCZoEhDSiXiswYcxKacoV2+ecam0KM6+eJgLEjTcOGADs2bOTRwu9XZNuaO3tS32fH1jPUJuHBJEACeEeSTZ+InSM/ETCtVBbqB0kAWEAwgCLFFLpLArFAjq621HszCPfnoORSkGTAUjT5XwT8eG4hdGxuufs9Nj0mwCW7rprUIpnn323BoDRIyf+W0o509aVH1OO9jMhIbEMgcGIibrrblp+M4CQ6vj1pOuh9wPYPw/mFy4QZEDDBJMJkAkSKUCYLliBIDWpFitHi2xHfjKVSc2OHn7zCQDYvRsQwAMaQ0PCHvnFobETI6+t27bxuNZaw/9QJ054A4HQtWV+4f5haQ9A5EaTF09EGoIxjGbQwzY0zPEo04iYlVLYsGPzsbPHR446Z/f9EkNDAtitAu8OZkZm2/pLP3Lb1+x6fc3Jg8NXpCxDM7tPspbPAKxUks0gR/81CIl0Cp9HDWS8LUq8eySCqlUduW7bhtfbiu0jrz7yxJ9g6dhRuPl17T+W07j7boHqkVNv/vL1f853Fmb7L+w/VK85gogZzOy/IcpezoDDN13xFxaKxjxhCWjicGTPEbVFzcTHbBV7gwhcqzqyd+Oqo11r+qaO7T3wHZSOHcVdgxJeOBhln/flSH7bHfduu+GyTyxOzRVPHx6+nIQQUgpfKKlp3K9TkrbVTW1R7kZAT+I6/HCNoRwmpRTWbbvgQGd/78zhp/fvXnjrqW/EP5pqJsTrkNk88KEt1+68z8pmCqcOD28sTc+vBdyvR6jlBwGN0KGV2J8f0edCeKPOWkNrDWagrSM/tn7HhcdV3V44sue171VPvfDDlT+b84vfMbX1ovUDuz7Zv2nNNmU7hemxqd7SzEKnXa1ntVJmy/HJlEYOidcjXTjUxEFgGO0bDGAyyDGtdDnXkZ/p6u+ZMDOp+fHjI8dOPfXyvwAnDp37h5NxEACg75prNuy48NbO1T0Xmhmrk1m3QXMKiZ/OLleWkQqOV5NUxK/E95bERMImQsmu1mdmxyaPjxx66ylnct+eJlriI1dYcfzj6Sy6rlxX7O/rTeeyOUj969kC/3l8eCsWJPAl/HTVsiXo4kARsV2qlucmZiYwvW8EQAkAmNn/yPN/8co6AGBIDA4Oyv+DL2F+44UIGBwclEDj48jlyv8AQGgYkV2vkx4AAAAASUVORK5CYII="
SETUP_LAUNCHER = "SETUP安裝軟體.bat"
LEGACY_LAUNCHER = "啟動獎勵金系統.bat"
SETUP_LAUNCHER_CONTENT = """@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
set "PYLIST=%TEMP%\\BonusLedger_python_list_%RANDOM%.txt"
set "PYTHON_EXE="

where py >nul 2>nul
if not errorlevel 1 (
    py -0p >"%PYLIST%" 2>nul
    findstr /i "python.exe" "%PYLIST%" >nul
    if not errorlevel 1 (
        findstr /i "3." "%PYLIST%" >nul
        if not errorlevel 1 (
            py -3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
            if not errorlevel 1 goto use_py
        )
    )
)

for /f "delims=" %%P in ('where python 2^>nul') do (
    echo %%P | findstr /i "WindowsApps" >nul
    if errorlevel 1 if not defined PYTHON_EXE set "PYTHON_EXE=%%P"
)
if defined PYTHON_EXE (
    "%PYTHON_EXE%" -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
    if not errorlevel 1 goto use_python
)

where py >nul 2>nul
if not errorlevel 1 (
    echo 尚未安裝 Python 執行環境，正在安裝 Python 3.12……
    py install 3.12
    if not errorlevel 1 (
        py -3.12 -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
        if not errorlevel 1 goto use_py312
    )
)

del "%PYLIST%" >nul 2>nul
echo 找不到可用的 Python 3.10 以上版本。
echo 請在 Python Install Manager 安裝 Python 3.12 後，再重新執行本安裝檔。
pause
exit /b 1

:use_py
 del "%PYLIST%" >nul 2>nul
py -3 "啟動程式.py"
if errorlevel 1 pause
exit /b %errorlevel%

:use_py312
del "%PYLIST%" >nul 2>nul
py -3.12 "啟動程式.py"
if errorlevel 1 pause
exit /b %errorlevel%

:use_python
del "%PYLIST%" >nul 2>nul
"%PYTHON_EXE%" "啟動程式.py"
if errorlevel 1 pause
exit /b %errorlevel%
"""


def _desktop_directory() -> Path | None:
    if os.name != "nt":
        return None
    try:
        buffer = ctypes.create_unicode_buffer(32768)
        result = ctypes.windll.shell32.SHGetFolderPathW(None, 0x10, None, 0, buffer)
        if result == 0 and buffer.value:
            return Path(buffer.value)
    except Exception:
        pass
    fallback = Path.home() / "Desktop"
    return fallback if fallback.exists() else None


def _create_shortcut(shortcut: Path, target: Path, working_dir: Path, icon: Path) -> None:
    script = (
        "$ErrorActionPreference='Stop';"
        "$shell=New-Object -ComObject WScript.Shell;"
        "$link=$shell.CreateShortcut($env:BONUSLEDGER_SHORTCUT);"
        "$link.TargetPath=$env:BONUSLEDGER_TARGET;"
        "$link.WorkingDirectory=$env:BONUSLEDGER_WORKDIR;"
        "$link.IconLocation=$env:BONUSLEDGER_ICON+',0';"
        "$link.Description='獎勵金、所得稅與二代健保計算系統';"
        "$link.Save()"
    )
    env = os.environ.copy()
    env.update({
        "BONUSLEDGER_SHORTCUT": str(shortcut),
        "BONUSLEDGER_TARGET": str(target),
        "BONUSLEDGER_WORKDIR": str(working_dir),
        "BONUSLEDGER_ICON": str(icon),
    })
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    subprocess.run(["powershell.exe", "-NoProfile", "-Command", script], env=env, capture_output=True, timeout=20, creationflags=flags, check=True)


def ensure_startup_assets(app_dir: str | Path) -> None:
    """Create the friendly launcher, app icon, and first-run shortcuts on Windows."""
    if os.name != "nt":
        return
    root = Path(app_dir).resolve()
    launcher = root / SETUP_LAUNCHER
    try:
        launcher_text = SETUP_LAUNCHER_CONTENT.replace("\r\n", "\n").replace("\n", "\r\n")
        launcher_bytes = launcher_text.encode("utf-8")
        if not launcher.exists() or launcher.read_bytes() != launcher_bytes:
            launcher.write_bytes(launcher_bytes)
    except OSError:
        return
    icon = root / "BonusLedger.ico"
    if not icon.exists() and not APP_ICON_B64.startswith("__"):
        try:
            icon.write_bytes(base64.b64decode(APP_ICON_B64, validate=True))
        except OSError:
            return
    legacy = root / LEGACY_LAUNCHER
    if legacy.exists():
        try:
            legacy.unlink()
        except OSError:
            pass
    if not icon.exists():
        return
    shortcuts = [root / "獎勵金系統.lnk"]
    desktop = _desktop_directory()
    if desktop:
        shortcuts.append(desktop / "獎勵金計算系統.lnk")
    for shortcut in shortcuts:
        if shortcut.exists():
            continue
        try:
            _create_shortcut(shortcut, launcher, root, icon)
        except Exception:
            # A shortcut failure must never prevent the ledger from opening.
            continue
