"""Traditional-Chinese Windows desktop interface. Run main() or package with PyInstaller."""
import contextlib
import json
import os
import re
import subprocess
import sys
import threading
import traceback
import webbrowser
from datetime import date,datetime
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
from core import Store,KINDS,DISPLAY_KINDS,SHEETS,VERSION,uid,js,milli,money,summary
from excel_io import Source,aggregate,match_record,export_workbook
from employee_io import export_employees,preview_employees,commit_employees,display_employee,HEADERS as EMPLOYEE_HEADERS
from update_service import UpdateError,check_latest,download_package,ensure_license,open_license_dialog,ensure_startup_assets

ASSETS=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parent))
def default_data_dir():return Path(os.environ.get('LOCALAPPDATA',str(Path.home()/'AppData'/'Local')))/'BonusLedger'
def error(exc,parent=None):messagebox.showerror('無法完成',str(exc),parent=parent)
def guarded(fn):
    def inner(*a,**k):
        try:return fn(*a,**k)
        except Exception as e:error(e)
    return inner
def table(parent,headers,widths=None,height=18):
    frame=ttk.Frame(parent);frame.pack(fill='both',expand=True)
    tree=ttk.Treeview(frame,columns=[str(i) for i in range(len(headers))],show='headings',height=height,selectmode='browse')
    for i,h in enumerate(headers):tree.heading(str(i),text=h);tree.column(str(i),width=widths[i] if widths else 125,minwidth=65,stretch=False)
    vy=ttk.Scrollbar(frame,orient='vertical',command=tree.yview);hx=ttk.Scrollbar(frame,orient='horizontal',command=tree.xview)
    tree.configure(yscrollcommand=vy.set,xscrollcommand=hx.set);tree.grid(row=0,column=0,sticky='nsew');vy.grid(row=0,column=1,sticky='ns');hx.grid(row=1,column=0,sticky='ew')
    frame.rowconfigure(0,weight=1);frame.columnconfigure(0,weight=1);return tree
def choose(tree):
    selected=tree.selection()
    if not selected:raise ValueError('請先選取一筆資料。')
    if selected[0]=='__total__':raise ValueError('合計列不能修改或刪除，請選取員工。')
    return selected[0]

def append_total(tree,start):
    rows=[tree.item(i,'values') for i in tree.get_children() if i!='__total__']
    count=len(tree['columns']);values=['合計']+['']*(count-1)
    for c in range(start,count):
        items=[r[c] for r in rows]
        values[c]='—' if any(v=='—' for v in items) else money(sum(milli(v) for v in items if v!=''))
    tree.tag_configure('total',background='#DFEBF2',font=('Microsoft JhengHei',11,'bold'))
    tree.insert('','end',iid='__total__',values=values,tags=('total',))

class Form(tk.Toplevel):
    """Small modal form. fields: key,label,value,choices or bool."""
    def __init__(self,parent,title,fields):
        super().__init__(parent);self.title(title);self.result=None;self.vars={};self.resizable(True,True)
        body=ttk.Frame(self,padding=18);body.pack(fill='both',expand=True)
        for i,(key,label,value,choices) in enumerate(fields):
            ttk.Label(body,text=label).grid(row=i,column=0,sticky='w',padx=5,pady=5)
            if choices is bool:
                var=tk.BooleanVar(value=bool(value));widget=ttk.Checkbutton(body,variable=var)
            else:
                var=tk.StringVar(value=value if value is not None else '')
                widget=ttk.Combobox(body,textvariable=var,values=choices,width=40,state='readonly') if choices else ttk.Entry(body,textvariable=var,width=43)
            self.vars[key]=var;widget.grid(row=i,column=1,sticky='ew',padx=5,pady=5)
        body.columnconfigure(1,weight=1);bar=ttk.Frame(body);bar.grid(row=len(fields),column=0,columnspan=2,pady=12)
        ttk.Button(bar,text='確定',command=self.ok).pack(side='left',padx=8);ttk.Button(bar,text='取消',command=self.destroy).pack(side='left')
        self.bind('<Escape>',lambda e:self.destroy());self.transient(parent);self.grab_set();self.wait_visibility();self.focus_set();self.wait_window()
    def ok(self):self.result={k:v.get() for k,v in self.vars.items()};self.destroy()

def employee_form(parent,store,employee=None):
    e=employee or {'id':uid(),'employee_code':'E'+uid()[:6].upper(),'name':'','title':'','employment_type':'civil','active':1,'default_insurance_milli':0,'payout_enabled':1,'nhi_export_enabled':1,'tax_difference_role':0}
    types={'civil':'公職','contract':'勞工','other':'其他'}
    fields=[('employee_code','員工代碼',e['employee_code'],None),('name','姓名',e['name'],None),('title','職稱（可自由輸入）',e['title'],None),
        ('employment_type','身分',types[e['employment_type']],list(types.values())),('active','在職／啟用',e['active'],bool),
        ('employed_on','到職日期 YYYY-MM-DD',e.get('employed_on',''),None),('left_on','退休(離職)日期 YYYY-MM-DD',e.get('left_on',''),None),
        ('national_id','身分證號',e.get('national_id',''),None),('bank_account','收款帳號（文字保留前置零）',e.get('bank_account',''),None),
        ('insurance_unit','投保單位代號',e.get('insurance_unit',''),None),('insurance','預設投保金額',money(e['default_insurance_milli']),None),
        
        ('tax_difference_role','醫師差額扣稅人員（每批一位）',e['tax_difference_role'],bool)]
    f=Form(parent,'員工基本資料',fields)
    if f.result:
        r=f.result;r['employment_type']={v:k for k,v in types.items()}[r['employment_type']];r['default_insurance_milli']=milli(r.pop('insurance'))
        return store.save_employee({**e,**r,'payout_enabled':1,'nhi_export_enabled':1})

RESULT_HEADERS=['員工','未扣稅金額','報稅金額','前次累計','截至本次累計','四倍投保額','當月投保額','個人計算稅','預扣所得稅','二代健保','實領']
def result_values(x):return [x['employee_snapshot']['name']]+[money(x[k]) for k in ['gross_milli','taxable_milli','previous_accumulated_milli','accumulated_milli','fourfold_insurance_milli','insurance_milli','calculated_tax_milli','deducted_tax_milli','nhi_milli','net_milli']]
def summary_text(s):
    return (f"本次 {s['people']} 人｜未扣稅 {money(s['gross'])}｜報稅 {money(s['taxable'])}｜預扣所得稅 {money(s['deducted'])}｜二代健保 {money(s['nhi'])}｜實領 {money(s['net'])}\n"
        f"需預扣：{s['withheld_count']} 人次／所得 {money(s['withheld_income'])}　免預扣：{s['exempt_count']} 人次／所得 {money(s['exempt_income'])}")

class ImportWindow(tk.Toplevel):
    def __init__(self,app,kind,replace_id=None):
        super().__init__(app);self.app=app;self.store=app.store;self.kind=kind;self.parsed=None;self.ready=False;self.committed=False
        existing=next((b for b in self.store.history() if b['state']=='active' and b['bonus_kind']==kind),None)
        replace_id=replace_id or (existing['id'] if existing else None);self.replace_id=replace_id;self.base_revision=existing['current_revision'] if existing else None;self.cycle_id=self.store.cycle()['id']
        self.source_file_id=None;self.people=[];self.regions=[];self.raw_rows=[];self.components={};self.source_applied=True;self.file_label=tk.StringVar(value='尚未選擇檔案；亦可雙擊人員手動輸入')
        self.title(('修正／取代 ' if replace_id else '匯入 ')+DISPLAY_KINDS[kind]);self.geometry('1240x780');self.minsize(700,450);self.state('zoomed')
        self.settings_record=self.store.settings_record();self.settings=self.store.settings();self.metadata={}
        top=ttk.Frame(self,padding=(10,6));top.pack(fill='x')
        ttk.Label(top,text=('修正原批次（保留順序）' if replace_id else '本次 '+DISPLAY_KINDS[kind]),style='Title.TLabel').pack(anchor='w')
        bar=ttk.Frame(top);bar.pack(fill='x')
        ttk.Button(bar,text='選擇 Excel 檔案',command=self.load_file).pack(side='left',padx=3)
        ttk.Button(bar,text='新增／納入員工',command=self.add_person).pack(side='left',padx=3)
        ttk.Button(bar,text='刪除選取員工',command=self.remove_person).pack(side='left',padx=3)
        ttk.Button(bar,text='套用最新基本資料',command=self.refresh_snapshots).pack(side='left',padx=3)
        ttk.Button(bar,text='套用目前計算設定',command=self.refresh_rules).pack(side='left',padx=3)
        ttk.Label(top,textvariable=self.file_label,wraplength=1100).pack(anchor='w',pady=6)
        meta=ttk.Frame(top);meta.pack(fill='x');self.vars={}
        fields=[('credited_on','入賬日期',date.today().isoformat()),('earned_period','獎勵金所屬期間',''),
                ('title','清冊標題',self.settings['organization']),('check_number','農會撥款支票號碼',''),('fund','內部往來統籌金',''),('remark','備註／修正原因',''),('months','醫療六欄標題（／分隔）','1月／2月／3月／4月／5月／6月')]
        columns=3 if self.winfo_screenwidth()>=1700 else 2 if self.winfo_screenwidth()>=1100 else 1
        for i,(key,label,val) in enumerate(fields):
            r=i//columns;c=(i%columns)*3;ttk.Label(meta,text=label).grid(row=r,column=c,padx=4,pady=3,sticky='w')
            var=tk.StringVar(value=val);self.vars[key]=var;ttk.Entry(meta,textvariable=var,width=24).grid(row=r,column=c+1,padx=4,pady=3,sticky='ew')
            example={'earned_period':'如114年4～6月','check_number':'如NB4807180','credited_on':'YYYY-MM-DD'}.get(key,'')
            ttk.Label(meta,text=example,foreground='#56707E').grid(row=r,column=c+2,sticky='w')
        ttk.Label(top,text='雙擊或右鍵修改資料｜右鍵新增／刪除選取員工｜底列顯示各金額合計',foreground='#285B71').pack(anchor='w',pady=8)
        bottom=ttk.Frame(self,padding=10);bottom.pack(side='bottom',fill='x');self.status=tk.StringVar()
        ttk.Button(bottom,text='確認入帳／儲存修改',command=self.commit_inline).pack(side='right',padx=5)
        ttk.Button(bottom,text='保存草稿並關閉',command=self.close_editor).pack(side='right',padx=5)
        ttk.Label(bottom,textvariable=self.status,wraplength=700).pack(side='left')
        self.order_var=tk.StringVar();ttk.Label(self,textvariable=self.order_var,wraplength=1100,padding=8).pack(side='bottom',fill='x')
        self.totals=tk.StringVar(value='請輸入本次資料');ttk.Label(self,textvariable=self.totals,wraplength=1500,padding=6).pack(fill='x')
        self.tree=table(self,['姓名','職稱','身分','未扣稅金額','主管加給','報稅金額','預扣所得稅','二代健保','實領','截至本次累計','四倍投保額','本次投保額','前次累計','個人計算稅'],[90,100,60,105,95,105,105,95,105,120,115,105,115,115])
        self.tree.bind('<Double-1>',lambda e:self.edit_person())
        self.menu=tk.Menu(self,tearoff=False);self.menu.add_command(label='新增／納入員工',command=self.add_person);self.menu.add_command(label='刪除選取員工',command=self.remove_person);self.menu.add_command(label='修改資料',command=self.edit_person)
        def popup(event):
            item=self.tree.identify_row(event.y)
            if item:self.tree.selection_set(item)
            else:self.tree.selection_remove(*self.tree.selection())
            try:self.menu.tk_popup(event.x_root,event.y_root)
            finally:self.menu.grab_release()
        self.tree.bind('<Button-3>',popup)
        if replace_id:
            p=self.store.batch_payload(replace_id);self.people=p['people'];self.regions=p['regions'];self.raw_rows=p['raw_rows'];self.source_file_id=p.get('source_file_id')
            self.settings_record=self.store.one('SELECT * FROM settings_versions WHERE id=?',(p['settings_version_id'],));self.settings=p['settings'];self.metadata=p['metadata'];self.components=self.metadata.get('components',{})
            for k in ['credited_on','earned_period']:self.vars[k].set(p.get(k) or p.get('paid_on',''))
            for k in ['title','check_number','remark']:self.vars[k].set(self.metadata.get(k,''))
            self.vars['fund'].set(money(self.metadata.get('fund_milli',0)));self.file_label.set('已載入原批次快照。可直接修改，或以新 Excel 取代金額。')
            self.vars['months'].set('／'.join(self.metadata.get('component_labels',['1月','2月','3月','4月','5月','6月'])))
        else:
            for e in self.store.employees():
                if e['active']:self.people.append(self.new_person(e))
        saved=self.store.load_editor(kind)
        if saved and saved.get('replace_id')==self.replace_id and saved.get('base_revision')==self.base_revision:
            for key in ['people','regions','raw_rows','components','metadata','source_file_id','parsed','source_applied','settings','settings_record']:setattr(self,key,saved[key])
            for key,value in saved['vars'].items():
                if key in self.vars:self.vars[key].set(value)
            self.file_label.set('已恢復上次保存的修改草稿；確認入帳後才更新正式批次。')
        for person in self.people:
            person['supervisor_milli']=person.get('supervisor_milli',max(0,person['gross_milli']-person['taxable_milli']))
            person['amount_entered']=person.get('amount_entered',person['gross_milli']>0 or person['employee_id'] in self.metadata.get('amount_entered',[]))
            person['payout_enabled']=1;person['nhi_export_enabled']=1
        self.ready=True
        self._refresh_after=None
        for var in self.vars.values():var.trace_add('write',self.schedule_refresh)
        self.refresh();self.protocol('WM_DELETE_WINDOW',self.close_editor)
    def persist(self):
        if not self.ready or self.committed or self.cycle_id!=self.store.cycle()['id']:return
        state={key:getattr(self,key) for key in ['people','regions','raw_rows','components','metadata','source_file_id','parsed','source_applied','settings','settings_record','replace_id','base_revision']}
        state['vars']={k:v.get() for k,v in self.vars.items()};self.store.save_editor(self.kind,state)
    def schedule_refresh(self,*_):
        if self._refresh_after is not None:
            try:self.after_cancel(self._refresh_after)
            except tk.TclError:pass
        self._refresh_after=self.after(180,self._run_scheduled_refresh)
    def _run_scheduled_refresh(self):
        self._refresh_after=None;self.refresh()
    @guarded
    def close_editor(self):
        if self._refresh_after is not None:
            try:self.after_cancel(self._refresh_after)
            except tk.TclError:pass
            self._refresh_after=None
        self.persist();self.destroy()
    def new_person(self,e):
        return {'employee_id':e['id'],'employee_snapshot':dict(e),'source_row_ids':[],'gross_milli':0,'taxable_milli':0,'insurance_milli':self.store.latest_insurance(e['id']),
                'supervisor_milli':0,'amount_entered':False,'input_method':'manual','input_explanation':'','insurance_change_reason':'','payout_enabled':1,'nhi_export_enabled':1,'tax_difference_role':e['tax_difference_role']}
    def payload(self):
        labels=[v.strip() for v in self.vars['months'].get().split('／')]
        for p in self.people:p['taxable_milli']=p['gross_milli']-(p.get('supervisor_milli',0) if not self.kind.startswith('bonus') else 0)
        meta={**self.metadata,**{k:self.vars[k].get() for k in ['title','check_number','remark']},'fund_milli':milli(self.vars['fund'].get() or '0'),'fund_entered':bool(self.vars['fund'].get().strip()),'components':self.components,'component_labels':labels,'amount_entered':[x['employee_id'] for x in self.people if x.get('amount_entered')]}
        return {'kind':self.kind,'source_file_id':self.source_file_id,'settings_version_id':self.settings_record['id'],'settings':self.settings,'paid_on':self.vars['credited_on'].get(),'credited_on':self.vars['credited_on'].get(),'earned_period':self.vars['earned_period'].get(),'people':self.people,'regions':self.regions,'raw_rows':self.raw_rows,'metadata':meta}
    def refresh(self):
        if self._refresh_after is not None:
            try:self.after_cancel(self._refresh_after)
            except tk.TclError:pass
            self._refresh_after=None
        if not self.ready:return
        selected=self.tree.selection();self.tree.delete(*self.tree.get_children());computed={}
        try:
            payload=json.loads(js(self.payload()));payload['earned_period']=payload['earned_period'] or '待填期間'
            # Incomplete amounts remain clearly marked; zero placeholders allow immediate arithmetic.
            for p in payload['people']:p.pop('amount_entered',None)
            calc=self.store.preview(payload,self.replace_id);computed={r['employee_id']:r for r in calc['rows']};self.totals.set('本頁即時計算（確認入帳後生效）\n'+summary_text(calc['summary']))
        except (ValueError,KeyError) as exc:self.totals.set('尚未完成計算：'+str(exc))
        for p in self.people:
            e=p['employee_snapshot'];r=computed.get(p['employee_id'])
            amounts=[money(r[k]) if r else '—' for k in ['deducted_tax_milli','nhi_milli','net_milli','accumulated_milli','fourfold_insurance_milli']]
            self.tree.insert('','end',iid=p['employee_id'],values=[e['name'],e.get('title',''),{'civil':'公職','contract':'勞工','other':'其他'}[e['employment_type']],money(p['gross_milli']) if p.get('amount_entered',p['gross_milli']>0) else '',money(p.get('supervisor_milli',0)),money(p['taxable_milli']),*amounts,money(p['insurance_milli']),*[money(r[k]) if r else '—' for k in ['previous_accumulated_milli','calculated_tax_milli']]])
        append_total(self.tree,3)
        if selected and self.tree.exists(selected[0]):self.tree.selection_set(selected[0])
        self.status.set('修改已保存草稿；'+('請填寫內部往來統籌金。' if self.kind.startswith('bonus') and not self.vars['fund'].get().strip() else '確認入帳後更新正式計算結果。'))
        self.order_var.set(self.app.order_text());self.persist()
    @guarded
    def remove_person(self):
        ident=choose(self.tree);p=next(x for x in self.people if x['employee_id']==ident)
        if not messagebox.askyesno('刪除選取員工','將 '+p['employee_snapshot']['name']+' 從本批移除？員工基本資料及以前批次保留，確認入帳後重算。',parent=self):return
        self.people=[x for x in self.people if x['employee_id']!=ident];self.components.pop(ident,None)
        self.metadata['removed_employee_ids']=list(set(self.metadata.get('removed_employee_ids',[])+[ident]));self.refresh()
    @guarded
    def edit_person(self):
        ident=choose(self.tree);p=next(x for x in self.people if x['employee_id']==ident);e=p['employee_snapshot']
        fields=[('gross','未扣稅金額',money(p['gross_milli']) if p.get('amount_entered',p['gross_milli']>0) else '',None)]
        if not self.kind.startswith('bonus'):fields.append(('supervisor','主管加給（本次總額，無則填0）',money(p.get('supervisor_milli',0)),None))
        fields += [('insurance','本次入賬當月投保金額',money(p['insurance_milli']),None),('insurance_change_reason','投保額修改說明',p.get('insurance_change_reason',''),None)]
        f=Form(self,'本批資料：'+e.get('title','')+' '+e['name'],fields)
        if f.result:
            x=f.result
            if not x['gross'].strip():raise ValueError('請填寫未扣稅金額；本次不發放請明確填0。')
            g=milli(x['gross']);allowance=milli(x.get('supervisor') or '0');insurance=milli(x['insurance'])
            if allowance>g:raise ValueError('主管加給不可超過未扣稅金額。')
            if insurance!=p['insurance_milli'] and not x['insurance_change_reason'].strip():raise ValueError('修改本次投保額時，請填寫說明。')
            p.update(gross_milli=g,taxable_milli=g-allowance,supervisor_milli=allowance,amount_entered=True,insurance_milli=insurance,input_method='manual',requires_manual_confirmation=False,insurance_change_reason=x['insurance_change_reason'],payout_enabled=1,nhi_export_enabled=1)
            if sum(self.components.get(ident,[0]*6))!=g:self.components[ident]=[g,0,0,0,0,0]
            self.refresh()
    @guarded
    def add_person(self):
        employees=self.store.employees();choices={e['employee_code']+' '+e['name']:e for e in employees if e['id'] not in {p['employee_id'] for p in self.people}}
        options=['新增基本資料']+list(choices)
        f=Form(self,'新增／納入員工',[('choice','選擇員工（可含離職者）',options[0],options)])
        if not f.result:return
        choice=f.result['choice']
        if choice=='新增基本資料':
            ident=employee_form(self,self.store)
            if not ident:return
            e=self.store.one('SELECT * FROM employees WHERE id=?',(ident,))
        else:e=choices[choice]
        self.people.append(self.new_person(e));self.metadata['removed_employee_ids']=[x for x in self.metadata.get('removed_employee_ids',[]) if x!=e['id']];self.refresh()
    @guarded
    def refresh_snapshots(self):
        if not messagebox.askyesno('套用最新基本資料','更新本批姓名、職稱、帳號、身分證、身分及差額扣稅角色？金額及本次投保額保留。',parent=self):return
        employees={e['id']:e for e in self.store.employees()}
        for p in self.people:
            e=employees[p['employee_id']];p['employee_snapshot']=e;p['tax_difference_role']=e['tax_difference_role']
        self.refresh()
    @guarded
    def refresh_rules(self):
        current=self.store.settings()
        msg=(f"本批門檻：{self.settings['threshold']} → {current['threshold']}\n"
             f"所得稅率：{self.settings['tax_percent']}% → {current['tax_percent']}%\n"
             f"健保率：{self.settings['nhi_percent']}% → {current['nhi_percent']}%\n只變更本批草稿，正式確認後才入帳。繼續？")
        if messagebox.askyesno('更新本批計算設定',msg,parent=self):self.settings=current;self.settings_record=self.store.settings_record();self.refresh()
    @guarded
    def load_file(self):
        path=filedialog.askopenfilename(parent=self,title='選擇本次來源 Excel',filetypes=[('Excel','*.xlsx')])
        if not path:return
        src=Source(path);sheet=KINDS[self.kind]
        if sheet not in src.values.sheetnames:
            f=Form(self,'選擇來源工作表',[('sheet','來源工作表',src.values.sheetnames[0],src.values.sheetnames)])
            if not f.result:return
            sheet=f.result['sheet']
        parsed=src.parse(self.kind,sheet)
        if any(p['gross_milli'] for p in self.people) and not messagebox.askyesno('取代草稿金額','選檔會重新載入本批金額。尚未正式儲存的手動金額將被替換，是否繼續？',parent=self):return
        self.source_applied=False;self.parsed=parsed;self.regions=parsed['regions'];self.raw_rows=parsed['raw_rows'];self.source_file_id=self.store.store_file(path)
        if self.kind.startswith('bonus'):
            labels=['前期一','前期二','前期三','本期一','本期二','本期三']
            for index,start in enumerate([22,29,36,1,8,15]):
                for col in range(start,start+6):
                    title=str(src.values[sheet].cell(1,col).value or '')
                    found=re.search(r'年\s*(\d{1,2})\s*月',title)
                    if found:labels[index]=str(int(found.group(1)))+'月';break
            self.vars['months'].set('／'.join(labels))
        self.file_label.set(Path(path).name+'／'+sheet+f"：辨識 {len(parsed['records'])} 筆來源明細。依原範本納入來源金額；醫師獎金與勞工金額可手動補入。")
        self.apply_source()
    def apply_source(self):
        if not self.parsed:return
        self.source_applied=False
        employees=self.store.employees();states={r['key']:r['status'] for r in self.regions}
        for rec in self.parsed['records']:
            if states[rec['region']]!='included' or match_record(rec,employees):continue
            options={e['employee_code']+' '+e['name']:e['id'] for e in employees}
            f=Form(self,'來源人員無法唯一匹配',[('match',f"來源姓名：{rec['name']}",'請選擇',['請選擇','新增員工']+list(options))])
            if not f.result or f.result['match']=='請選擇':raise ValueError('仍有未匹配來源人員，尚未完成載入；請重新選檔。')
            if f.result['match']=='新增員工':
                ident=employee_form(self,self.store)
                if not ident:raise ValueError('新增員工已取消，請重新載入。')
                employees=self.store.employees();rec['employee_id']=ident
            else:rec['employee_id']=options[f.result['match']]
        by,unmatched=aggregate(self.parsed,employees)
        if unmatched:raise ValueError('仍有來源人員未匹配。')
        previous={p['employee_id']:p for p in self.people};self.people=[];self.components={}
        for e in employees:
            if e['id'] in self.metadata.get('removed_employee_ids',[]):continue
            if e['active'] or e['id'] in by or e['id'] in previous:
                p=self.new_person(e)
                if e['id'] in previous:p['insurance_milli']=previous[e['id']]['insurance_milli'];p['employee_snapshot']=previous[e['id']]['employee_snapshot']
                amounts=by.get(e['id'])
                if amounts:
                    p.update(gross_milli=amounts['gross_milli'],taxable_milli=amounts['taxable_milli'],input_method='file',input_explanation='、'.join(amounts['locations']))
                    self.components[e['id']]=amounts['components']
                    p['supervisor_milli']=max(0,p['gross_milli']-p['taxable_milli']);p['amount_entered']=p['gross_milli']>0
                self.people.append(p)
        for raw in self.raw_rows:
            state=states[raw['region_key']];raw['disposition']='historical' if state=='historical' else 'excluded' if state=='pending' else 'included';raw['decision_reason']=state
            row_number=re.search(r'\d+',raw['source_location']).group()
            rec=next((x for x in self.parsed['records'] if x['region']==raw['region_key'] and re.search(r'\d+',x['source_location']).group()==row_number),None)
            if rec:
                raw['employee_id']=match_record(rec,employees)
                if raw['employee_id'] in self.metadata.get('removed_employee_ids',[]):raw['disposition']='excluded';raw['decision_reason']='使用者從本批移除'
        self.source_applied=True;self.refresh()
    @guarded
    def commit_inline(self):
        if not self.source_applied:raise ValueError('來源尚未完整載入，請重新選檔完成配對。')
        if self.kind.startswith('bonus') and not self.vars['fund'].get().strip():
            messagebox.showwarning('請填寫內部往來統籌金','請輸入內部往來統籌金金額；本次沒有統籌金請填0。',parent=self);return
        for x in self.people:
            e=x['employee_snapshot'];required=(self.kind.startswith('bonus') and '醫師' in e.get('title','')) or (self.kind=='year_end' and e['employment_type']=='contract')
            if required and not x.get('amount_entered',x['gross_milli']>0):
                messagebox.showwarning('請填寫未扣稅金額',e['name']+' 尚未填寫未扣稅金額，請先填寫；本次不發放請輸入0。',parent=self)
                self.tree.selection_set(x['employee_id']);self.tree.see(x['employee_id']);self.edit_person();return
        p=self.payload();labels=p['metadata']['component_labels']
        if self.kind.startswith('bonus') and (len(labels)!=6 or not all(labels)):raise ValueError('醫療月份欄標題請以全形／分成六欄。')
        draft,result=self.store.save_draft(p,self.replace_id);self.refresh()
        if not messagebox.askyesno('確認儲存入帳',summary_text(result['summary'])+'\n\n確認本頁資料並儲存入帳？後續批次會依目前順序重新計算。',parent=self):return
        bid=self.store.commit_draft(draft,p['metadata'].get('remark') or ('使用者修改' if self.replace_id else '正式匯入'))
        self.committed=True;self.store.clear_editor(self.kind);self.destroy();self.app.show_results(bid)
        messagebox.showinfo('已儲存','本批資料與重算結果已保存。',parent=self.app)

class App(tk.Tk):
    def __init__(self,store):
        super().__init__();self.store=store;self.title('獎勵金、所得稅與二代健保計算系統 '+VERSION);self.geometry('1320x820');self.minsize(760,480);self.state('zoomed')
        st=ttk.Style();st.theme_use('vista');st.configure('.',font=('Microsoft JhengHei',11));st.configure('Treeview',rowheight=31);st.configure('Title.TLabel',font=('Microsoft JhengHei',20,'bold'),foreground='#174B66');st.configure('TButton',padding=5)
        self.order_var=tk.StringVar();ttk.Label(self,textvariable=self.order_var,wraplength=max(700,self.winfo_screenwidth()-40),padding=8).pack(side='bottom',fill='x')
        nav_host=ttk.Frame(self,width=235);nav_host.pack(side='left',fill='y');nav_host.pack_propagate(False)
        nav_canvas=tk.Canvas(nav_host,width=215,highlightthickness=0);scroll=ttk.Scrollbar(nav_host,orient='vertical',command=nav_canvas.yview);scroll.pack(side='right',fill='y');nav_canvas.pack(side='left',fill='both',expand=True);nav_canvas.configure(yscrollcommand=scroll.set)
        nav=ttk.Frame(nav_canvas,padding=8);nav_canvas.create_window((0,0),window=nav,anchor='nw',width=215);nav.bind('<Configure>',lambda e:nav_canvas.configure(scrollregion=nav_canvas.bbox('all')))
        ttk.Label(nav,text='獎勵金作業',style='Title.TLabel').pack(pady=8)
        for label,cmd in [('首頁',self.home),('基本資料／設定',self.settings_page),('員工資料',self.employees_page)]+[('匯入'+label,lambda k=k:self.open_import(k)) for k,label in DISPLAY_KINDS.items()]+[('匯入紀錄',self.history_page),('計算結果',self.show_results),('匯出 Excel',self.export_dialog),('備份／還原',self.backup_page),('前往報稅網站',self.websites_page),('年度結清／清除本期',self.close_period)]:ttk.Button(nav,text=label,command=cmd).pack(fill='x',pady=2)
        ttk.Button(nav,text='檢查更新',command=lambda:self.check_updates(manual=True)).pack(fill='x',pady=(10,2))
        ttk.Button(nav,text='授權狀態／輸入授權',command=self.open_license).pack(fill='x',pady=2)
        self.body=ttk.Frame(self,padding=20);self.body.pack(side='left',fill='both',expand=True);self.home();self.protocol('WM_DELETE_WINDOW',self.shutdown)
        self._update_check_active=False;self.after(1500,lambda:self.check_updates(manual=False))
    def open_license(self):
        open_license_dialog(self, self.store.path.parent)
    def check_updates(self,manual=False):
        if self._update_check_active:return
        self._update_check_active=True
        def work():
            try:payload=check_latest();error_text=None
            except Exception as exc:payload=None;error_text=str(exc)
            def done():
                self._update_check_active=False
                if not self.winfo_exists():return
                if error_text:
                    if manual:messagebox.showerror('檢查更新失敗',error_text,parent=self)
                    return
                if payload is None:
                    if manual:messagebox.showinfo('檢查更新','目前已是最新版本。',parent=self)
                    return
                if messagebox.askyesno('發現新版本',f"目前版本：{VERSION}\n新版本：{payload['version']}\n\n{payload.get('notes','')}\n\n要立即下載並更新嗎？稍後可再按「檢查更新」。",parent=self):
                    self.download_update(payload)
            try:self.after(0,done)
            except tk.TclError:pass
        threading.Thread(target=work,daemon=True).start()
    def download_update(self,payload):
        win=tk.Toplevel(self);win.title('下載更新');win.transient(self);win.resizable(False,False)
        ttk.Label(win,text='正在下載並驗證更新檔，請稍候。',padding=20).pack()
        status=tk.StringVar(value='連線中…');ttk.Label(win,textvariable=status,padding=(20,0,20,15)).pack()
        win.update_idletasks()
        destination=self.store.path.parent/'updates'/'client_update.zip'
        def work():
            try:path=download_package(payload,destination);error_text=None
            except Exception as exc:path=None;error_text=str(exc)
            def done():
                if not win.winfo_exists():return
                win.destroy()
                if error_text:
                    messagebox.showerror('更新失敗',error_text,parent=self);return
                messagebox.showinfo('準備更新',f"版本 {payload['version']} 已下載並通過簽章與 SHA-256 驗證。程式即將關閉並重新啟動。",parent=self)
                runner=Path(__file__).resolve().parent/'update_runner.py'
                subprocess.Popen([sys.executable,str(runner),str(path),str(Path(__file__).resolve().parent),str(os.getpid())],cwd=Path(__file__).resolve().parent)
                self.shutdown()
            try:self.after(0,done)
            except tk.TclError:pass
        threading.Thread(target=work,daemon=True).start()
    def open_import(self,kind,bid=None):
        for win in self.winfo_children():
            if isinstance(win,ImportWindow) and win.kind==kind:win.deiconify();win.lift();return win
        return ImportWindow(self,kind,bid)
    def order_text(self):
        batches=[b for b in self.store.history() if b['state']=='active']
        return '已匯入順序：'+(' > '.join(DISPLAY_KINDS[b['bonus_kind']]+datetime.fromisoformat(b['created_at']).astimezone().date().isoformat()+'匯入' for b in batches) or '尚未匯入')
    def shutdown(self):
        for win in self.winfo_children():
            if isinstance(win,ImportWindow):win.persist()
        self.store.close();self.destroy()
    def page(self,title):
        self.order_var.set(self.order_text())
        for w in self.body.winfo_children():w.destroy()
        ttk.Label(self.body,text=title,style='Title.TLabel').pack(anchor='w',pady=(0,14))
        ttk.Label(self.body,text='目前計算期間：'+self.store.cycle()['label'],foreground='#456878').pack(anchor='w',pady=(0,12))
    def home(self):
        self.page('獎勵金、所得稅與二代健保')
        h=[b for b in self.store.history() if b['state']=='active'];s=summary(self.store.results())
        ttk.Label(self.body,text=f'已匯入 {len(h)}／6 種獎金　　批次依確認順序累計',font=('Microsoft JhengHei',15)).pack(anchor='w',pady=14)
        ttk.Label(self.body,text=summary_text(s),font=('Microsoft JhengHei',12),wraplength=1000).pack(anchor='w',pady=18)
        ttk.Label(self.body,text='開始作業\n1. 核對員工、帳號與預設投保額。\n2. 選擇左側獎金種類及 Excel 檔案。\n3. 核對本頁金額與合計，確認後正式匯入。\n4. 匯出清冊，並定期備份。',font=('Microsoft JhengHei',13),justify='left').pack(anchor='w',pady=16)
        ttk.Label(self.body,text='考績實領以未扣稅金額減去預扣所得稅及二代健保；需報稅考績才排除主管加給。日期跨年不自動歸零；由「年度結清」開啟新期。',wraplength=950).pack(anchor='w',pady=12)
        ttk.Label(self.body,text='資料保存位置：'+str(self.store.path),wraplength=1000,foreground='#56707E').pack(anchor='w',pady=10)
        backups=list((self.store.path.parent/'backups').glob('*.sqlite')) if (self.store.path.parent/'backups').exists() else []
        ttk.Label(self.body,text='最近自動備份：'+(max(backups,key=lambda p:p.stat().st_mtime).name if backups else '尚無')).pack(anchor='w')
    @guarded
    def settings_page(self):
        self.page('基本設定（修改後用於新批次）');s=self.store.settings();fields=[('organization','機關名稱'),('tax_id','統一編號'),('threshold','所得預扣門檻（達到即扣）'),('tax_percent','所得稅率 %'),('nhi_percent','二代健保率 %')];vars={}
        form=ttk.Frame(self.body);form.pack(anchor='w')
        for i,(key,label) in enumerate(fields):
            ttk.Label(form,text=label).grid(row=i,column=0,sticky='w',padx=7,pady=9);var=tk.StringVar(value=s[key]);vars[key]=var;ttk.Entry(form,textvariable=var,width=42).grid(row=i,column=1,padx=7,pady=9)
        cycle_name=tk.StringVar(value=self.store.cycle()['label']);ttk.Label(form,text='目前計算期間名稱').grid(row=len(fields),column=0,sticky='w',padx=7,pady=9);ttk.Entry(form,textvariable=cycle_name,width=42).grid(row=len(fields),column=1,padx=7,pady=9)
        @guarded
        def save():
            if not cycle_name.get().strip():raise ValueError('計算期間名稱不可空白。')
            self.store.save_settings({**s,**{k:v.get() for k,v in vars.items()}});self.store.rename_cycle(cycle_name.get());messagebox.showinfo('已儲存','設定已建立新版本。既有批次維持原快照；可從取代／修改明確套用新設定。',parent=self)
        ttk.Button(self.body,text='儲存設定',command=save).pack(anchor='w',pady=16)
        ttk.Label(self.body,text='固定核准規則：四倍投保額；前次累計恰等於門檻時本次健保為 0。\n考績實領＝未扣稅金額－預扣所得稅－預扣二代健保；健表 P 欄依外部格式保留 0。',wraplength=900).pack(anchor='w')
    def employees_page(self):
        self.page('員工基本資料');bar=ttk.Frame(self.body);bar.pack(fill='x',pady=8)
        grid=table(self.body,['代碼','姓名','職稱','身分','狀態','預設投保額','收款帳號','身分證字號','投保單位代號','到職日期','退休(離職)日期'],[100,100,130,70,65,110,160,125,125,110,125])
        def refresh():
            grid.delete(*grid.get_children())
            for e in self.store.employees():grid.insert('','end',iid=e['id'],values=[e['employee_code'],e['name'],e['title'],{'civil':'公職','contract':'勞工','other':'其他'}[e['employment_type']],'在職' if e['active'] else '離職',money(e['default_insurance_milli']),e.get('bank_account',''),e.get('national_id',''),e.get('insurance_unit',''),e.get('employed_on') or '',e.get('left_on') or ''])
        @guarded
        def edit(new=False):
            e=None if new else self.store.one('SELECT * FROM employees WHERE id=?',(choose(grid),));employee_form(self,self.store,e);refresh()
        @guarded
        def remove():
            ident=choose(grid)
            if messagebox.askyesno('離職／刪除','已有批次的人員將設為離職，保留歷史。未使用過的人員可刪除。繼續？',parent=self):self.store.remove_employee(ident);refresh()
        @guarded
        def export_staff():
            path=filedialog.asksaveasfilename(parent=self,title='匯出員工設定／匯入範本',initialfile='員工資料.xlsx',defaultextension='.xlsx',filetypes=[('Excel檔案','*.xlsx'),('CSV檔案','*.csv')])
            if path:
                count=export_employees(self.store,path)
                messagebox.showinfo('匯出完成',f'已匯出 {count} 位員工的全部設定。\n可直接編輯此檔後批次匯入；新增員工請將員工代碼留空。\n建議使用Excel格式，保留帳號開頭的0。',parent=self)
        @guarded
        def import_staff():
            path=filedialog.askopenfilename(parent=self,title='批次匯入員工資料',filetypes=[('Excel／CSV','*.xlsx *.csv')])
            if not path:return
            preview=preview_employees(self.store,path)
            win=tk.Toplevel(self);win.title('員工批次匯入預覽');win.geometry('1200x650');win.transient(self);win.grab_set()
            added=sum(x['action']=='新增' for x in preview['people']);updated=len(preview['people'])-added
            ttk.Label(win,text=f'新增 {added} 人／更新 {updated} 人。依員工代碼更新，不以姓名合併。\n更新使用整列設定（空白會清除該欄）；未列出員工不刪除，已保存批次不更動。',padding=12).pack(fill='x')
            if preview.get('warnings'):
                warning=tk.Text(win,height=4,wrap='word',font=('Microsoft JhengHei',10))
                warning.pack(fill='x',padx=12)
                warning.insert('end','格式轉換提醒（請核對，可捲動查看）：\n'+'\n'.join(preview['warnings']));warning.configure(state='disabled')
            actions=ttk.Frame(win,padding=12);actions.pack(side='bottom',fill='x')
            view=table(win,['動作','檔案列']+EMPLOYEE_HEADERS)
            for item in preview['people']:view.insert('','end',values=[item['action'],item['row']]+display_employee(item['employee']))
            @guarded
            def confirm():
                backup=commit_employees(self.store,preview);win.destroy();refresh()
                messagebox.showinfo('匯入完成',f'已新增 {added} 人、更新 {updated} 人。\n匯入前備份：{backup}\n已開啟的匯入作業與已保存草稿保留原資料；可在該批次新增員工。',parent=self)
            ttk.Button(actions,text='確認匯入',command=confirm).pack(side='right',padx=5)
            ttk.Button(actions,text='取消',command=win.destroy).pack(side='right',padx=5)
        ttk.Button(bar,text='匯出員工設定（Excel／CSV）',command=export_staff).pack(side='right',padx=4)
        ttk.Button(bar,text='批次匯入員工',command=import_staff).pack(side='right',padx=4)
        ttk.Button(bar,text='新增員工',command=lambda:edit(True)).pack(side='left',padx=4);ttk.Button(bar,text='修改',command=edit).pack(side='left',padx=4);ttk.Button(bar,text='離職／刪除',command=remove).pack(side='left',padx=4);grid.bind('<Double-1>',lambda e:edit());refresh()
    def cycle_picker(self,parent,callback):
        cycles=self.store.cycles();labels={f"{c['label']}（{'本期' if c['status']=='open' else '已封存'}／{c['id'][:6]}）":c['id'] for c in cycles}
        var=tk.StringVar(value=next(k for k,v in labels.items() if v==self.store.cycle()['id']));box=ttk.Combobox(parent,values=list(labels),textvariable=var,state='readonly',width=43);box.pack(side='left',padx=5);box.bind('<<ComboboxSelected>>',lambda e:callback(labels[var.get()]));return var,labels
    def history_page(self):
        self.page('匯入紀錄');bar=ttk.Frame(self.body);bar.pack(fill='x',pady=8);selected_cycle=[self.store.cycle()['id']]
        actions=ttk.Frame(self.body);actions.pack(side='bottom',fill='x',pady=10)
        grid=table(self.body,['順序','種類','狀態','入賬日期','所屬期間','修訂','匯入時間'],[70,85,85,115,165,60,250])
        def refresh(cycle=None):
            if cycle:selected_cycle[0]=cycle
            grid.delete(*grid.get_children())
            for b in self.store.history(selected_cycle[0]):grid.insert('','end',iid=b['id'],values=[b['sequence'],DISPLAY_KINDS[b['bonus_kind']],'有效' if b['state']=='active' else '已刪除',b['paid_on'],b['earned_period'],b['current_revision'],b['created_at']])
        self.cycle_picker(bar,refresh)
        @guarded
        def replace():
            bid=choose(grid);b=self.store.one('SELECT * FROM batches WHERE id=?',(bid,))
            if b['cycle_id']!=self.store.cycle()['id'] or b['state']!='active':raise ValueError('請選擇本期有效批次。')
            self.open_import(b['bonus_kind'],bid)
        @guarded
        def delete():
            bid=choose(grid);reason=simpledialog.askstring('刪除批次','後續批次將重新計算。請輸入刪除原因：',parent=self)
            if reason:self.store.delete_batch(bid,reason);self.store.clear_editor(self.store.batch_payload(bid)['kind']);refresh();self.order_var.set(self.order_text())
        @guarded
        def restore():self.store.restore_batch(choose(grid));refresh();self.order_var.set(self.order_text())
        @guarded
        def original():
            p=self.store.batch_payload(choose(grid));fid=p.get('source_file_id')
            if not fid:messagebox.showinfo('原始資料','此批為手動建立，可從「檢視來源／修訂」查看金額。',parent=self);return
            f=self.store.one('SELECT * FROM source_files WHERE id=?',(fid,));path=filedialog.asksaveasfilename(parent=self,initialfile=f['original_name'],defaultextension='.xlsx')
            if path:Path(path).write_bytes(f['bytes'])
        @guarded
        def detail():
            bid=choose(grid);p=self.store.batch_payload(bid);win=tk.Toplevel(self);win.title('原始輸入與修訂');win.geometry('1100x690')
            revs=self.store.all('SELECT revision,created_at,correction_reason FROM batch_revisions WHERE batch_id=? ORDER BY revision',(bid,))
            revvar=tk.StringVar(value=str(p['revision']));box=ttk.Combobox(win,values=[str(r['revision']) for r in revs],textvariable=revvar,state='readonly');box.pack(anchor='w',padx=12,pady=8)
            t=tk.Text(win,wrap='none',font=('Microsoft JhengHei',11));t.pack(fill='both',expand=True)
            def show(e=None):
                data=self.store.batch_payload(bid,int(revvar.get()));t.config(state='normal');t.delete('1.0','end');t.insert('end',json.dumps({'修訂紀錄':revs,'批次設定':data['metadata'],'來源區':data['regions'],'人員原始輸入':data['people'],'來源列':data['raw_rows']},ensure_ascii=False,indent=2));t.config(state='disabled')
            box.bind('<<ComboboxSelected>>',show);show()
        for title,fn in [('調整計算順序',lambda:self.reorder_dialog(selected_cycle[0])),('查看結果',lambda:self.show_results(choose(grid),selected_cycle[0])),('取代／修改',replace),('刪除批次',delete),('復原刪除',restore),('取回原檔',original),('檢視來源／修訂',detail)]:ttk.Button(actions,text=title,command=guarded(fn)).pack(side='left',padx=3)
        refresh()
    @guarded
    def reorder_dialog(self,cycle):
        if cycle!=self.store.cycle()['id']:raise ValueError('已封存期間不能調整順序。')
        batches=[b for b in self.store.history() if b['state']=='active']
        if len(batches)<2:raise ValueError('至少需要兩個有效批次才能調整順序。')
        win=tk.Toplevel(self);win.title('調整匯入計算順序');win.geometry('740x500');win.transient(self);win.grab_set()
        ttk.Label(win,text='由上往下累計。原始匯入日期保留，儲存後重新計算所有有效批次。',padding=12,wraplength=700).pack(fill='x')
        bar=ttk.Frame(win,padding=12);bar.pack(side='bottom',fill='x')
        box=tk.Listbox(win,font=('Microsoft JhengHei',13),exportselection=False);box.pack(fill='both',expand=True,padx=12)
        def render(index=0):
            box.delete(0,'end')
            for i,b in enumerate(batches,1):box.insert('end',f"{i}. {DISPLAY_KINDS[b['bonus_kind']]}　入賬日期 {b['paid_on']}")
            box.selection_set(index)
        def move(delta):
            if not box.curselection():return
            i=box.curselection()[0];j=i+delta
            if 0<=j<len(batches):batches[i],batches[j]=batches[j],batches[i];render(j)
        @guarded
        def save():
            self.store.reorder_batches([b['id'] for b in batches]);win.destroy();self.history_page()
            for editor in self.winfo_children():
                if isinstance(editor,ImportWindow):editor.refresh()
            messagebox.showinfo('順序已更新','已依新順序重算累計獎金、所得稅及二代健保。',parent=self)
        ttk.Button(bar,text='上移',command=lambda:move(-1)).pack(side='left',padx=4)
        ttk.Button(bar,text='下移',command=lambda:move(1)).pack(side='left',padx=4)
        ttk.Button(bar,text='儲存順序並重算',command=save).pack(side='right');render()
    def websites_page(self):
        self.page('前往報稅網站')
        for label,url in [('二代健保網站','https://eservice.nhi.gov.tw/2nd/'),('預扣所得稅網站','https://www.etax.nat.gov.tw/etwmain/etw144w/151')]:
            row=ttk.Frame(self.body);row.pack(fill='x',pady=5)
            ttk.Label(row,text=label,font=('Microsoft JhengHei',13)).pack(side='left',padx=8)
            ttk.Button(row,text='前往',command=lambda u=url:webbrowser.open(u)).pack(side='left',padx=8)
        ttk.Label(self.body,text='原範本「參考圖」：選擇圖片查看，使用捲軸移動；可切換原尺寸核對細節。').pack(anchor='w',pady=8)
        controls=ttk.Frame(self.body);controls.pack(fill='x',pady=5)
        paths=sorted((ASSETS/'references').glob('*.png'))
        names=[p.stem for p in paths];choice=tk.StringVar(value=names[0] if names else '')
        picker=ttk.Combobox(controls,values=names,textvariable=choice,state='readonly',width=42);picker.pack(side='left')
        full=tk.BooleanVar(value=False)
        frame=ttk.Frame(self.body);frame.pack(fill='both',expand=True)
        canvas=tk.Canvas(frame,background='white',highlightthickness=0)
        v=ttk.Scrollbar(frame,orient='vertical',command=canvas.yview);h=ttk.Scrollbar(frame,orient='horizontal',command=canvas.xview)
        canvas.configure(yscrollcommand=v.set,xscrollcommand=h.set);canvas.grid(row=0,column=0,sticky='nsew');v.grid(row=0,column=1,sticky='ns');h.grid(row=1,column=0,sticky='ew');frame.rowconfigure(0,weight=1);frame.columnconfigure(0,weight=1)
        def display(*_):
            if not paths:return
            pic=tk.PhotoImage(file=str(paths[names.index(choice.get())]));self.update_idletasks()
            factor=1 if full.get() else max(1,(pic.width()+max(canvas.winfo_width(),500)-1)//max(canvas.winfo_width(),500))
            self.reference_picture=pic.subsample(factor,factor);canvas.delete('all');canvas.create_image(0,0,image=self.reference_picture,anchor='nw');canvas.configure(scrollregion=canvas.bbox('all'));canvas.xview_moveto(0);canvas.yview_moveto(0)
        picker.bind('<<ComboboxSelected>>',display);ttk.Checkbutton(controls,text='原尺寸',variable=full,command=display).pack(side='left',padx=12);display()
    @guarded
    def show_results(self,bid=None,cycle=None):
        self.page('計算結果');cycle=cycle or self.store.cycle()['id'];bar=ttk.Frame(self.body);bar.pack(fill='x',pady=6)
        history=[b for b in self.store.history(cycle) if b['state']=='active']
        if not history:ttk.Label(self.body,text='此期間尚無有效批次。').pack(anchor='w');return
        labels={f"#{b['sequence']} {DISPLAY_KINDS[b['bonus_kind']]}／{b['paid_on']}":b['id'] for b in history};bid=bid if bid in labels.values() else history[-1]['id']
        var=tk.StringVar(value=next(k for k,v in labels.items() if v==bid));cb=ttk.Combobox(bar,textvariable=var,values=list(labels),state='readonly',width=40);cb.pack(side='left')
        totals=tk.StringVar();ttk.Label(self.body,textvariable=totals,wraplength=1000).pack(anchor='w',pady=12);grid=table(self.body,RESULT_HEADERS)
        def refresh(e=None):
            rows=self.store.results(labels[var.get()],cycle);grid.delete(*grid.get_children());totals.set(summary_text(summary(rows)))
            for x in rows:grid.insert('','end',iid=x['employee_id'],values=result_values(x))
            append_total(grid,1)
        @guarded
        def edit(action='edit'):
            if cycle!=self.store.cycle()['id']:raise ValueError('已封存期間僅供查閱，不能修改。')
            ident=choose(grid) if action!='add' else None
            batch=self.store.batch_payload(labels[var.get()]);editor=self.open_import(batch['kind'],batch['id'])
            if ident:
                if not editor.tree.exists(ident):raise ValueError('此員工已從修改草稿移除。')
                editor.tree.selection_set(ident);editor.tree.see(ident)
            if action=='add':editor.add_person()
            elif action=='delete':editor.remove_person()
            else:editor.edit_person()
        menu=tk.Menu(grid,tearoff=False)
        for label,action in [('新增／納入員工','add'),('修改資料','edit'),('刪除選取員工','delete')]:menu.add_command(label=label,command=lambda a=action:edit(a))
        grid.context_menu=menu
        def popup(event):
            item=grid.identify_row(event.y)
            if item:grid.selection_set(item)
            else:grid.selection_remove(*grid.selection())
            try:menu.tk_popup(event.x_root,event.y_root)
            finally:menu.grab_release()
        grid.bind('<Button-3>',popup);grid.bind('<Double-1>',lambda e:edit())
        cb.bind('<<ComboboxSelected>>',refresh);ttk.Button(bar,text='匯出本批 Excel',command=lambda:self.export_dialog(labels[var.get()],cycle)).pack(side='left',padx=10);refresh()
    @guarded
    def export_dialog(self,bid=None,cycle=None):
        cycle=cycle or self.store.cycle()['id']
        if not bid:
            cycles=self.store.cycles();opts={c['label']+'／'+c['id'][:6]:c['id'] for c in cycles}
            f=Form(self,'匯出完整計算期間',[('cycle','選擇計算期間',next(k for k,v in opts.items() if v==cycle),list(opts))])
            if not f.result:return
            cycle=opts[f.result['cycle']]
        path=filedialog.asksaveasfilename(parent=self,title='匯出 Excel',initialfile=('本批計算結果' if bid else '完整期間獎金資料')+'.xlsx',defaultextension='.xlsx',filetypes=[('Excel','*.xlsx')])
        if path:
            self.config(cursor='watch');self.update_idletasks()
            try:export_workbook(self.store,path,cycle,bid)
            finally:self.config(cursor='')
            messagebox.showinfo('匯出完成',path,parent=self)
    def safety_path(self,prefix):return self.store.path.parent/'backups'/(prefix+'_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.sqlite')
    def backup_page(self):
        self.page('備份／還原');ttk.Label(self.body,text='備份含員工、設定、所有原始檔、批次修訂與計算結果。\n還原前會自動備份目前資料，並檢查備份完整性。').pack(anchor='w',pady=15)
        @guarded
        def backup():
            p=filedialog.asksaveasfilename(parent=self,initialfile='獎勵金備份_'+date.today().isoformat()+'.sqlite',defaultextension='.sqlite',filetypes=[('備份','*.sqlite')])
            if p:self.store.backup(p);messagebox.showinfo('完成','已保存完整備份。',parent=self)
        @guarded
        def restore():
            p=filedialog.askopenfilename(parent=self,filetypes=[('備份','*.sqlite')])
            if not p:return
            if Path(p).resolve()==self.store.path.resolve():raise ValueError('不能以正在使用的資料庫還原自身。')
            s=self.store.inspect_backup(p)
            if messagebox.askyesno('確認還原',f"備份包含 {s['cycles']} 個期間、{s['batches']} 筆批次。將取代目前資料，是否繼續？",parent=self):
                self.store.restore_backup(p,self.safety_path('還原前'));[w.destroy() for w in self.winfo_children() if isinstance(w,ImportWindow)];self.home();messagebox.showinfo('還原完成','資料已還原，目前資料另有自動備份。',parent=self)
        ttk.Button(self.body,text='建立完整備份',command=backup).pack(anchor='w',pady=10);ttk.Button(self.body,text='從備份還原',command=restore).pack(anchor='w',pady=10)
    @guarded
    def close_period(self):
        name=simpledialog.askstring('年度結清／清除本期','本期將封存並先備份，歷史不刪除。\n請輸入新計算期間名稱：',parent=self)
        if not name:return
        if messagebox.askyesno('結清確認','確認本期資料已完成？新期累計歸零，員工及設定沿用。',parent=self):[w.close_editor() for w in self.winfo_children() if isinstance(w,ImportWindow)];self.store.close_cycle(name,self.safety_path('結清前'));self.home()

def main():
    ensure_startup_assets(Path(__file__).resolve().parent)
    data_dir=Path(os.environ.get('BONUS_LEDGER_DATA',default_data_dir()));data_dir.mkdir(parents=True,exist_ok=True)
    if not ensure_license(data_dir):return
    # OS file lock is released on process exit, including crashes.
    lock=open(data_dir/'app.lock','a+b');lock.seek(0);lock.write(b'0');lock.flush();lock.seek(0)
    try:
        import msvcrt
        msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
    except OSError:
        root=tk.Tk();root.withdraw();messagebox.showerror('程式已開啟','同一資料庫已有程式執行，請切換到原視窗。');root.destroy();return
    try:
        store=Store(data_dir/'bonus.sqlite',ASSETS);app=App(store)
        if '--smoke-test' in sys.argv:
            app.withdraw();app.update();app.after(300,app.shutdown)
        app.mainloop()
    except Exception:
        (data_dir/'error.log').write_text(traceback.format_exc(),encoding='utf-8')
        root=tk.Tk();root.withdraw();messagebox.showerror('啟動失敗','請查看 '+str(data_dir/'error.log'));root.destroy();raise
    finally:lock.close()

if __name__=='__main__':main()
